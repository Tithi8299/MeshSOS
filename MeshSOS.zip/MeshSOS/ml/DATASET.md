# MeshSOS emergency-message dataset

## What it is

`ml/data/meshsos_dataset.csv`: **3,971 synthetic short emergency messages** in Bangla script, English, Banglish (Bangla written in Latin letters) and code-mixed text, labelled with emergency type, severity and the stated number of people.

**Every message is synthetic.** None of them is a real disaster report. The phrasing templates were written with the help of a large language model during development, then reviewed, labelled and expanded by `ml/generate_dataset.py` (seed 20261125, fully reproducible). The `source` column marks each row as `synthetic_template_v1` or `synthetic_mixed_v1`.

## Columns

| Column | Meaning |
|---|---|
| `message` | The text |
| `language` | `bangla`, `english`, `banglish` or `mixed` |
| `category` | `medical`, `trapped`, `fire`, `flood`, `food`, `missing`, `other` |
| `severity` | `critical`, `high`, `normal` |
| `people_count` | Number written in the message, empty if none |
| `subtype` | One of 29 fine-grained concepts (e.g. `not_breathing`, `need_boat`); trains the concept embedding used for grouping |
| `template_id` | Which template produced the row (`subtype:lang:index`, or two joined with `+` for mixed rows) |
| `split` | `train`, `val` or `test` |
| `source` | Provenance marker |

## How it was made

1. **Templates.** 450 phrasings across 29 subtypes, each written in English, Bangla and Banglish, each with its own severity label. Slots: relation (father, মা, baba…), place (near the school, মসজিদের পিছনে, bazar er pashe…), number of people (digits, Bangla digits or number words) and a child's age.
2. **Expansion.** Each template was filled 8 times with random slot values, prefixes ("Help!", "জরুরি,", "plz") and suffixes ("hurry", "তাড়াতাড়ি", "jaldi").
3. **Realistic noise.** Banglish spelling variation (sh→s, kh→k, o→u, bh→v…), dropped letters in English, random lower-casing, and English words swapped into Bangla sentences (ডাক্তার → doctor, পানি → water).
4. **Code-mixing.** A Bangla or Banglish clause joined to an English clause of the same subtype, *only within the same split*.
5. **De-duplication.** Exact duplicates (case-insensitive) were removed.

Version history: v1 (312 templates) gave 0.700 held-out macro F1. Because most subtypes had only 2 or 3 phrasings, v2 added 2 or 3 more phrasings to **every** subtype and language (not only the weak ones), giving the current 450 templates.

## Leakage control

- The split is made on **templates before expansion**: in each (subtype, language), template 2 goes to test and the last template (when there are 4 or more) goes to validation. A test sentence is never a re-filled copy of a training template.
- Mixed rows are built only from templates in the same split.
- Hyper-parameters are chosen with GroupKFold (groups = template) on single-language rows only, because a mixed row contains two templates.

This makes the held-out test a measure of generalisation **to new phrasings**, which is deliberately harder than a random split.

## Distribution

| | Count |
|---|---|
| Split | train 2,470 · val 727 · test 774 (150 unseen templates) |
| Language | English 1,160 · Banglish 1,139 · Bangla 1,082 · mixed 590 |
| Category | medical 1,460 · trapped 557 · flood 508 · other 441 · food 371 · fire 370 · missing 264 |
| Severity | critical 1,606 · high 1,513 · normal 852 |

Medical is over-represented because it has the most subtypes; training uses balanced class weights.

## Independent challenge set

`ml/data/challenge_set.csv`: 70 messages written by hand **separately from the templates**, in a looser style (dialect spellings such as *partese*, *lagse*, *gesi*; missing punctuation; heavier code-mixing), including the three examples from the prototype. It is never used for training or tuning.

## How to improve it

The best next step is **real-style data written by people**: ask 10 to 20 volunteers to write how they would ask for help in each situation, in their own words and spelling, label the messages as a team, and add them as a new `source`. Prioritise *food and water*, *other* and English, which are the weakest today.
