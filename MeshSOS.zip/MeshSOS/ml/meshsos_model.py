"""
Pure-Python reader + inference for ml/models/meshsos_classifier.bin.

It performs exactly the arithmetic the Kotlin core performs (EmergencyClassifier.kt), so it is
used (1) to verify the exported file against scikit-learn's own predictions and (2) by
grouping_eval.py.
"""
import math
import os
import struct
from collections import Counter

from featurizer import analyze


class MeshModel:
    def __init__(self, path):
        with open(path, "rb") as f:
            data = f.read()
        p = 0

        def rd(fmt):
            nonlocal p
            v = struct.unpack_from(fmt, data, p)
            p += struct.calcsize(fmt)
            return v

        def rs():
            (n,) = rd(">i")
            nonlocal p
            s = data[p:p + n].decode("utf-8")
            p += n
            return s

        assert data[:8] == b"MSOSCLF1"
        p = 8
        (self.version,) = rd(">i")
        (nf,) = rd(">i")
        self.index, self.idf = {}, []
        for i in range(nf):
            self.index[rs()] = i
            self.idf.append(rd(">f")[0])
        (nh,) = rd(">i")
        self.heads = {}
        for _ in range(nh):
            name = rs()
            (nc,) = rd(">i")
            classes = [rs() for _ in range(nc)]
            coef = [list(rd(">%df" % nf)) for _ in range(nc)]
            inter = list(rd(">%df" % nc))
            self.heads[name] = (classes, coef, inter)

    def vector(self, text):
        counts = Counter(f for f in analyze(text) if f in self.index)
        vec = {self.index[f]: (1.0 + math.log(c)) * self.idf[self.index[f]] for f, c in counts.items()}
        norm = math.sqrt(sum(v * v for v in vec.values()))
        return {k: v / norm for k, v in vec.items()} if norm > 0 else {}

    def probs(self, head, vec):
        classes, coef, inter = self.heads[head]
        z = [inter[c] + sum(coef[c][i] * v for i, v in vec.items()) for c in range(len(classes))]
        m = max(z)
        e = [math.exp(x - m) for x in z]
        s = sum(e)
        return classes, [x / s for x in e]


if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__))
    mm = MeshModel(os.path.join(here, "models", "meshsos_classifier.bin"))
    worst, n = 0.0, 0
    with open(os.path.join(here, "models", "golden_vectors.tsv"), encoding="utf-8") as f:
        next(f)
        next(f)
        for line in f:
            msg, tp, sp = line.rstrip("\n").split("\t")
            v = mm.vector(msg)
            _, pt = mm.probs("type", v)
            _, ps = mm.probs("severity", v)
            ref = [float(x) for x in tp.split(",")] + [float(x) for x in sp.split(",")]
            worst = max(worst, max(abs(a - b) for a, b in zip(pt + ps, ref)))
            n += 1
    print(f"checked {n} golden vectors, max |diff| = {worst:.2e}")
    assert worst < 1e-4, "exported model does not reproduce scikit-learn output"
