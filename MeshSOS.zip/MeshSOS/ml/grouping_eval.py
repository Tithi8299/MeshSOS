"""
AI-5: duplicate-report grouping. Reference implementation of the algorithm in
core/src/main/kotlin/com/meshsos/core/ai/IncidentGrouper.kt plus its evaluation.

Scenario generator: incidents are placed in a 3 km x 3 km area over two hours. Each incident
gets 1-6 reports written in different languages (real messages of the same subtype taken from
the dataset), sent from up to 150 m away, spread over 25 minutes. Hard negatives are added on
purpose: a different emergency of the SAME category 120-400 m away, and the same subtype far away.

Thresholds are tuned on scenarios built from VAL-split messages and reported on scenarios built
from TEST-split messages (templates never seen by the classifier).
"""
import json
import math
import os
import random
import sys

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from meshsos_model import MeshModel  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
SEV_RANK = {"normal": 0, "high": 1, "critical": 2}


def haversine(a, b):
    R = 6371000.0
    la1, lo1, la2, lo2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    h = math.sin((la2 - la1) / 2) ** 2 + math.cos(la1) * math.cos(la2) * math.sin((lo2 - lo1) / 2) ** 2
    return 2 * R * math.asin(math.sqrt(h))


def cos_dense(a, b):
    na = math.sqrt(sum(x * x for x in a)); nb = math.sqrt(sum(x * x for x in b))
    return sum(x * y for x, y in zip(a, b)) / (na * nb) if na and nb else 0.0


def cos_sparse(a, b):  # both already L2-normalised
    if len(a) > len(b):
        a, b = b, a
    return sum(v * b.get(k, 0.0) for k, v in a.items())


class Grouper:
    """Online, time-ordered grouping (same rules as the Kotlin IncidentGrouper)."""
    def __init__(self, text_thr=0.55, max_dist_m=250.0, max_gap_s=45 * 60, mode="combined"):
        self.t, self.d, self.g, self.mode = text_thr, max_dist_m, max_gap_s, mode

    def sim(self, r, grp):
        sem = cos_dense(r["concept"], grp["concept_sum"])
        lex = max(cos_sparse(r["vec"], m["vec"]) for m in grp["members"])
        return {"lexical": lex, "semantic": sem, "combined": max(sem, lex)}[self.mode]

    def run(self, reports):
        groups = []
        for r in sorted(reports, key=lambda x: x["time"]):
            best, best_s = None, 0.0
            for g in groups:
                if r["time"] - g["latest"] > self.g:
                    continue
                if r["loc"] is None or g["loc"] is None:
                    # conservative fallback: without a location, only the same sender's follow-ups are merged
                    if r["sender"] not in g["senders"]:
                        continue
                elif haversine(r["loc"], g["loc"]) > self.d:
                    continue
                s = self.sim(r, g)
                thr = self.t if r["category"] == g["category"] else max(self.t, 0.85)
                if s >= thr and s > best_s:
                    best, best_s = g, s
            if best is None:
                groups.append({"members": [r], "concept_sum": list(r["concept"]), "latest": r["time"],
                               "loc": r["loc"], "senders": {r["sender"]}, "category": r["category"]})
            else:
                best["members"].append(r)
                best["concept_sum"] = [a + b for a, b in zip(best["concept_sum"], r["concept"])]
                best["latest"] = max(best["latest"], r["time"])
                best["senders"].add(r["sender"])
                locs = [m["loc"] for m in best["members"] if m["loc"] is not None]
                best["loc"] = (sum(l[0] for l in locs) / len(locs), sum(l[1] for l in locs) / len(locs)) if locs else None
        return groups


def make_scenarios(pool, mm, n_scen=30, seed=0):
    rnd = random.Random(seed)
    cache = {}

    def enc(msg):
        if msg not in cache:
            v = mm.vector(msg)
            cache[msg] = (v, mm.probs("concept", v)[1])
        return cache[msg]

    by_sub = {k: g.message.tolist() for k, g in pool.groupby("subtype")}
    cat_of = dict(zip(pool.subtype, pool.category))
    subs_by_cat = {}
    for s, c in cat_of.items():
        subs_by_cat.setdefault(c, []).append(s)
    lat0, lon0 = 24.87, 91.40
    m_per_deg = 111000.0
    scen = []
    for _ in range(n_scen):
        reports, iid, sid = [], 0, 0

        def add_incident(sub, base, t0, k):
            nonlocal iid, sid
            for _ in range(k):
                msg = rnd.choice(by_sub[sub])
                v, c = enc(msg)
                ang, dist = rnd.uniform(0, 2 * math.pi), rnd.uniform(0, 150)
                loc = (base[0] + dist * math.cos(ang) / m_per_deg,
                       base[1] + dist * math.sin(ang) / (m_per_deg * math.cos(math.radians(base[0]))))
                if rnd.random() < 0.08:
                    loc = None  # GPS fix unavailable
                reports.append(dict(msg=msg, vec=v, concept=c, category=cat_of[sub], loc=loc,
                                    time=t0 + rnd.uniform(0, 25 * 60), incident=iid, sender=sid))
                sid += 1
            iid += 1

        for _ in range(rnd.randint(6, 10)):
            sub = rnd.choice(list(by_sub))
            base = (lat0 + rnd.uniform(0, 3000) / m_per_deg, lon0 + rnd.uniform(0, 3000) / m_per_deg)
            t0 = rnd.uniform(0, 7200)
            add_incident(sub, base, t0, rnd.randint(1, 6))
            if rnd.random() < 0.5:   # hard negative: different subtype, same category, close by
                others = [s for s in subs_by_cat[cat_of[sub]] if s != sub]
                if others:
                    d = rnd.uniform(120, 400) / m_per_deg
                    add_incident(rnd.choice(others), (base[0] + d, base[1]), t0 + rnd.uniform(-600, 600), rnd.randint(1, 3))
            if rnd.random() < 0.3:   # same subtype, far away
                add_incident(sub, (base[0] + 0.02, base[1] - 0.02), t0 + rnd.uniform(-600, 600), rnd.randint(1, 3))
        scen.append(reports)
    return scen


def pairwise(scenarios, grouper):
    tp = fp = fn = 0
    for reps in scenarios:
        gid = {}
        for k, g in enumerate(grouper.run(reps)):
            for m in g["members"]:
                gid[id(m)] = k
        for i in range(len(reps)):
            for j in range(i + 1, len(reps)):
                same_true = reps[i]["incident"] == reps[j]["incident"]
                same_pred = gid[id(reps[i])] == gid[id(reps[j])]
                tp += same_true and same_pred
                fp += (not same_true) and same_pred
                fn += same_true and (not same_pred)
    p = tp / (tp + fp) if tp + fp else 0.0
    r = tp / (tp + fn) if tp + fn else 0.0
    return dict(precision=p, recall=r, f1=2 * p * r / (p + r) if p + r else 0.0)


def main():
    mm = MeshModel(os.path.join(HERE, "models", "meshsos_classifier.bin"))
    df = pd.read_csv(os.path.join(HERE, "data", "meshsos_dataset.csv"), keep_default_na=False)
    val = make_scenarios(df[df.split == "val"], mm, seed=1)
    test = make_scenarios(df[df.split == "test"], mm, seed=2)
    out = {"tuning": {}, "test": {}}
    best = {}
    for mode in ["lexical", "semantic", "combined"]:
        cands = []
        for thr in [0.15, 0.25, 0.35, 0.45, 0.55, 0.65, 0.75]:
            for dist in [150.0, 250.0, 400.0]:
                r = pairwise(val, Grouper(thr, dist, 45 * 60, mode))
                cands.append(((thr, dist), r))
        (thr, dist), r = max(cands, key=lambda x: x[1]["f1"])
        best[mode] = {"text_threshold": thr, "max_distance_m": dist}
        out["tuning"][mode] = {"selected": best[mode], "val": r}
        out["test"][mode] = pairwise(test, Grouper(thr, dist, 45 * 60, mode))
    out["test"]["same_category_only_baseline"] = pairwise(test, Grouper(-1.0, 250.0, 45 * 60, "lexical"))
    with open(os.path.join(HERE, "reports", "grouping_metrics.json"), "w") as f:
        json.dump(out, f, indent=1)
    with open(os.path.join(HERE, "models", "grouping_config.json"), "w") as f:
        json.dump({"format": "meshsos-grouping-v1", "mode": "combined", **best["combined"],
                   "max_gap_minutes": 45, "cross_category_threshold": 0.85}, f, indent=1)
    print(json.dumps(out, indent=1))


if __name__ == "__main__":
    main()
