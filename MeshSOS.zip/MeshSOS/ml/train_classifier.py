"""
Train and evaluate the MeshSOS emergency classifier (AI-1 / AI-2 of the proposal).

  * Features: word uni/bigrams + character 2-4 grams inside word boundaries (featurizer.py)
  * Weighting: TF-IDF (sublinear tf, smoothed idf, L2 norm)
  * Heads: emergency type (7), severity (3), fine-grained concept (used as the
    semantic embedding for incident grouping, AI-5)
  * Baselines compared: TF-IDF + Logistic Regression vs TF-IDF + Linear SVM

Hyper-parameters are chosen with GroupKFold on train+val (groups = template id),
the final model is fitted on train+val, and the held-out test split is scored ONCE.

Outputs:
  ml/models/meshsos_classifier.bin   binary model read by the Kotlin core
  ml/models/golden_vectors.tsv       Python reference outputs for the Kotlin parity test
  ml/reports/classifier_report.md    metrics
  ml/reports/classifier_metrics.json
"""
import json
import os
import struct
import sys
import time

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, classification_report, confusion_matrix, f1_score,
                             precision_recall_fscore_support, recall_score)
from sklearn.model_selection import GroupKFold
from sklearn.svm import LinearSVC

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from featurizer import analyze  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data", "meshsos_dataset.csv")
CHALLENGE = os.path.join(HERE, "data", "challenge_set.csv")
MODELS = os.path.join(HERE, "models")
REPORTS = os.path.join(HERE, "reports")
TYPES = ["medical", "trapped", "fire", "flood", "food", "missing", "other"]
SEVS = ["critical", "high", "normal"]
THRESHOLD = 0.60
MAX_FEATURES = 20000


def make_vec():
    return TfidfVectorizer(analyzer=analyze, sublinear_tf=True, min_df=2, max_features=MAX_FEATURES,
                           norm="l2", smooth_idf=True, dtype=np.float64)


def group_cv(model_fn, texts, y, groups, k=5):
    scores = []
    for tr, va in GroupKFold(n_splits=k).split(texts, y, groups):
        v = make_vec()
        Xtr = v.fit_transform(texts[tr])
        m = model_fn().fit(Xtr, y[tr])
        scores.append(f1_score(y[va], m.predict(v.transform(texts[va])), average="macro"))
    return float(np.mean(scores))


def write_str(f, s):
    b = s.encode("utf-8")
    f.write(struct.pack(">i", len(b)))
    f.write(b)


def export_model(path, vec, heads):
    vocab = vec.vocabulary_
    feats = sorted(vocab, key=lambda t: vocab[t])
    idf = vec.idf_
    with open(path, "wb") as f:
        f.write(b"MSOSCLF1")
        f.write(struct.pack(">i", 1))  # format version
        f.write(struct.pack(">i", len(feats)))
        for i, t in enumerate(feats):
            write_str(f, t)
            f.write(struct.pack(">f", float(idf[i])))
        f.write(struct.pack(">i", len(heads)))
        for name, model in heads:
            classes = list(model.classes_)
            coef = model.coef_
            if coef.shape[0] == 1:  # binary LR stores one row; never the case here, kept for safety
                coef = np.vstack([-coef, coef])
            write_str(f, name)
            f.write(struct.pack(">i", len(classes)))
            for c in classes:
                write_str(f, str(c))
            f.write(coef.astype(">f4").tobytes(order="C"))
            f.write(model.intercept_.astype(">f4").tobytes())


def main():
    df = pd.read_csv(DATA, keep_default_na=False)
    dev = df[df.split != "test"].reset_index(drop=True)
    test = df[df.split == "test"].reset_index(drop=True)
    texts, groups = dev.message.values, dev.template_id.values
    y_type, y_sev = dev.category.values, dev.severity.values
    # CV uses single-language rows only: a mixed row contains two templates, so it could
    # leak a validation-fold template into the training fold.
    base = dev[dev.language != "mixed"]
    cv_texts, cv_groups, cv_y = base.message.values, base.template_id.values, base.category.values

    # ------------------------------------------------ model selection (grouped CV)
    cv = {}
    for C in [1.0, 4.0, 16.0]:
        cv[f"logreg_C{C}"] = group_cv(lambda: LogisticRegression(C=C, max_iter=3000, class_weight="balanced"),
                                      cv_texts, cv_y, cv_groups)
    for C in [0.1, 0.5, 2.0]:
        cv[f"linsvm_C{C}"] = group_cv(lambda: LinearSVC(C=C, class_weight="balanced"), cv_texts, cv_y, cv_groups)
    best_lr = max((k for k in cv if k.startswith("logreg")), key=cv.get)
    best_C = float(best_lr.split("C")[1])
    print("grouped CV macro-F1 (type):", json.dumps(cv, indent=1))

    # ------------------------------------------------ final fit on train+val
    vec = make_vec()
    X = vec.fit_transform(texts)
    lr_type = LogisticRegression(C=best_C, max_iter=4000, class_weight="balanced").fit(X, y_type)
    lr_sev = LogisticRegression(C=best_C, max_iter=4000, class_weight="balanced").fit(X, y_sev)
    lr_concept = LogisticRegression(C=best_C, max_iter=4000).fit(X, dev.subtype.values)
    best_svm = max((k for k in cv if k.startswith("linsvm")), key=cv.get)
    svm = LinearSVC(C=float(best_svm.split("C")[1]), class_weight="balanced").fit(X, y_type)

    # ------------------------------------------------ held-out test, scored once
    Xt = vec.transform(test.message.values)
    t0 = time.perf_counter()
    p_type = lr_type.predict_proba(Xt)
    per_msg_ms = (time.perf_counter() - t0) / len(test) * 1000
    pred_type = lr_type.classes_[p_type.argmax(1)]
    conf = p_type.max(1)
    pred_sev = lr_sev.predict(Xt)
    svm_pred = svm.predict(Xt)

    def block(y, p, labels):
        P, R, F, S = precision_recall_fscore_support(y, p, labels=labels, zero_division=0)
        return dict(accuracy=accuracy_score(y, p), macro_precision=float(P.mean()), macro_recall=float(R.mean()),
                    macro_f1=float(F.mean()),
                    per_class={l: dict(precision=float(P[i]), recall=float(R[i]), f1=float(F[i]), support=int(S[i]))
                               for i, l in enumerate(labels)})

    m = {"dataset": {"rows": len(df), "dev_rows": len(dev), "test_rows": len(test),
                     "test_templates": int(test.template_id.nunique())},
         "grouped_cv_type_macro_f1": cv, "selected": {"logreg_C": best_C, "svm": best_svm},
         "test_type_logreg": block(test.category.values, pred_type, TYPES),
         "test_type_linsvm": block(test.category.values, svm_pred, TYPES),
         "test_severity_logreg": block(test.severity.values, pred_sev, SEVS),
         "critical_recall": float(recall_score(test.severity.values, pred_sev, labels=["critical"], average="macro")),
         "confusion_type": {"labels": TYPES,
                            "matrix": confusion_matrix(test.category.values, pred_type, labels=TYPES).tolist()},
         "per_language_type_macro_f1": {}, "threshold": THRESHOLD,
         "python_inference_ms_per_message_batch": per_msg_ms,
         "n_features": len(vec.vocabulary_)}
    for lang in sorted(test.language.unique()):
        mask = test.language.values == lang
        m["per_language_type_macro_f1"][lang] = float(f1_score(test.category.values[mask], pred_type[mask],
                                                               labels=TYPES, average="macro", zero_division=0))
    covered = conf >= THRESHOLD
    m["coverage_at_threshold"] = float(covered.mean())
    m["macro_f1_on_covered"] = float(f1_score(test.category.values[covered], pred_type[covered], labels=TYPES,
                                              average="macro", zero_division=0))
    m["accuracy_on_unclassified"] = float((test.category.values[~covered] == pred_type[~covered]).mean()) \
        if (~covered).any() else None

    # ------------------------------------------------ independent hand-written challenge set
    ch = pd.read_csv(CHALLENGE, keep_default_na=False)
    Xc = vec.transform(ch.message.values)
    pc = lr_type.predict_proba(Xc)
    ch_pred = lr_type.classes_[pc.argmax(1)]
    ch_sev = lr_sev.predict(Xc)
    m["challenge"] = {"rows": len(ch),
                      "type": block(ch.category.values, ch_pred, TYPES),
                      "severity": block(ch.severity.values, ch_sev, SEVS),
                      "critical_recall": float(recall_score(ch.severity.values, ch_sev, labels=["critical"],
                                                            average="macro")),
                      "coverage_at_threshold": float((pc.max(1) >= THRESHOLD).mean())}
    ch_out = ch.copy()
    ch_out["pred_type"], ch_out["conf"], ch_out["pred_sev"] = ch_pred, pc.max(1).round(3), ch_sev
    ch_out.to_csv(os.path.join(REPORTS, "challenge_predictions.csv"), index=False)

    # ------------------------------------------------ export
    os.makedirs(MODELS, exist_ok=True)
    path = os.path.join(MODELS, "meshsos_classifier.bin")
    export_model(path, vec, [("type", lr_type), ("severity", lr_sev), ("concept", lr_concept)])
    m["model_bytes"] = os.path.getsize(path)
    # golden vectors for the Kotlin parity test
    sample = pd.concat([test.sample(40, random_state=1), ch.sample(20, random_state=1)]).message.values
    Xs = vec.transform(sample)
    with open(os.path.join(MODELS, "golden_vectors.tsv"), "w", encoding="utf-8") as f:
        f.write("message\ttype_probs\tseverity_probs\n")
        f.write("#classes\t" + ",".join(lr_type.classes_) + "\t" + ",".join(lr_sev.classes_) + "\n")
        for msg, a, b in zip(sample, lr_type.predict_proba(Xs), lr_sev.predict_proba(Xs)):
            f.write(msg.replace("\t", " ") + "\t" + ",".join(f"{v:.6f}" for v in a) + "\t" +
                    ",".join(f"{v:.6f}" for v in b) + "\n")

    with open(os.path.join(REPORTS, "classifier_metrics.json"), "w") as f:
        json.dump(m, f, indent=1)
    write_report(m, test, pred_type)
    print(json.dumps({k: m[k] for k in ["critical_recall", "coverage_at_threshold", "per_language_type_macro_f1",
                                        "model_bytes", "n_features"]}, indent=1))
    print("TEST type macro-F1 logreg=%.4f svm=%.4f  severity macro-F1=%.4f" % (
        m["test_type_logreg"]["macro_f1"], m["test_type_linsvm"]["macro_f1"], m["test_severity_logreg"]["macro_f1"]))
    print("CHALLENGE type macro-F1=%.4f severity macro-F1=%.4f crit-recall=%.4f" % (
        m["challenge"]["type"]["macro_f1"], m["challenge"]["severity"]["macro_f1"], m["challenge"]["critical_recall"]))
    print(classification_report(test.category.values, pred_type, digits=3))


def write_report(m, test, pred_type):
    t, s, c = m["test_type_logreg"], m["test_severity_logreg"], m["challenge"]
    L = ["# Classifier evaluation report", "",
         "Generated by `ml/train_classifier.py`. All numbers below were produced by actually running the script.",
         "The data is synthetic (see `ml/DATASET.md`), so these scores describe performance on *new template phrasings*,",
         "not on real disaster messages. Treat the challenge-set numbers as the more realistic estimate.", "",
         f"- Dataset rows: {m['dataset']['rows']} (dev {m['dataset']['dev_rows']}, held-out test {m['dataset']['test_rows']} "
         f"from {m['dataset']['test_templates']} templates never seen in training)",
         f"- Features: {m['n_features']} (word 1-2 grams + char 2-4 grams), model file {m['model_bytes']/1e6:.2f} MB",
         f"- Selected model: TF-IDF + multinomial logistic regression, C = {m['selected']['logreg_C']}", "",
         "## Grouped cross-validation on train+val (emergency type, macro F1)", "", "| Model | Macro F1 |", "|---|---|"]
    L += [f"| {k} | {v:.3f} |" for k, v in m["grouped_cv_type_macro_f1"].items()]
    L += ["", "## Held-out test set", "", "| Metric | Logistic regression | Linear SVM |", "|---|---|---|",
          f"| Type accuracy | {t['accuracy']:.3f} | {m['test_type_linsvm']['accuracy']:.3f} |",
          f"| Type macro precision | {t['macro_precision']:.3f} | {m['test_type_linsvm']['macro_precision']:.3f} |",
          f"| Type macro recall | {t['macro_recall']:.3f} | {m['test_type_linsvm']['macro_recall']:.3f} |",
          f"| **Type macro F1** (NFR2 target ≥ 0.80) | **{t['macro_f1']:.3f}** | {m['test_type_linsvm']['macro_f1']:.3f} |",
          "", f"- Severity macro F1: {s['macro_f1']:.3f}; accuracy {s['accuracy']:.3f}",
          f"- Critical-message recall: {m['critical_recall']:.3f}",
          f"- Share of test messages with confidence ≥ {m['threshold']:.2f} (not Unclassified): {m['coverage_at_threshold']:.3f}",
          f"- Macro F1 on those confident messages: {m['macro_f1_on_covered']:.3f}",
          "", "### Per-class (type, logistic regression)", "", "| Class | Precision | Recall | F1 | Support |", "|---|---|---|---|---|"]
    L += [f"| {k} | {v['precision']:.3f} | {v['recall']:.3f} | {v['f1']:.3f} | {v['support']} |" for k, v in t["per_class"].items()]
    L += ["", "### Per-language type macro F1", "", "| Language | Macro F1 |", "|---|---|"]
    L += [f"| {k} | {v:.3f} |" for k, v in m["per_language_type_macro_f1"].items()]
    L += ["", "### Confusion matrix (rows = true, columns = predicted)", "", "| | " + " | ".join(TYPES) + " |",
          "|---" * (len(TYPES) + 1) + "|"]
    for lab, row in zip(TYPES, m["confusion_type"]["matrix"]):
        L.append(f"| {lab} | " + " | ".join(map(str, row)) + " |")
    L += ["", "## Independent hand-written challenge set", "",
          f"{c['rows']} messages written separately from the templates, in a looser, more realistic style "
          "(dialect spellings such as *partese*, *lagse*, missing punctuation, code-mixing).", "",
          f"- Type macro F1: **{c['type']['macro_f1']:.3f}** (accuracy {c['type']['accuracy']:.3f})",
          f"- Severity macro F1: {c['severity']['macro_f1']:.3f}; critical recall {c['critical_recall']:.3f}",
          f"- Confident (≥ {m['threshold']:.2f}) share: {c['coverage_at_threshold']:.3f}",
          "- Row-level predictions: `ml/reports/challenge_predictions.csv`", "",
          "## Latency", "",
          f"Python batch inference: {m['python_inference_ms_per_message_batch']:.3f} ms per message on the build machine. "
          "On-device latency (NFR3) must be measured on a phone: open Settings → Diagnostics in the app, "
          "which times the Kotlin classifier on the bundled benchmark messages."]
    with open(os.path.join(REPORTS, "classifier_report.md"), "w") as f:
        f.write("\n".join(L) + "\n")


if __name__ == "__main__":
    main()
