"""
Text normalisation and feature extraction shared by training and by the Android
app. The Kotlin port lives in core/src/main/kotlin/com/meshsos/core/ai/TextFeaturizer.kt
and MUST stay byte-for-byte equivalent. Golden vectors exported by train_classifier.py
are checked by the Kotlin unit test ClassifierParityTest.
"""
import unicodedata

BN_DIGITS = "০১২৩৪৫৬৭৮৯"
CHAR_NGRAM_MIN = 2
CHAR_NGRAM_MAX = 4


def normalize(text: str) -> str:
    text = unicodedata.normalize("NFC", text).lower()
    out = []
    for ch in text:
        i = BN_DIGITS.find(ch)
        if i >= 0:
            out.append(str(i))
            continue
        cat = unicodedata.category(ch)
        if cat == "Cf":            # zero-width joiners etc.
            continue
        if cat[0] in ("L", "M") or cat == "Nd":
            out.append(ch)
        else:
            out.append(" ")
    return " ".join("".join(out).split())


def analyze(text: str):
    """Return the list of feature strings (with repeats) for one message."""
    norm = normalize(text)
    if not norm:
        return []
    toks = norm.split(" ")
    feats = []
    for t in toks:
        feats.append("w:" + t)
    for a, b in zip(toks, toks[1:]):
        feats.append("b:" + a + "_" + b)
    for t in toks:
        padded = " " + t + " "
        cps = list(padded)
        for n in range(CHAR_NGRAM_MIN, CHAR_NGRAM_MAX + 1):
            for i in range(0, len(cps) - n + 1):
                feats.append("c:" + "".join(cps[i:i + n]))
    return feats
