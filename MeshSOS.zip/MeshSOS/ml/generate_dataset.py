"""
MeshSOS synthetic emergency-message dataset generator.

IMPORTANT: every message produced by this script is SYNTHETIC. The templates
below were written with the help of a large language model during development
and then expanded with slot filling, spelling variation and code-mixing.
None of these sentences are real disaster reports. See ml/DATASET.md.

Leakage control: the train / val / test split is done on TEMPLATE ids, before
expansion. A test sentence is therefore never a re-filled copy of a training
template. Mixed-language examples are only built from templates that sit in
the same split.

Usage:  python3 ml/generate_dataset.py   (writes ml/data/meshsos_dataset.csv)
"""
import csv
import os
import random
import re

SEED = 20261125
rng = random.Random(SEED)

# ---------------------------------------------------------------- slot values
REL = {  # index-aligned across languages
    "en": ["father", "mother", "grandmother", "grandfather", "brother", "sister", "son",
           "daughter", "wife", "husband", "uncle", "neighbour", "baby", "child"],
    "bn": ["বাবা", "মা", "দাদি", "দাদা", "ভাই", "বোন", "ছেলে", "মেয়ে", "স্ত্রী", "স্বামী",
           "চাচা", "প্রতিবেশী", "বাচ্চা", "শিশু"],
    "bl": ["baba", "ma", "dadi", "dada", "bhai", "bon", "chele", "meye", "bou", "shami",
           "chacha", "protibeshi", "baccha", "shishu"],
}
PLACE = {
    "en": ["near the school", "in Ward 4", "behind the mosque", "next to the bazar",
           "by the river bank", "in the char area", "near the bridge", "at the camp",
           "near the union office", "on the east side of the village", ""],
    "bn": ["স্কুলের পাশে", "৪ নম্বর ওয়ার্ডে", "মসজিদের পিছনে", "বাজারের পাশে", "নদীর পাড়ে",
           "চরে", "ব্রিজের কাছে", "ক্যাম্পে", "ইউনিয়ন অফিসের কাছে", "গ্রামের পূর্ব দিকে", ""],
    "bl": ["school er pashe", "4 no ward e", "masjid er pichone", "bazar er pashe",
           "nodir pare", "chor e", "brij er kache", "camp e", "union office er kache",
           "gramer purbo dike", ""],
}
NUM_WORD = {
    "en": {2: "two", 3: "three", 4: "four", 5: "five", 6: "six", 7: "seven", 8: "eight", 10: "ten", 12: "twelve", 20: "twenty"},
    "bn": {2: "দুই", 3: "তিন", 4: "চার", 5: "পাঁচ", 6: "ছয়", 7: "সাত", 8: "আট", 10: "দশ", 12: "বারো", 20: "বিশ"},
    "bl": {2: "dui", 3: "tin", 4: "char", 5: "pach", 6: "choy", 7: "sat", 8: "at", 10: "dosh", 12: "baro", 20: "bish"},
}
BN_DIGITS = "০১২৩৪৫৬৭৮৯"


def render_num(n, lang):
    if lang in NUM_WORD and n in NUM_WORD[lang] and rng.random() < 0.35:
        return NUM_WORD[lang][n]
    s = str(n)
    if lang == "bn" and rng.random() < 0.75:
        s = "".join(BN_DIGITS[int(c)] for c in s)
    return s


# ---------------------------------------------------------------- templates
# subtype -> (category, {lang: [(severity, text), ...]})
C, H, N = "critical", "high", "normal"
T = {
 # ------------------------------------------------------------ MEDICAL
 "not_breathing": ("medical", {
   "en": [(C, "My {rel} has stopped breathing, please come fast"), (C, "{rel} is not breathing {place}"),
          (C, "Someone is not breathing here, we need a doctor now"), (C, "My {rel} can't breathe, help"),
          (C, "{rel} collapsed and is not breathing, we are {n} people {place}")],
   "bn": [(C, "আমার {rel} শ্বাস নিচ্ছে না, তাড়াতাড়ি আসেন"), (C, "{rel} শ্বাস নিতে পারছে না {place}"),
          (C, "একজন শ্বাস নিচ্ছে না, ডাক্তার লাগবে এখনই"), (C, "{rel} এর শ্বাস বন্ধ হয়ে গেছে, সাহায্য করেন"),
          (C, "আমরা {n} জন আছি, {rel} শ্বাস নিচ্ছে না")],
   "bl": [(C, "amar {rel} shash nicche na, taratari ashen"), (C, "{rel} shas nite parche na {place}"),
          (C, "ekjon shash nicche na, doctor lagbe ekhoni"), (C, "{rel} er shash bondho hoye geche, help koren"),
          (C, "amra {n} jon, {rel} shash nicche na")]}),
 "bleeding": ("medical", {
   "en": [(C, "{rel} is bleeding a lot from the head"), (C, "Heavy bleeding, my {rel} cut a leg on a tin sheet"),
          (C, "Blood won't stop, need first aid {place}"), (H, "{rel} has a deep cut and is bleeding")],
   "bn": [(C, "{rel} এর মাথা থেকে অনেক রক্ত পড়ছে"), (C, "রক্ত বন্ধ হচ্ছে না, ফার্স্ট এইড লাগবে {place}"),
          (H, "{rel} এর পা কেটে গেছে, রক্ত পড়ছে"), (C, "টিনে কেটে অনেক রক্ত যাচ্ছে")],
   "bl": [(C, "{rel} er matha theke onek rokto porche"), (C, "rokto bondho hocche na, first aid lagbe {place}"),
          (H, "{rel} er pa kete geche, rokto porche"), (C, "tin e kete onek rokto jacche")]}),
 "unconscious": ("medical", {
   "en": [(C, "{rel} fainted and is not waking up"), (C, "My {rel} is unconscious {place}"),
          (C, "He fell down and is not responding"), (C, "{rel} passed out an hour ago and still has not woken")],
   "bn": [(C, "{rel} অজ্ঞান হয়ে গেছে, জ্ঞান ফিরছে না"), (C, "{rel} বেহুঁশ হয়ে পড়ে আছে {place}"),
          (C, "পড়ে গিয়ে কোনো সাড়া দিচ্ছে না"), (C, "এক ঘণ্টা ধরে {rel} এর জ্ঞান নেই")],
   "bl": [(C, "{rel} ogyan hoye geche, gyan firche na"), (C, "{rel} behush hoye pore ache {place}"),
          (C, "pore giye kono sara dicche na"), (C, "ek ghonta dhore {rel} er gyan nai")]}),
 "chest_pain": ("medical", {
   "en": [(C, "{rel} has severe chest pain, maybe a heart attack"), (H, "Heart patient here needs help urgently"),
          (C, "My {rel} is sweating and holding the chest"), (H, "{rel} has chest pain and feels dizzy {place}")],
   "bn": [(C, "{rel} এর বুকে প্রচণ্ড ব্যথা, হার্ট অ্যাটাক মনে হচ্ছে"), (H, "হার্টের রোগী আছে, জরুরি সাহায্য দরকার"),
          (C, "{rel} বুক চেপে ধরে ঘামছে"), (H, "{rel} এর বুকে ব্যথা, মাথা ঘুরছে {place}")],
   "bl": [(C, "{rel} er buke prochondo betha, heart attack mone hocche"), (H, "heart er rogi ache, joruri sahajjo dorkar"),
          (C, "{rel} buk chepe dhore ghamche"), (H, "{rel} er buke betha, matha ghurche {place}")]}),
 "labour": ("medical", {
   "en": [(C, "My wife is in labour and there is no midwife"), (H, "A pregnant woman needs to go to hospital {place}"),
          (C, "Labour pain started and her water broke, help"), (H, "Pregnant woman with bleeding, nine months")],
   "bn": [(C, "আমার স্ত্রীর প্রসব ব্যথা উঠেছে, কোনো দাই নেই"), (H, "গর্ভবতী মহিলাকে হাসপাতালে নিতে হবে {place}"),
          (C, "পানি ভেঙে গেছে, ডেলিভারি হবে এখনই"), (H, "নয় মাসের গর্ভবতী, রক্ত যাচ্ছে")],
   "bl": [(C, "amar bou er proshob betha uthche, kono dai nai"), (H, "gorbhoboti mohila ke haspatal e nite hobe {place}"),
          (C, "pani bhenge geche, delivery hobe ekhoni"), (H, "noy masher gorbhoboti, rokto jacche")]}),
 "injury": ("medical", {
   "en": [(H, "{rel} broke a leg and can't walk"), (H, "Injured person here, arm may be broken {place}"),
          (H, "A tree branch fell on my {rel}, badly hurt"), (N, "{rel} twisted an ankle, needs a bandage")],
   "bn": [(H, "{rel} এর পা ভেঙে গেছে, হাঁটতে পারছে না"), (H, "আহত একজন আছে, হাত ভেঙেছে মনে হয় {place}"),
          (H, "গাছের ডাল পড়ে {rel} খুব আহত"), (N, "{rel} এর পা মচকে গেছে, ব্যান্ডেজ লাগবে")],
   "bl": [(H, "{rel} er pa bhenge geche, hatte parche na"), (H, "ahoto ekjon ache, hat bhengeche mone hoy {place}"),
          (H, "gacher dal pore {rel} khub ahoto"), (N, "{rel} er pa mochke geche, bandage lagbe")]}),
 "snake_bite": ("medical", {
   "en": [(C, "A snake bit my {rel}, we need anti venom"), (C, "Snakebite {place}, the leg is swelling"),
          (C, "Snake bite, {rel} is feeling sleepy and weak")],
   "bn": [(C, "{rel}কে সাপে কামড় দিয়েছে"), (C, "সাপে কেটেছে {place}, পা ফুলে যাচ্ছে"),
          (C, "সাপের কামড়, {rel} ঝিমিয়ে পড়ছে")],
   "bl": [(C, "{rel} ke shape kamor diyeche"), (C, "shape keteche {place}, pa fule jacche"),
          (C, "shaper kamor, {rel} jhimiye porche")]}),
 "sick": ("medical", {
   "en": [(H, "My baby has had a high fever for two days"), (H, "{rel} has diarrhoea and is very weak"),
          (H, "Child vomiting since morning, need saline"), (N, "An old man here has fever and cough {place}")],
   "bn": [(H, "বাচ্চার দুই দিন ধরে খুব জ্বর"), (H, "{rel} এর ডায়রিয়া হয়েছে, খুব দুর্বল"),
          (H, "সকাল থেকে বমি করছে, স্যালাইন লাগবে"), (N, "একজন বয়স্ক মানুষের জ্বর আর কাশি {place}")],
   "bl": [(H, "bacchar dui din dhore khub jor"), (H, "{rel} er diarrhea hoyeche, khub durbol"),
          (H, "sokal theke bomi korche, saline lagbe"), (N, "ekjon boyoshko manusher jor ar kashi {place}")]}),
 "medicine": ("medical", {
   "en": [(H, "We need insulin for my {rel}, diabetes patient"), (N, "Out of blood pressure medicine {place}"),
          (H, "Need an asthma inhaler urgently"), (N, "Need paracetamol and ORS for {n} people")],
   "bn": [(H, "{rel} ডায়াবেটিস রোগী, ইনসুলিন লাগবে"), (N, "প্রেশারের ওষুধ শেষ হয়ে গেছে {place}"),
          (H, "হাঁপানির ইনহেলার লাগবে জরুরি"), (N, "{n} জনের জন্য প্যারাসিটামল আর স্যালাইন লাগবে")],
   "bl": [(H, "{rel} diabetes rogi, insulin lagbe"), (N, "presher er oshudh shesh hoye geche {place}"),
          (H, "hapanir inhaler lagbe joruri"), (N, "{n} joner jonno paracetamol ar saline lagbe")]}),
 # ------------------------------------------------------------ TRAPPED
 "collapse": ("trapped", {
   "en": [(C, "Building collapsed, people are trapped under it {place}"), (C, "Our house fell down, my {rel} is under the rubble"),
          (C, "A wall collapsed and {n} people are stuck inside"), (C, "We can hear someone under the debris"),
          (C, "Roof caved in on my {rel}, cannot pull out")],
   "bn": [(C, "বিল্ডিং ধসে পড়েছে, নিচে মানুষ আটকা {place}"), (C, "আমাদের ঘর ভেঙে পড়েছে, {rel} ধ্বংসস্তূপের নিচে"),
          (C, "দেয়াল ধসে {n} জন ভেতরে আটকে আছে"), (C, "ইটের নিচ থেকে কারো আওয়াজ পাচ্ছি"),
          (C, "ছাদ ভেঙে {rel} এর উপর পড়েছে, বের করতে পারছি না")],
   "bl": [(C, "building dhose poreche, niche manush atka {place}"), (C, "amader ghor bhenge poreche, {rel} dhongshostuper niche"),
          (C, "deyal dhose {n} jon bhetore atke ache"), (C, "iter niche theke karo awaj pacchi"),
          (C, "chad bhenge {rel} er upor poreche, ber korte parchi na")]}),
 "landslide": ("trapped", {
   "en": [(C, "A landslide buried our house {place}"), (C, "{n} people are buried under the mud"),
          (C, "The hill came down on the houses, people trapped")],
   "bn": [(C, "পাহাড় ধসে আমাদের ঘর চাপা পড়েছে {place}"), (C, "{n} জন মাটির নিচে চাপা পড়েছে"),
          (C, "ভূমিধসে মানুষ আটকা পড়েছে")],
   "bl": [(C, "pahar dhose amader ghor chapa poreche {place}"), (C, "{n} jon matir niche chapa poreche"),
          (C, "bhumidhose manush atka poreche")]}),
 "stuck_inside": ("trapped", {
   "en": [(H, "The door is jammed, we are stuck inside the room"), (H, "We are trapped in the house, the stairs broke"),
          (H, "Stuck in the lift, power is gone {place}"), (H, "We are locked in, {n} people, cannot get out")],
   "bn": [(H, "দরজা আটকে গেছে, আমরা ঘরের ভেতরে আটকা"), (H, "সিঁড়ি ভেঙে গেছে, বাড়ির ভেতর আটকে আছি"),
          (H, "কারেন্ট নেই, লিফটে আটকে আছি {place}"), (H, "আমরা {n} জন ভেতরে আটকা, বের হতে পারছি না")],
   "bl": [(H, "dorja atke geche, amra ghorer bhetore atka"), (H, "siri bhenge geche, barir bhitor atke achi"),
          (H, "current nai, lift e atke achi {place}"), (H, "amra {n} jon bhitore atka, ber hote parchi na")]}),
 "pinned": ("trapped", {
   "en": [(C, "A tree fell on our car, my {rel} can't get out"), (C, "Bus overturned, passengers are stuck {place}"),
          (H, "Stuck under a fallen tree, leg pinned")],
   "bn": [(C, "গাছ পড়ে গাড়ির ভেতর {rel} আটকে গেছে"), (C, "বাস উল্টে গেছে, যাত্রীরা আটকা {place}"),
          (H, "পড়ে যাওয়া গাছের নিচে পা আটকে গেছে")],
   "bl": [(C, "gach pore garir bhitor {rel} atke geche"), (C, "bus ulte geche, jatrira atka {place}"),
          (H, "pore jawa gacher niche pa atke geche")]}),
 # ------------------------------------------------------------ FIRE
 "house_fire": ("fire", {
   "en": [(C, "Our house is on fire, my {rel} is still inside"), (C, "Fire in the building {place}, smoke everywhere"),
          (C, "House burning, {n} people need help"), (C, "There is a fire next door and it is spreading to our house")],
   "bn": [(C, "আমাদের ঘরে আগুন লেগেছে, {rel} এখনো ভেতরে"), (C, "বিল্ডিংয়ে আগুন {place}, সব জায়গায় ধোঁয়া"),
          (C, "বাড়ি পুড়ছে, {n} জনের সাহায্য দরকার"), (C, "পাশের বাড়িতে আগুন, আমাদের দিকে ছড়াচ্ছে")],
   "bl": [(C, "amader ghore agun legeche, {rel} ekhono bhetore"), (C, "building e agun {place}, shob jaygay dhoya"),
          (C, "bari purche, {n} joner sahajjo dorkar"), (C, "pasher barite agun, amader dike chorache")]}),
 "market_fire": ("fire", {
   "en": [(C, "Fire at the market {place}, shops are burning"), (C, "Shop fire spreading, please hurry"),
          (H, "A small fire started in a shop, we are trying to put it out")],
   "bn": [(C, "বাজারে আগুন {place}, দোকান পুড়ছে"), (C, "দোকানে আগুন ছড়িয়ে পড়ছে, তাড়াতাড়ি আসেন"),
          (H, "একটা দোকানে ছোট আগুন লেগেছে, নেভানোর চেষ্টা করছি")],
   "bl": [(C, "bazare agun {place}, dokan purche"), (C, "dokane agun choriye porche, taratari ashen"),
          (H, "ekta dokane choto agun legeche, nevanor chesta korchi")]}),
 "gas_electric": ("fire", {
   "en": [(H, "Strong gas smell in the kitchen, afraid it will explode"), (C, "An electric wire is sparking and caught fire"),
          (C, "Gas cylinder caught fire {place}")],
   "bn": [(H, "রান্নাঘরে গ্যাসের গন্ধ, বিস্ফোরণের ভয়"), (C, "বিদ্যুতের তারে আগুন ধরেছে"),
          (C, "গ্যাস সিলিন্ডারে আগুন {place}")],
   "bl": [(H, "rannaghore gas er gondho, bisphoron er bhoy"), (C, "biddut er tare agun dhoreche"),
          (C, "gas cylinder e agun {place}")]}),
 # ------------------------------------------------------------ FLOOD / WATER
 "water_rising": ("flood", {
   "en": [(H, "Water is rising fast inside our house"), (H, "Flood water is up to our waist {place}"),
          (N, "Water is entering the yard and may rise tonight"), (C, "Water is at neck level and the children can't swim"),
          (H, "Water keeps rising, we are {n} people")],
   "bn": [(H, "ঘরের ভেতর পানি দ্রুত বাড়ছে"), (H, "বন্যার পানি কোমর পর্যন্ত {place}"),
          (N, "উঠানে পানি ঢুকছে, রাতে বাড়তে পারে"), (C, "গলা পর্যন্ত পানি, বাচ্চারা সাঁতার জানে না"),
          (H, "পানি উঠছে, আমরা {n} জন")],
   "bl": [(H, "ghorer bhetor pani druto barche"), (H, "bonnar pani komor porjonto {place}"),
          (N, "uthane pani dhukche, rate barte pare"), (C, "gola porjonto pani, bacchara satar jane na"),
          (H, "pani uthche, amra {n} jon")]}),
 "need_boat": ("flood", {
   "en": [(H, "We need a boat, {n} people are cut off by flood water"), (H, "Please send a boat {place}"),
          (H, "The village is cut off by water, we need a boat rescue")],
   "bn": [(H, "নৌকা লাগবে, বন্যায় {n} জন আটকা"), (H, "{place} একটা নৌকা পাঠান"),
          (H, "পানিতে গ্রাম বিচ্ছিন্ন, নৌকা দরকার")],
   "bl": [(H, "nouka lagbe, bonnay {n} jon atka"), (H, "{place} ekta nouka pathan"),
          (H, "panite gram bicchinno, nouka dorkar")]}),
 "roof_stranded": ("flood", {
   "en": [(H, "We are on the roof with flood water all around, {n} people"), (C, "Water reached the roof, we have nowhere to go"),
          (H, "Stranded on the tin roof with my {rel}")],
   "bn": [(H, "আমরা ছাদে আছি, চারদিকে পানি, {n} জন"), (C, "পানি চাল পর্যন্ত উঠে গেছে, কোথাও যাওয়ার জায়গা নেই"),
          (H, "{rel}কে নিয়ে টিনের চালে বসে আছি, চারদিকে পানি")],
   "bl": [(H, "amra chade achi, chardike pani, {n} jon"), (C, "pani chal porjonto uthe geche, kothao jawar jayga nai"),
          (H, "{rel} ke niye tiner chale bose achi, chardike pani")]}),
 "swept_away": ("flood", {
   "en": [(C, "Someone was swept away by the current {place}"), (C, "My {rel} fell into the river and the current is strong"),
          (C, "A boat capsized, people are in the water")],
   "bn": [(C, "স্রোতে একজন ভেসে গেছে {place}"), (C, "{rel} নদীতে পড়ে গেছে, খুব স্রোত"),
          (C, "নৌকা ডুবে গেছে, মানুষ পানিতে")],
   "bl": [(C, "srote ekjon bhese geche {place}"), (C, "{rel} nodite pore geche, khub srot"),
          (C, "nouka dube geche, manush panite")]}),
 # ------------------------------------------------------------ FOOD AND WATER
 "no_food": ("food", {
   "en": [(H, "No food for two days, {n} people here"), (N, "We have run out of rice {place}"),
          (N, "Need food for {n} people at the shelter"), (H, "The children are hungry and there is nothing to eat")],
   "bn": [(H, "দুই দিন ধরে খাবার নেই, এখানে {n} জন"), (N, "চাল শেষ হয়ে গেছে {place}"),
          (N, "আশ্রয়কেন্দ্রে {n} জনের খাবার লাগবে"), (H, "বাচ্চারা ক্ষুধার্ত, খাওয়ার কিছু নেই")],
   "bl": [(H, "dui din dhore khabar nai, ekhane {n} jon"), (N, "chal shesh hoye geche {place}"),
          (N, "ashroykendre {n} joner khabar lagbe"), (H, "bacchara khudharto, khawar kichu nai")]}),
 "no_drinking_water": ("food", {
   "en": [(H, "No clean drinking water left {place}"), (N, "The tube well is under water, we need drinking water"),
          (N, "We need water purification tablets for {n} people")],
   "bn": [(H, "খাওয়ার পানি শেষ {place}"), (N, "টিউবওয়েল ডুবে গেছে, খাবার পানি লাগবে"),
          (N, "{n} জনের জন্য পানি বিশুদ্ধকরণ ট্যাবলেট লাগবে")],
   "bl": [(H, "khawar pani shesh {place}"), (N, "tubewell dube geche, khabar pani lagbe"),
          (N, "{n} joner jonno pani bishuddhokoron tablet lagbe")]}),
 "baby_food": ("food", {
   "en": [(H, "Need baby milk, my infant has had nothing since yesterday"), (H, "No formula milk for the baby {place}")],
   "bn": [(H, "বাচ্চার দুধ লাগবে, কাল থেকে কিছু খায়নি"), (H, "শিশুর জন্য গুঁড়া দুধ নেই {place}")],
   "bl": [(H, "bacchar dudh lagbe, kal theke kichu khayni"), (H, "shishur jonno gura dudh nai {place}")]}),
 # ------------------------------------------------------------ MISSING PERSON
 "missing_child": ("missing", {
   "en": [(H, "I cannot find my son, he is {age} years old {place}"), (H, "Our child went missing during the evacuation"),
          (H, "A little girl is lost near the river, wearing a red dress"), (H, "My daughter is missing, she is {age} years old")],
   "bn": [(H, "আমার মেয়েকে খুঁজে পাচ্ছি না, বয়স {age} বছর"), (H, "ছেলেটা হারিয়ে গেছে {place}"),
          (H, "সরানোর সময় বাচ্চা হারিয়ে গেছে"), (H, "লাল জামা পরা একটা মেয়ে নদীর পাশে হারিয়ে গেছে")],
   "bl": [(H, "amar meye ke khuje pacchi na, boyosh {age} bochor"), (H, "chele ta hariye geche {place}"),
          (H, "soranor somoy baccha hariye geche"), (H, "lal jama pora ekta meye nodir pashe hariye geche")]}),
 "missing_adult": ("missing", {
   "en": [(H, "My {rel} has been missing since last night"), (N, "Has anyone seen an old man in a white panjabi? He is lost"),
          (H, "We lost contact with {n} family members {place}")],
   "bn": [(H, "কাল রাত থেকে {rel} নিখোঁজ"), (N, "সাদা পাঞ্জাবি পরা একজন বৃদ্ধ হারিয়ে গেছেন, কেউ দেখেছেন?"),
          (H, "{n} জন আত্মীয়ের খোঁজ পাচ্ছি না {place}")],
   "bl": [(H, "kal rat theke {rel} nikhoj"), (N, "sada panjabi pora ekjon briddho hariye gechen, keu dekhechen?"),
          (H, "{n} jon attiyer khoj pacchi na {place}")]}),
 # ------------------------------------------------------------ OTHER
 "shelter": ("other", {
   "en": [(N, "We need a place to stay, our house is gone, {n} people"), (N, "Where is the nearest shelter?"),
          (N, "The shelter is full and people are sleeping outside {place}")],
   "bn": [(N, "থাকার জায়গা লাগবে, ঘর নেই, {n} জন"), (N, "সবচেয়ে কাছের আশ্রয়কেন্দ্র কোথায়?"),
          (N, "আশ্রয়কেন্দ্র ভরে গেছে, মানুষ বাইরে ঘুমাচ্ছে {place}")],
   "bl": [(N, "thakar jayga lagbe, ghor nai, {n} jon"), (N, "sobcheye kacher ashroykendro kothay?"),
          (N, "ashroykendro bhore geche, manush baire ghumacche {place}")]}),
 "road_blocked": ("other", {
   "en": [(N, "The road is blocked by fallen trees {place}"), (N, "The bridge is broken, there is no way to cross"),
          (N, "Electric pole fell across the road {place}")],
   "bn": [(N, "গাছ পড়ে রাস্তা বন্ধ {place}"), (N, "ব্রিজ ভেঙে গেছে, পার হওয়ার উপায় নেই"),
          (N, "রাস্তায় বিদ্যুতের খুঁটি পড়ে আছে {place}")],
   "bl": [(N, "gach pore rasta bondho {place}"), (N, "brij bhenge geche, par howar upay nai"),
          (N, "rastay biddut er khuti pore ache {place}")]}),
 "info_power": ("other", {
   "en": [(N, "Need a way to charge phones, battery almost dead"), (N, "Any news about when relief will come?"),
          (N, "Is anyone from the rescue team nearby?")],
   "bn": [(N, "ফোন চার্জ দেওয়ার ব্যবস্থা লাগবে"), (N, "ত্রাণ কখন আসবে কেউ জানেন?"),
          (N, "উদ্ধারকারী দলের কেউ কাছে আছেন?")],
   "bl": [(N, "phone charge dewar bebostha lagbe"), (N, "tran kokhon ashbe keu janen?"),
          (N, "uddharkari doler keu kache achen?")]}),
 "livestock": ("other", {
   "en": [(N, "Our cows are stuck in the water"), (N, "Need help moving the goats to high ground")],
   "bn": [(N, "গরুগুলো পানিতে আটকা পড়েছে"), (N, "ছাগলগুলো উঁচু জায়গায় নিতে সাহায্য লাগবে")],
   "bl": [(N, "goru gulo panite atka poreche"), (N, "chagol gulo uchu jaygay nite sahajjo lagbe")]}),
 "safe_status": ("other", {
   "en": [(N, "We are safe at the shelter, just letting you know"), (N, "Everyone in our family is okay {place}")],
   "bn": [(N, "আমরা আশ্রয়কেন্দ্রে নিরাপদ আছি"), (N, "পরিবারের সবাই ভালো আছে {place}")],
   "bl": [(N, "amra ashroykendre nirapod achi"), (N, "poribarer shobai bhalo ache {place}")]}),
}

# ---------------------------------------------------------------- dataset v2: extra paraphrases
# Added after the v1 evaluation showed too little phrasing diversity per subtype. Two to three
# extra phrasings were written for EVERY subtype and language (not only the ones that failed),
# so the held-out templates are still phrasings the model has never seen.
T_EXTRA = {
 "not_breathing": {
   "en": [(C, "{rel} stopped breathing a minute ago, someone come"), (C, "No breath, lips turning blue, my {rel} needs help"),
          (C, "Please, {rel} is choking and can't get air")],
   "bn": [(C, "{rel} এর দম বন্ধ হয়ে আসছে, ঠোঁট নীল হয়ে যাচ্ছে"), (C, "এক মিনিট ধরে {rel} নিঃশ্বাস নিচ্ছে না"),
          (C, "গলায় কিছু আটকে {rel} শ্বাস নিতে পারছে না")],
   "bl": [(C, "{rel} er dom bondho hoye ashche, thot nil hoye jacche"), (C, "ek minute dhore {rel} nisshash nicche na"),
          (C, "golay kichu atke {rel} shash nite parche na")]},
 "bleeding": {
   "en": [(C, "Lots of blood coming out, {rel} is getting pale"), (H, "{rel} is cut by broken glass and bleeding")],
   "bn": [(C, "অনেক রক্ত বের হচ্ছে, {rel} ফ্যাকাশে হয়ে যাচ্ছে"), (H, "কাঁচে কেটে {rel} এর রক্ত পড়ছে")],
   "bl": [(C, "onek rokto ber hocche, {rel} fakashe hoye jacche"), (H, "kach e kete {rel} er rokto porche")]},
 "unconscious": {
   "en": [(C, "{rel} is lying on the floor and won't open the eyes"), (C, "We can't wake {rel} up")],
   "bn": [(C, "{rel} মেঝেতে পড়ে আছে, চোখ খুলছে না"), (C, "{rel} কে কিছুতেই জাগাতে পারছি না")],
   "bl": [(C, "{rel} mejhete pore ache, chokh khulche na"), (C, "{rel} ke kichutei jagate parchi na")]},
 "chest_pain": {
   "en": [(C, "{rel} says the chest feels tight and the left arm hurts"), (H, "Old heart patient feeling pain again {place}")],
   "bn": [(C, "{rel} বলছে বুক চাপ লাগছে, বাম হাতে ব্যথা"), (H, "পুরনো হার্টের রোগীর আবার ব্যথা উঠেছে {place}")],
   "bl": [(C, "{rel} bolche buk chap lagche, bam hate betha"), (H, "purono heart er rogir abar betha uthche {place}")]},
 "labour": {
   "en": [(C, "Baby is coming, mother is in a lot of pain"), (H, "Pregnant lady needs a midwife {place}")],
   "bn": [(C, "বাচ্চা হবে এখন, মা খুব কষ্ট পাচ্ছে"), (H, "গর্ভবতী মায়ের জন্য ধাত্রী লাগবে {place}")],
   "bl": [(C, "baccha hobe ekhon, ma khub koshto pacche"), (H, "gorbhoboti mayer jonno dhattri lagbe {place}")]},
 "injury": {
   "en": [(H, "{rel} fell from the roof and hurt the back"), (H, "Burns on the hand from hot oil, needs treatment")],
   "bn": [(H, "{rel} ছাদ থেকে পড়ে কোমরে ব্যথা পেয়েছে"), (H, "গরম তেলে হাত পুড়ে গেছে, চিকিৎসা লাগবে")],
   "bl": [(H, "{rel} chad theke pore komore betha peyeche"), (H, "gorom tele hat pure geche, chikitsha lagbe")]},
 "snake_bite": {
   "en": [(C, "{rel} was bitten by a snake in the field")],
   "bn": [(C, "মাঠে {rel}কে সাপে কেটেছে")],
   "bl": [(C, "mathe {rel} ke shape keteche")]},
 "sick": {
   "en": [(H, "{rel} is shivering with fever and vomiting"), (N, "Several people have stomach problems {place}")],
   "bn": [(H, "{rel} জ্বরে কাঁপছে আর বমি করছে"), (N, "কয়েকজনের পেটের সমস্যা হচ্ছে {place}")],
   "bl": [(H, "{rel} jore kapche ar bomi korche"), (N, "koyekjoner peter somossha hocche {place}")]},
 "medicine": {
   "en": [(N, "Running out of regular medicines for {rel}"), (H, "Need epilepsy tablets today, none left")],
   "bn": [(N, "{rel} এর নিয়মিত ওষুধ শেষ হয়ে আসছে"), (H, "মৃগীর ওষুধ আজই লাগবে, একটাও নেই")],
   "bl": [(N, "{rel} er niyomito oshudh shesh hoye ashche"), (H, "mrigir oshudh aji lagbe, ektao nai")]},
 "collapse": {
   "en": [(C, "The concrete roof fell, {n} people are under it"), (C, "Someone is calling for help from under the broken wall")],
   "bn": [(C, "ঢালাই ছাদ পড়ে গেছে, নিচে {n} জন"), (C, "ভাঙা দেয়ালের নিচ থেকে কেউ সাহায্য চাইছে")],
   "bl": [(C, "dhalai chad pore geche, niche {n} jon"), (C, "bhanga deyaler niche theke keu sahajjo caiche")]},
 "landslide": {
   "en": [(C, "Mud covered the house, my {rel} is inside")],
   "bn": [(C, "কাদায় ঘর ঢেকে গেছে, {rel} ভেতরে")],
   "bl": [(C, "kaday ghor dheke geche, {rel} bhetore")]},
 "stuck_inside": {
   "en": [(H, "Debris is blocking our door, we can't get out"), (H, "We are trapped upstairs, {n} of us")],
   "bn": [(H, "দরজার সামনে ভাঙা জিনিস, বের হতে পারছি না"), (H, "আমরা উপরের তলায় আটকে আছি, {n} জন")],
   "bl": [(H, "dorjar samne bhanga jinish, ber hote parchi na"), (H, "amra uporer tolay atke achi, {n} jon")]},
 "pinned": {
   "en": [(C, "A beam fell on my {rel}, the legs are stuck")],
   "bn": [(C, "{rel} এর পায়ের উপর বিম পড়েছে, আটকে আছে")],
   "bl": [(C, "{rel} er payer upor beam poreche, atke ache")]},
 "house_fire": {
   "en": [(C, "Flames in the kitchen, the whole house is filling with smoke"), (C, "Our tin shed is burning {place}")],
   "bn": [(C, "রান্নাঘরে আগুনের শিখা, পুরো ঘর ধোঁয়ায় ভরে যাচ্ছে"), (C, "আমাদের টিনের ঘর জ্বলছে {place}")],
   "bl": [(C, "rannaghore aguner shikha, puro ghor dhoyay bhore jacche"), (C, "amader tiner ghor jolche {place}")]},
 "market_fire": {
   "en": [(C, "Big fire in the warehouse {place}")],
   "bn": [(C, "গুদামে বড় আগুন {place}")],
   "bl": [(C, "gudam e boro agun {place}")]},
 "gas_electric": {
   "en": [(H, "Short circuit and burning smell from the meter box")],
   "bn": [(H, "মিটার বক্সে শর্ট সার্কিট, পোড়া গন্ধ")],
   "bl": [(H, "meter box e short circuit, pora gondho")]},
 "water_rising": {
   "en": [(H, "The river is overflowing into the houses {place}"), (N, "Water level going up slowly near our home")],
   "bn": [(H, "নদীর পানি বাড়িঘরে ঢুকে পড়েছে {place}"), (N, "বাড়ির কাছে পানি আস্তে আস্তে বাড়ছে")],
   "bl": [(H, "nodir pani barighore dhuke poreche {place}"), (N, "barir kache pani aste aste barche")]},
 "need_boat": {
   "en": [(H, "Send a rescue boat for {n} people, the road is under water")],
   "bn": [(H, "রাস্তা পানির নিচে, {n} জনের জন্য উদ্ধার নৌকা পাঠান")],
   "bl": [(H, "rasta panir niche, {n} joner jonno uddhar nouka pathan")]},
 "roof_stranded": {
   "en": [(H, "Flooded all around, we climbed onto the roof {place}")],
   "bn": [(H, "চারদিকে বন্যা, আমরা চালে উঠে বসে আছি {place}")],
   "bl": [(H, "chardike bonna, amra chale uthe bose achi {place}")]},
 "swept_away": {
   "en": [(C, "{rel} was pulled away by the flood water")],
   "bn": [(C, "বন্যার পানিতে {rel} ভেসে গেছে")],
   "bl": [(C, "bonnar panite {rel} bhese geche")]},
 "no_food": {
   "en": [(H, "We have nothing to eat since yesterday {place}"), (N, "Please bring dry food, rice and lentils")],
   "bn": [(H, "গতকাল থেকে কিছু খাইনি {place}"), (N, "শুকনো খাবার, চাল ডাল নিয়ে আসেন")],
   "bl": [(H, "gotokal theke kichu khaini {place}"), (N, "shukno khabar, chal dal niye ashen")]},
 "no_drinking_water": {
   "en": [(H, "Kids are thirsty, no safe water to drink"), (N, "Need drinking water bottles {place}")],
   "bn": [(H, "বাচ্চাদের পিপাসা, খাওয়ার মতো পানি নেই"), (N, "খাওয়ার পানির বোতল লাগবে {place}")],
   "bl": [(H, "bacchader pipasha, khawar moto pani nai"), (N, "khawar panir botol lagbe {place}")]},
 "baby_food": {
   "en": [(H, "The infant is hungry, we need milk powder")],
   "bn": [(H, "শিশুটা ক্ষুধায় কাঁদছে, দুধ লাগবে")],
   "bl": [(H, "shishu ta khudhay kandche, dudh lagbe")]},
 "missing_child": {
   "en": [(H, "Our {age} year old boy has not come back since the water came")],
   "bn": [(H, "পানি আসার পর থেকে আমাদের {age} বছরের ছেলেটা ফেরেনি")],
   "bl": [(H, "pani ashar por theke amader {age} bochorer chele ta fereni")]},
 "missing_adult": {
   "en": [(H, "Nobody knows where my {rel} is since the storm"), (N, "Looking for my {rel}, last seen at the shelter")],
   "bn": [(H, "ঝড়ের পর থেকে {rel} কোথায় কেউ জানে না"), (N, "{rel} কে খুঁজছি, শেষ দেখা গেছে আশ্রয়কেন্দ্রে")],
   "bl": [(H, "jhorer por theke {rel} kothay keu jane na"), (N, "{rel} ke khujchi, shesh dekha geche ashroykendre")]},
 "shelter": {
   "en": [(N, "Our home is destroyed, we need tents for {n} people")],
   "bn": [(N, "ঘর নষ্ট হয়ে গেছে, {n} জনের জন্য তাঁবু লাগবে")],
   "bl": [(N, "ghor nosto hoye geche, {n} joner jonno tabu lagbe")]},
 "road_blocked": {
   "en": [(N, "The way to the hospital is closed by a landslide")],
   "bn": [(N, "হাসপাতালে যাওয়ার রাস্তা মাটি পড়ে বন্ধ")],
   "bl": [(N, "haspatal e jawar rasta mati pore bondho")]},
 "info_power": {
   "en": [(N, "Does anyone have a power bank to share?")],
   "bn": [(N, "কারো কাছে পাওয়ার ব্যাংক আছে?")],
   "bl": [(N, "karo kache power bank ache?")]},
 "livestock": {
   "en": [(N, "Our chickens and ducks are drowning, can someone help")],
   "bn": [(N, "হাঁস মুরগি ডুবে যাচ্ছে, কেউ সাহায্য করবেন")],
   "bl": [(N, "has murgi dube jacche, keu sahajjo korben")]},
 "safe_status": {
   "en": [(N, "We reached the cyclone centre safely")],
   "bn": [(N, "আমরা নিরাপদে সাইক্লোন সেন্টারে পৌঁছেছি")],
   "bl": [(N, "amra nirapode cyclone center e pouchechi")]},
}
for _st, _by_lang in T_EXTRA.items():
    for _lang, _items in _by_lang.items():
        T[_st][1][_lang].extend(_items)

PREFIX = {"en":["", "", "", "Help! ", "Please help. ", "Urgent: ", "SOS ", "pls "],
          "bn": ["", "", "", "সাহায্য করেন! ", "জরুরি, ", "দয়া করে, "],
          "bl": ["", "", "", "help! ", "plz ", "joruri, ", "doya kore "]}
SUFFIX = {"en": ["", "", " please", " hurry", "!!", "."],
          "bn": ["", "", " তাড়াতাড়ি", " দয়া করে", "।"],
          "bl": ["", "", " taratari", " please", " jaldi", "!!"]}

# Banglish spelling variation (people write Bangla in Latin letters inconsistently)
BL_SWAPS = [("sh", "s"), ("kh", "k"), ("ch", "c"), ("oo", "u"), ("ee", "i"), ("o", "u"), ("a", "o"),
            ("bh", "v"), ("ph", "f"), ("j", "z"), ("w", "o")]
# English words commonly dropped into Bangla-script sentences
BN_TO_EN_WORDS = {"ডাক্তার": "doctor", "সাহায্য": "help", "হাসপাতালে": "hospital e", "জরুরি": "urgent",
                  "নৌকা": "boat", "আগুন": "fire", "পানি": "water", "খাবার": "food", "রক্ত": "blood",
                  "তাড়াতাড়ি": "fast", "বাচ্চা": "baby", "ফোন": "phone"}


def banglish_noise(text):
    words = text.split(" ")
    out = []
    for w in words:
        if rng.random() < 0.25 and len(w) > 3:
            a, b = rng.choice(BL_SWAPS)
            if a in w:
                w = w.replace(a, b, 1)
        out.append(w)
    return " ".join(out)


def english_typo(text):
    words = text.split(" ")
    for i, w in enumerate(words):
        if len(w) > 4 and rng.random() < 0.06:
            j = rng.randrange(1, len(w) - 1)
            words[i] = w[:j] + w[j + 1:]  # drop a letter
    return " ".join(words)


def fill(template, lang, ri, n, age, place_i):
    t = template
    t = t.replace("{rel}", REL[lang][ri])
    t = t.replace("{place}", PLACE[lang][place_i])
    t = t.replace("{age}", render_num(age, lang) if lang != "en" else str(age))
    t = t.replace("{n}", render_num(n, lang))
    t = re.sub(r"\s+", " ", t).strip()
    t = re.sub(r"\s+([,.?!।])", r"\1", t)
    if t and lang == "en":
        t = t[0].upper() + t[1:]
    return t


def decorate(text, lang):
    p = rng.choice(PREFIX[lang])
    s = rng.choice(SUFFIX[lang])
    if s and text.endswith((".", "!", "?", "।")) and s in (".", "।", "!!"):
        s = ""
    t = p + text + s
    if lang == "bl":
        t = banglish_noise(t)
        if rng.random() < 0.3:
            t = t.lower()
    elif lang == "en":
        t = english_typo(t)
        if rng.random() < 0.15:
            t = t.lower()
    elif lang == "bn" and rng.random() < 0.25:
        for k, v in BN_TO_EN_WORDS.items():
            if k in t and rng.random() < 0.6:
                t = t.replace(k, v)
    return t


def assign_split(idx, count):
    # one template per (subtype, language) goes to test, one more to val when there are >= 4
    if idx == 2 or (count == 2 and idx == 1):
        return "test"
    if count >= 4 and idx == count - 1 and idx != 2:
        return "val"
    return "train"


def main():
    rows, base = [], []
    for subtype, (cat, by_lang) in T.items():
        for lang, items in by_lang.items():
            for i, (sev, text) in enumerate(items):
                tid = f"{subtype}:{lang}:{i}"
                base.append(dict(tid=tid, subtype=subtype, cat=cat, lang=lang, sev=sev, text=text,
                                 split=assign_split(i, len(items))))
    per_template = 8
    for b in base:
        has_n = "{n}" in b["text"]
        for _ in range(per_template):
            n = rng.choice([2, 3, 3, 4, 5, 6, 7, 8, 10, 12, 20])
            ri = rng.randrange(len(REL["en"]))
            age = rng.choice([4, 5, 6, 7, 8, 9, 10, 12])
            pi = rng.randrange(len(PLACE["en"]))
            msg = decorate(fill(b["text"], b["lang"], ri, n, age, pi), b["lang"])
            rows.append(dict(message=msg, language={"en": "english", "bn": "bangla", "bl": "banglish"}[b["lang"]],
                             category=b["cat"], severity=b["sev"], people_count=n if has_n else "",
                             subtype=b["subtype"], template_id=b["tid"], split=b["split"],
                             source="synthetic_template_v1"))
    # code-mixed examples: a Bangla or Banglish clause joined to an English clause of the same subtype and split
    sev_rank = {"normal": 0, "high": 1, "critical": 2}
    by_key = {}
    for b in base:
        by_key.setdefault((b["subtype"], b["split"], b["lang"]), []).append(b)
    for (subtype, split, lang), items in list(by_key.items()):
        if lang == "en":
            continue
        ens = by_key.get((subtype, split, "en"), [])
        if not ens:
            continue
        for _ in range(2 * len(items)):
            a, e = rng.choice(items), rng.choice(ens)
            n = rng.choice([2, 3, 4, 5, 6, 8])
            ri = rng.randrange(len(REL["en"]))
            pi = rng.randrange(len(PLACE["en"]))
            age = rng.choice([5, 6, 7, 9])
            p1 = fill(a["text"], a["lang"], ri, n, age, pi)
            p2 = fill(e["text"], "en", ri, n, age, len(PLACE["en"]) - 1)
            joiner = rng.choice([". ", ", ", " - ", " । "])
            msg = (p1 + joiner + p2) if rng.random() < 0.6 else (p2 + joiner + p1)
            sev = max(a["sev"], e["sev"], key=lambda s: sev_rank[s])
            has_n = "{n}" in a["text"] or "{n}" in e["text"]
            rows.append(dict(message=msg, language="mixed", category=a["cat"], severity=sev,
                             people_count=n if has_n else "", subtype=subtype,
                             template_id=a["tid"] + "+" + e["tid"], split=split, source="synthetic_mixed_v1"))
    # exact-duplicate removal (keep first)
    seen, final = set(), []
    for r in rows:
        k = r["message"].strip().lower()
        if k in seen:
            continue
        seen.add(k)
        final.append(r)
    rng.shuffle(final)
    out = os.path.join(os.path.dirname(__file__), "data", "meshsos_dataset.csv")
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(final[0].keys()))
        w.writeheader()
        w.writerows(final)
    from collections import Counter
    print("templates:", len(base), "rows:", len(final))
    print("splits:", Counter(r["split"] for r in final))
    print("languages:", Counter(r["language"] for r in final))
    print("categories:", Counter(r["category"] for r in final))
    print("severity:", Counter(r["severity"] for r in final))


if __name__ == "__main__":
    main()
