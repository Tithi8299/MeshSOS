package com.meshsos.core.ai

import com.meshsos.core.model.Severity
import com.meshsos.core.packet.Packet
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

/**
 * Link / device conditions at the moment a packet is about to be sent.
 * null means "not measured" and is handled explicitly (never silently treated as perfect).
 */
data class LinkContext(val selfBattery: Float?, val linkQuality: Float?) {
    companion object { val UNKNOWN = LinkContext(null, null) }
}

/** AI-4: forwarding order. Higher score = sent first. */
interface PriorityScorer {
    fun score(p: Packet, nowMillis: Long, link: LinkContext, enqueuedAtMillis: Long): Double

    /**
     * Battery-aware relaying: below 15 % battery this phone still sends its own messages and
     * relays critical/high ones, but stops relaying routine traffic for others.
     */
    fun shouldSend(p: Packet, nowMillis: Long, link: LinkContext, enqueuedAtMillis: Long): Boolean {
        val b = link.selfBattery ?: return true
        val relayed = p.hopCount > 0
        return !(relayed && b < 0.15f && p.severity == Severity.NORMAL)
    }

    companion object {
        /** Fairness: every minute in the queue adds 0.35, capped at 4.0, so routine messages are never starved. */
        fun aging(nowMillis: Long, enqueuedAtMillis: Long, perMinute: Double = 0.35, cap: Double = 4.0): Double =
            min(cap, perMinute * max(0L, nowMillis - enqueuedAtMillis) / 60_000.0)

        fun severityWeight(s: Severity) = when (s) { Severity.CRITICAL -> 3.0; Severity.HIGH -> 1.6; Severity.NORMAL -> 0.5 }
    }
}

/** Transparent baseline and app default (chosen from the 20-seed simulation, sim/results/summary.txt). */
class RulePriorityScorer(private val agingPerMin: Double = 0.35, private val agingCap: Double = 4.0) : PriorityScorer {
    override fun score(p: Packet, nowMillis: Long, link: LinkContext, enqueuedAtMillis: Long): Double =
        PriorityScorer.severityWeight(p.severity) + PriorityScorer.aging(nowMillis, enqueuedAtMillis, agingPerMin, agingCap)
}

/**
 * Logistic-regression scorer trained on simulator outcomes (sim/train_priority.py).
 * score = utility(severity) * P(transmission is useful) + aging.
 * Unknown battery / link quality fall back to the means used in simulation (0.6 / 0.75).
 */
class LearnedPriorityScorer(
    private val weights: Map<String, Double>,
    private val bias: Double,
    private val utility: Map<Severity, Double>,
    private val agingPerMin: Double = 0.35,
    private val agingCap: Double = 4.0,
) : PriorityScorer {
    fun pUseful(p: Packet, nowMillis: Long, link: LinkContext): Double {
        val ageMin = max(0L, nowMillis - p.createdAtMillis) / 60_000.0
        val x = mapOf(
            "sev_critical" to if (p.severity == Severity.CRITICAL) 1.0 else 0.0,
            "sev_high" to if (p.severity == Severity.HIGH) 1.0 else 0.0,
            "age_norm" to min(ageMin, 30.0) / 30.0,
            "hops_norm" to min(p.hopCount, 10) / 10.0,
            "battery" to (link.selfBattery?.toDouble() ?: 0.6),
            "link_quality" to (link.linkQuality?.toDouble() ?: 0.75),
        )
        val z = bias + weights.entries.sumOf { (k, w) -> w * (x[k] ?: 0.0) }
        return 1.0 / (1.0 + exp(-z))
    }

    override fun score(p: Packet, nowMillis: Long, link: LinkContext, enqueuedAtMillis: Long): Double =
        (utility[p.severity] ?: 1.0) * pUseful(p, nowMillis, link) +
            PriorityScorer.aging(nowMillis, enqueuedAtMillis, agingPerMin, agingCap)

    companion object {
        @Suppress("UNCHECKED_CAST")
        fun fromJson(json: String): LearnedPriorityScorer {
            val m = MiniJson.parse(json) as Map<String, Any?>
            require(m["format"] == "meshsos-priority-v1") { "unknown priority model format" }
            val w = (m["weights"] as Map<String, Any?>).mapValues { (it.value as Number).toDouble() }
            val u = (m["severity_utility"] as Map<String, Any?>).entries
                .associate { Severity.fromLabel(it.key) to (it.value as Number).toDouble() }
            return LearnedPriorityScorer(w, (m["bias"] as Number).toDouble(), u,
                (m["aging_per_min"] as Number).toDouble(), (m["aging_cap"] as Number).toDouble())
        }
    }
}

/** Minimal JSON reader for the small model / config files (keeps the core free of dependencies). */
object MiniJson {
    fun parse(s: String): Any? = P(s).run { val v = value(); ws(); require(i == s.length) { "trailing json" }; v }

    private class P(val s: String) {
        var i = 0
        fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
        fun value(): Any? {
            ws()
            require(i < s.length) { "unexpected end" }
            return when (val c = s[i]) {
                '{' -> obj(); '[' -> arr(); '"' -> str()
                't' -> lit("true", true); 'f' -> lit("false", false); 'n' -> lit("null", null)
                else -> if (c == '-' || c.isDigit()) num() else throw IllegalArgumentException("bad json at $i")
            }
        }
        fun lit(w: String, v: Any?): Any? { require(s.startsWith(w, i)); i += w.length; return v }
        fun num(): Double {
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] in "+-.eE")) i++
            return s.substring(st, i).toDouble()
        }
        fun str(): String {
            val sb = StringBuilder(); i++
            while (true) {
                val c = s[i++]
                when (c) {
                    '"' -> return sb.toString()
                    '\\' -> when (val e = s[i++]) {
                        'n' -> sb.append('\n'); 't' -> sb.append('\t'); 'r' -> sb.append('\r'); 'b' -> sb.append('\b')
                        'f' -> sb.append('\u000C'); 'u' -> { sb.append(s.substring(i, i + 4).toInt(16).toChar()); i += 4 }
                        else -> sb.append(e)
                    }
                    else -> sb.append(c)
                }
            }
        }
        fun arr(): List<Any?> {
            val out = ArrayList<Any?>(); i++; ws()
            if (s[i] == ']') { i++; return out }
            while (true) { out += value(); ws(); if (s[i++] == ']') return out }
        }
        fun obj(): Map<String, Any?> {
            val out = LinkedHashMap<String, Any?>(); i++; ws()
            if (s[i] == '}') { i++; return out }
            while (true) {
                ws(); val k = str(); ws(); require(s[i++] == ':'); out[k] = value(); ws()
                if (s[i++] == '}') return out
            }
        }
    }
}
