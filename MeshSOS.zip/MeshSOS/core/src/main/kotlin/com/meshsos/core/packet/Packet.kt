package com.meshsos.core.packet

import com.meshsos.core.model.Category
import com.meshsos.core.model.PacketType
import com.meshsos.core.model.ReceiptKind
import com.meshsos.core.model.Severity

/**
 * One mesh packet, format version [Packet.WIRE_VERSION].
 *
 * Signed fields: everything except [ttl], [hopCount], [lastHopId] and [signature] itself.
 * Those three are rewritten by every relay. [originalTtl] is signed, so a relay can never push
 * the TTL above what the sender set; together with the seen-ID table this rules out loops.
 *
 * IDs are lowercase hex: messageId = 16 random bytes, node IDs = first 16 bytes of
 * SHA-256(Ed25519 public key). A node therefore cannot claim another node's ID without its key.
 */
data class Packet(
    val type: PacketType,
    val messageId: String,
    val senderId: String,
    val senderSigningKey: ByteArray,     // Ed25519 public key (32 bytes)
    val senderAgreementKey: ByteArray,   // X25519 public key (32 bytes): lets anyone reply privately
    val senderName: String,
    val createdAtMillis: Long,
    val originalTtl: Int,
    val ttl: Int,
    val hopCount: Int = 0,
    val lastHopId: String? = null,
    val recipientId: String? = null,     // DIRECT_TEXT and RECEIPT only
    val category: Category = Category.UNCLASSIFIED,
    val severity: Severity = Severity.NORMAL,
    val peopleCount: Int = 0,            // 0 = not stated
    val aiConfidence: Float = 0f,
    val userEdited: Boolean = false,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val accuracyMeters: Float? = null,
    val text: String = "",               // plaintext for SOS / BROADCAST_TEXT, empty otherwise
    val ciphertext: ByteArray? = null,   // DIRECT_TEXT: AES-GCM(iv || ct || tag)
    val ephemeralKey: ByteArray? = null, // DIRECT_TEXT: sender's one-time X25519 public key
    val refMessageId: String? = null,    // RECEIPT: the message being acknowledged
    val receiptKind: ReceiptKind? = null,
    val isRescuer: Boolean = false,      // HELLO / RECEIPT: self-declared rescuer endpoint
    val batteryPercent: Int = -1,        // HELLO: -1 = unknown
    val signature: ByteArray = ByteArray(0),
) {
    val hasLocation: Boolean get() = latitude != null && longitude != null

    /** Copy prepared by a relay: one hop used up. Signature stays valid (mutable fields are unsigned). */
    fun forwardedBy(relayId: String): Packet = copy(ttl = ttl - 1, hopCount = hopCount + 1, lastHopId = relayId)

    // ByteArray fields need content equality for tests and de-duplication logic.
    override fun equals(other: Any?): Boolean =
        other is Packet && messageId == other.messageId && ttl == other.ttl && hopCount == other.hopCount &&
            lastHopId == other.lastHopId && signature.contentEquals(other.signature) &&
            runCatching { PacketCodec.signingBytes(this).contentEquals(PacketCodec.signingBytes(other)) }.getOrDefault(false)

    override fun hashCode(): Int = messageId.hashCode()

    companion object {
        const val WIRE_VERSION = 1
        const val MAX_TEXT_CHARS = 1000
        const val MAX_NAME_CHARS = 40
        const val MAX_WIRE_BYTES = 30_000   // Nearby BYTES payloads are limited to ~32 KB
        const val MAX_TTL = 16
        const val DEFAULT_TTL = 6
    }
}
