package com.meshsos.core.ai

import com.meshsos.core.geo.Geo
import com.meshsos.core.model.Category
import com.meshsos.core.model.Severity
import kotlin.math.sqrt

/** One received SOS as seen by the grouper. */
data class Report(
    val id: String,
    val senderId: String,
    val text: String,
    val category: Category,
    val severity: Severity,
    val peopleCount: Int,
    val latitude: Double?,
    val longitude: Double?,
    val timeMillis: Long,
    val concept: FloatArray,
    val vector: SparseVector,
)

data class Incident(
    val id: String,
    val category: Category,
    val combinedSeverity: Severity,
    val reports: List<Report>,
    val latitude: Double?,
    val longitude: Double?,
    val latestMillis: Long,
    val peopleCount: Int,
    /** Mean similarity of each joined report to its group when it joined (1.0 for single reports). */
    val meanSimilarity: Double,
) {
    val reportCount get() = reports.size
}

data class GroupingConfig(
    val textThreshold: Double = 0.25,
    val maxDistanceMeters: Double = 250.0,
    val maxGapMillis: Long = 45L * 60_000,
    val crossCategoryThreshold: Double = 0.85,
) {
    companion object {
        @Suppress("UNCHECKED_CAST")
        fun fromJson(json: String): GroupingConfig {
            val m = MiniJson.parse(json) as Map<String, Any?>
            require(m["format"] == "meshsos-grouping-v1")
            return GroupingConfig((m["text_threshold"] as Number).toDouble(), (m["max_distance_m"] as Number).toDouble(),
                (m["max_gap_minutes"] as Number).toLong() * 60_000, (m["cross_category_threshold"] as Number).toDouble())
        }
    }
}

/**
 * AI-5: groups reports that describe the same real-world emergency (port of ml/grouping_eval.py).
 *
 * Text similarity = max(cosine of concept-probability embeddings, TF-IDF cosine). The concept
 * embedding is language-independent ("baba shash nicche na" and "my father stopped breathing"
 * land on the same concept), the TF-IDF part catches near-identical wording.
 * A report joins the most similar open group only if it is also close in space and time; a
 * different category needs much stronger text evidence; and a report WITHOUT a location is only
 * merged with follow-ups from the same sender (conservative fallback).
 */
class IncidentGrouper(private val cfg: GroupingConfig = GroupingConfig()) {
    private class Open(val first: Report) {
        val members = arrayListOf(first)
        val conceptSum = first.concept.copyOf()
        var latest = first.timeMillis
        val senders = hashSetOf(first.senderId)
        var lat: Double? = first.latitude
        var lon: Double? = first.longitude
        var simSum = 0.0
        fun add(r: Report, sim: Double) {
            members += r; senders += r.senderId; simSum += sim
            for (k in conceptSum.indices) conceptSum[k] += r.concept.getOrElse(k) { 0f }
            latest = maxOf(latest, r.timeMillis)
            val located = members.filter { it.latitude != null && it.longitude != null }
            if (located.isNotEmpty()) {
                lat = located.sumOf { it.latitude!! } / located.size
                lon = located.sumOf { it.longitude!! } / located.size
            }
        }
    }

    fun similarity(a: Report, b: Report): Double = maxOf(cosine(a.concept, b.concept), a.vector.dot(b.vector))

    fun group(reports: List<Report>): List<Incident> {
        val open = ArrayList<Open>()
        for (r in reports.sortedBy { it.timeMillis }) {
            var best: Open? = null; var bestSim = 0.0
            for (g in open) {
                if (r.timeMillis - g.latest > cfg.maxGapMillis) continue
                val rLat = r.latitude; val rLon = r.longitude; val gLat = g.lat; val gLon = g.lon
                if (rLat == null || rLon == null || gLat == null || gLon == null) {
                    if (r.senderId !in g.senders) continue
                } else if (Geo.distanceMeters(rLat, rLon, gLat, gLon) > cfg.maxDistanceMeters) continue
                val sim = maxOf(cosine(r.concept, g.conceptSum), g.members.maxOf { r.vector.dot(it.vector) })
                val sameCat = r.category == g.first.category
                val thr = if (sameCat) cfg.textThreshold else maxOf(cfg.textThreshold, cfg.crossCategoryThreshold)
                if (sim >= thr && sim > bestSim) { best = g; bestSim = sim }
            }
            if (best == null) open += Open(r) else best.add(r, bestSim)
        }
        return open.map { g ->
            Incident(
                id = g.first.id,
                category = g.members.map { it.category }.firstOrNull { it != Category.UNCLASSIFIED } ?: Category.UNCLASSIFIED,
                combinedSeverity = g.members.map { it.severity }.reduce { a, b -> Severity.max(a, b) },
                reports = g.members.sortedByDescending { it.timeMillis },
                latitude = g.lat, longitude = g.lon, latestMillis = g.latest,
                peopleCount = g.members.maxOf { it.peopleCount },
                meanSimilarity = if (g.members.size > 1) g.simSum / (g.members.size - 1) else 1.0,
            )
        }
    }

    companion object {
        fun cosine(a: FloatArray, b: FloatArray): Double {
            if (a.isEmpty() || a.size != b.size) return 0.0
            var d = 0.0; var na = 0.0; var nb = 0.0
            for (i in a.indices) { d += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i] }
            return if (na > 0 && nb > 0) d / (sqrt(na) * sqrt(nb)) else 0.0
        }
    }
}
