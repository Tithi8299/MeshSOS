package com.meshsos.core.geo

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.asin
import kotlin.math.sin
import kotlin.math.sqrt

/** Offline distance and direction (FR13). No map service is involved. */
object Geo {
    private const val EARTH_RADIUS_M = 6_371_000.0

    /** Great-circle (haversine) distance in metres. */
    fun distanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val p1 = Math.toRadians(lat1); val p2 = Math.toRadians(lat2)
        val dp = p2 - p1; val dl = Math.toRadians(lon2 - lon1)
        val h = sin(dp / 2) * sin(dp / 2) + cos(p1) * cos(p2) * sin(dl / 2) * sin(dl / 2)
        return 2 * EARTH_RADIUS_M * asin(sqrt(h.coerceIn(0.0, 1.0)))
    }

    /** Initial bearing from point 1 to point 2, degrees clockwise from true north, in [0, 360). */
    fun bearingDegrees(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val p1 = Math.toRadians(lat1); val p2 = Math.toRadians(lat2); val dl = Math.toRadians(lon2 - lon1)
        val y = sin(dl) * cos(p2)
        val x = cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl)
        return (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0
    }

    enum class Compass { N, NE, E, SE, S, SW, W, NW }

    fun compass(bearing: Double): Compass = Compass.entries[(((bearing % 360 + 360) % 360 + 22.5) / 45.0).toInt() % 8]

    /** "420 m" / "1.1 km" - matches the prototype's style. */
    fun formatDistance(m: Double): String = when {
        m < 1000 -> "${(m / 10).toInt() * 10} m"
        m < 10_000 -> String.format(java.util.Locale.US, "%.1f km", m / 1000)
        else -> "${(m / 1000).toInt()} km"
    }
}
