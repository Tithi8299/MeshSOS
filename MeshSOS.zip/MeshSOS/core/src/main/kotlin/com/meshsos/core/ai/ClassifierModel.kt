package com.meshsos.core.ai

import java.io.DataInputStream
import java.io.InputStream
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sqrt

/** L2-normalised sparse TF-IDF vector. */
class SparseVector(val indices: IntArray, val values: FloatArray) {
    fun dot(o: SparseVector): Double {
        val small = if (indices.size <= o.indices.size) this else o
        val big = if (small === this) o else this
        val map = HashMap<Int, Float>(big.indices.size * 2)
        for (k in big.indices.indices) map[big.indices[k]] = big.values[k]
        var s = 0.0
        for (k in small.indices.indices) s += small.values[k] * (map[small.indices[k]] ?: 0f)
        return s
    }
    val isEmpty get() = indices.isEmpty()
}

/**
 * Reader for ml/models/meshsos_classifier.bin (format "MSOSCLF1", big-endian):
 * vocabulary + idf, then one multinomial logistic-regression head per output
 * ("type", "severity", "concept"). Inference is a sparse dot product and a softmax, so it runs
 * in a few milliseconds on a phone without any ML runtime.
 */
class ClassifierModel private constructor(
    private val index: HashMap<String, Int>,
    private val idf: FloatArray,
    val heads: Map<String, Head>,
) {
    class Head(val classes: List<String>, val coef: FloatArray, val intercept: FloatArray, val nFeatures: Int)

    val featureCount get() = idf.size

    fun vectorize(text: String): SparseVector {
        val counts = HashMap<Int, Int>()
        for (f in TextFeaturizer.analyze(text)) {
            val i = index[f] ?: continue
            counts[i] = (counts[i] ?: 0) + 1
        }
        val idx = counts.keys.sorted().toIntArray()
        val vals = FloatArray(idx.size)
        var norm = 0.0
        for (k in idx.indices) {
            val v = (1.0 + ln(counts[idx[k]]!!.toDouble())) * idf[idx[k]]
            vals[k] = v.toFloat(); norm += v * v
        }
        norm = sqrt(norm)
        if (norm > 0) for (k in vals.indices) vals[k] = (vals[k] / norm).toFloat()
        return SparseVector(idx, vals)
    }

    fun probabilities(head: String, v: SparseVector): FloatArray {
        val h = heads[head] ?: throw IllegalArgumentException("no head $head")
        val z = DoubleArray(h.classes.size)
        for (c in z.indices) {
            var s = h.intercept[c].toDouble()
            val base = c * h.nFeatures
            for (k in v.indices.indices) s += h.coef[base + v.indices[k]] * v.values[k]
            z[c] = s
        }
        val m = z.max()
        var sum = 0.0
        for (c in z.indices) { z[c] = exp(z[c] - m); sum += z[c] }
        return FloatArray(z.size) { (z[it] / sum).toFloat() }
    }

    companion object {
        fun load(input: InputStream): ClassifierModel {
            val i = DataInputStream(input.buffered())
            val magic = ByteArray(8).also { i.readFully(it) }
            require(String(magic, Charsets.US_ASCII) == "MSOSCLF1") { "not a MeshSOS classifier file" }
            val version = i.readInt()
            require(version == 1) { "unsupported model version $version" }
            val nf = i.readInt()
            val index = HashMap<String, Int>(nf * 2)
            val idf = FloatArray(nf)
            for (k in 0 until nf) { index[readStr(i)] = k; idf[k] = i.readFloat() }
            val heads = LinkedHashMap<String, Head>()
            repeat(i.readInt()) {
                val name = readStr(i)
                val nc = i.readInt()
                val classes = List(nc) { readStr(i) }
                val coef = FloatArray(nc * nf) { i.readFloat() }
                val inter = FloatArray(nc) { i.readFloat() }
                heads[name] = Head(classes, coef, inter, nf)
            }
            return ClassifierModel(index, idf, heads)
        }

        private fun readStr(i: DataInputStream): String {
            val n = i.readInt()
            require(n in 0..10_000)
            return String(ByteArray(n).also { i.readFully(it) }, Charsets.UTF_8)
        }
    }
}
