package com.meshsos.core.model

/** Packet kinds carried over the mesh. Codes are part of the wire format: never renumber. */
enum class PacketType(val code: Int) {
    HELLO(1),          // identity announcement to direct neighbours only (never forwarded)
    SOS(2),            // public emergency broadcast
    BROADCAST_TEXT(3), // public short text to everyone nearby
    DIRECT_TEXT(4),    // encrypted one-to-one text
    RECEIPT(5);        // RELAYED / DELIVERED acknowledgement travelling back to the origin

    companion object {
        fun fromCode(c: Int): PacketType = entries.firstOrNull { it.code == c }
            ?: throw IllegalArgumentException("unknown packet type $c")
    }
}

enum class Category(val code: Int, val modelLabel: String) {
    MEDICAL(1, "medical"), TRAPPED(2, "trapped"), FIRE(3, "fire"), FLOOD(4, "flood"),
    FOOD(5, "food"), MISSING(6, "missing"), OTHER(7, "other"), UNCLASSIFIED(0, "unclassified");

    companion object {
        fun fromCode(c: Int): Category = entries.firstOrNull { it.code == c }
            ?: throw IllegalArgumentException("unknown category $c")
        fun fromLabel(l: String): Category = entries.firstOrNull { it.modelLabel == l } ?: UNCLASSIFIED
    }
}

enum class Severity(val code: Int, val rank: Int, val modelLabel: String) {
    CRITICAL(1, 2, "critical"), HIGH(2, 1, "high"), NORMAL(3, 0, "normal");

    companion object {
        fun fromCode(c: Int): Severity = entries.firstOrNull { it.code == c }
            ?: throw IllegalArgumentException("unknown severity $c")
        fun fromLabel(l: String): Severity = entries.firstOrNull { it.modelLabel == l } ?: NORMAL
        fun max(a: Severity, b: Severity): Severity = if (a.rank >= b.rank) a else b
    }
}

enum class ReceiptKind(val code: Int) {
    RELAYED(1), DELIVERED(2);

    companion object {
        fun fromCode(c: Int): ReceiptKind = entries.firstOrNull { it.code == c }
            ?: throw IllegalArgumentException("unknown receipt kind $c")
    }
}

/** Sender-side lifecycle shown on the Delivery status screen (FR9). */
enum class DeliveryStatus(val code: Int) {
    QUEUED(0),     // stored on this phone, no neighbour has accepted it yet
    SENT(1),       // Nearby Connections reported a successful transfer to >= 1 neighbour
    RELAYED(2),    // a signed RELAYED receipt came back from another phone
    DELIVERED(3);  // a signed DELIVERED receipt came back from the recipient / a rescuer phone

    companion object {
        fun fromCode(c: Int) = entries.first { it.code == c }
    }
}
