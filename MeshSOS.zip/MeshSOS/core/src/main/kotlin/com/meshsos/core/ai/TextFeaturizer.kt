package com.meshsos.core.ai

import java.text.Normalizer

/**
 * Kotlin port of ml/featurizer.py. The two MUST produce identical feature strings; the
 * ClassifierParityTest checks this against golden vectors exported by the training script.
 */
object TextFeaturizer {
    private const val BN_DIGITS = "০১২৩৪৫৬৭৮৯"
    private const val CHAR_MIN = 2
    private const val CHAR_MAX = 4

    fun normalize(text: String): String {
        val s = Normalizer.normalize(text, Normalizer.Form.NFC).lowercase()
        val sb = StringBuilder(s.length)
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            i += Character.charCount(cp)
            val d = BN_DIGITS.indexOf(String(Character.toChars(cp)))
            if (d >= 0) { sb.append(('0'.code + d).toChar()); continue }
            when (Character.getType(cp)) {
                Character.FORMAT.toInt() -> {}
                Character.UPPERCASE_LETTER.toInt(), Character.LOWERCASE_LETTER.toInt(),
                Character.TITLECASE_LETTER.toInt(), Character.MODIFIER_LETTER.toInt(),
                Character.OTHER_LETTER.toInt(), Character.NON_SPACING_MARK.toInt(),
                Character.ENCLOSING_MARK.toInt(), Character.COMBINING_SPACING_MARK.toInt(),
                Character.DECIMAL_DIGIT_NUMBER.toInt() -> sb.appendCodePoint(cp)
                else -> sb.append(' ')
            }
        }
        return sb.toString().split(' ').filter { it.isNotEmpty() }.joinToString(" ")
    }

    /** Feature strings with repeats, in the same order as the Python analyzer. */
    fun analyze(text: String): List<String> {
        val norm = normalize(text)
        if (norm.isEmpty()) return emptyList()
        val toks = norm.split(' ')
        val out = ArrayList<String>(toks.size * 12)
        for (t in toks) out += "w:$t"
        for (k in 0 until toks.size - 1) out += "b:${toks[k]}_${toks[k + 1]}"
        for (t in toks) {
            val cps = " $t ".codePoints().toArray()
            for (n in CHAR_MIN..CHAR_MAX) {
                for (s in 0..cps.size - n) out += "c:" + String(cps, s, n)
            }
        }
        return out
    }
}
