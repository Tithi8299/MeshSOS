package com.meshsos.core.crypto

import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

object Hex {
    private val DIGITS = "0123456789abcdef".toCharArray()
    fun encode(b: ByteArray): String {
        val out = CharArray(b.size * 2)
        for (i in b.indices) {
            val v = b[i].toInt() and 0xff
            out[2 * i] = DIGITS[v ushr 4]; out[2 * i + 1] = DIGITS[v and 0x0f]
        }
        return String(out)
    }
    fun decode(s: String): ByteArray {
        require(s.length % 2 == 0) { "odd hex length" }
        return ByteArray(s.length / 2) { i ->
            val hi = Character.digit(s[2 * i], 16); val lo = Character.digit(s[2 * i + 1], 16)
            require(hi >= 0 && lo >= 0) { "bad hex" }
            ((hi shl 4) or lo).toByte()
        }
    }
}

class KeyPairBytes(val publicKey: ByteArray, val privateKey: ByteArray)

/**
 * The two elliptic-curve primitives MeshSOS needs. Android below API 33 has neither Ed25519 nor
 * X25519 in the platform JCA, so the app implements this with Google Tink
 * (app/.../security/TinkCurveProvider.kt). Unit tests use the JDK implementation
 * (core/src/test/.../JdkCurveProvider.kt). Both use raw RFC 8032 / RFC 7748 32-byte keys,
 * so keys and signatures are interchangeable between the two.
 */
interface CurveProvider {
    fun newSigningKeyPair(): KeyPairBytes                 // Ed25519, private = 32-byte seed
    fun sign(privateKey: ByteArray, message: ByteArray): ByteArray
    fun verify(publicKey: ByteArray, message: ByteArray, signature: ByteArray): Boolean
    fun newAgreementKeyPair(): KeyPairBytes               // X25519
    fun agree(privateKey: ByteArray, peerPublicKey: ByteArray): ByteArray
}

/** Hashing, HKDF and AES-GCM from javax.crypto, which Android supports at API 26. */
object Primitives {
    private val random = SecureRandom()
    const val GCM_IV_BYTES = 12
    const val GCM_TAG_BITS = 128

    fun randomBytes(n: Int): ByteArray = ByteArray(n).also { random.nextBytes(it) }
    fun sha256(data: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(data)

    fun hmacSha256(key: ByteArray, data: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(if (key.isEmpty()) ByteArray(32) else key, "HmacSHA256"))
        return mac.doFinal(data)
    }

    /** RFC 5869 HKDF-SHA256. */
    fun hkdf(ikm: ByteArray, salt: ByteArray, info: ByteArray, length: Int): ByteArray {
        require(length in 1..255 * 32)
        val prk = hmacSha256(salt, ikm)
        val out = ByteArray(length)
        var t = ByteArray(0); var pos = 0; var counter = 1
        while (pos < length) {
            t = hmacSha256(prk, t + info + byteArrayOf(counter.toByte()))
            val n = minOf(t.size, length - pos)
            System.arraycopy(t, 0, out, pos, n)
            pos += n; counter++
        }
        return out
    }

    /** AES-256-GCM with a fresh random 96-bit IV. Output = iv || ciphertext || tag. */
    fun aesGcmEncrypt(key: ByteArray, plaintext: ByteArray, aad: ByteArray): ByteArray {
        require(key.size == 32)
        val iv = randomBytes(GCM_IV_BYTES)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(GCM_TAG_BITS, iv))
        c.updateAAD(aad)
        return iv + c.doFinal(plaintext)
    }

    /** Throws [javax.crypto.AEADBadTagException] (a GeneralSecurityException) if anything was altered. */
    fun aesGcmDecrypt(key: ByteArray, data: ByteArray, aad: ByteArray): ByteArray {
        require(key.size == 32 && data.size > GCM_IV_BYTES + 16)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(GCM_TAG_BITS, data, 0, GCM_IV_BYTES))
        c.updateAAD(aad)
        return c.doFinal(data, GCM_IV_BYTES, data.size - GCM_IV_BYTES)
    }
}
