package com.meshsos.core.crypto

import com.meshsos.core.packet.Packet
import com.meshsos.core.packet.PacketCodec
import java.security.GeneralSecurityException

/** This phone's long-term identity. Generated once on first launch; never hard-coded. */
class Identity(
    val signing: KeyPairBytes,
    val agreement: KeyPairBytes,
    /** Shown to nearby phones; can be changed in Settings at any time. */
    @Volatile var displayName: String,
) {
    val nodeId: String = nodeIdFor(signing.publicKey)

    companion object {
        fun generate(curves: CurveProvider, displayName: String) =
            Identity(curves.newSigningKeyPair(), curves.newAgreementKeyPair(), displayName)

        /** Self-certifying node ID: first 16 bytes of SHA-256(Ed25519 public key), hex. */
        fun nodeIdFor(signingPublicKey: ByteArray): String =
            Hex.encode(Primitives.sha256(signingPublicKey).copyOf(16))

        /**
         * Safety code people compare face to face to verify a contact (stops a nearby phone from
         * passing off its own keys as someone else's). 12 digits from both nodes' keys, order-independent.
         */
        fun safetyCode(aSigningKey: ByteArray, bSigningKey: ByteArray): String {
            val (x, y) = listOf(aSigningKey, bSigningKey).sortedBy { Hex.encode(it) }
            val h = Primitives.sha256("MeshSOS-safety-v1".toByteArray() + x + y)
            val n = ((h[0].toLong() and 0xff) shl 32) or ((h[1].toLong() and 0xff) shl 24) or
                ((h[2].toLong() and 0xff) shl 16) or ((h[3].toLong() and 0xff) shl 8) or (h[4].toLong() and 0xff)
            val digits = (n % 1_000_000_000_000L).toString().padStart(12, '0')
            return digits.chunked(4).joinToString(" ")
        }
    }
}

class PacketSigner(private val curves: CurveProvider) {
    fun sign(unsigned: Packet, identity: Identity): Packet {
        require(unsigned.senderId == identity.nodeId) { "sender id does not match identity" }
        val sig = curves.sign(identity.signing.privateKey, PacketCodec.signingBytes(unsigned))
        return unsigned.copy(signature = sig)
    }

    /** True only if the signature is valid AND the sender ID really belongs to the embedded key. */
    fun verify(p: Packet): Boolean {
        if (p.signature.size != 64) return false
        if (Identity.nodeIdFor(p.senderSigningKey) != p.senderId) return false
        return try {
            curves.verify(p.senderSigningKey, PacketCodec.signingBytes(p), p.signature)
        } catch (e: GeneralSecurityException) {
            false
        }
    }
}

/**
 * Private one-to-one messages (FR11).
 *
 * For every message the sender makes a fresh X25519 key pair (ephemeral-static ECDH with the
 * recipient's long-term X25519 key), derives a one-time AES-256 key with HKDF-SHA256 and
 * encrypts with AES-GCM. Because each message has its own key, a random 96-bit IV can never
 * repeat under the same key. The packet header (ids) is bound as associated data, and the
 * whole packet is additionally Ed25519-signed by the sender.
 */
class PrivateMessageCipher(private val curves: CurveProvider) {
    class Sealed(val ephemeralPublicKey: ByteArray, val ciphertext: ByteArray)

    fun seal(plaintext: String, senderId: String, recipientId: String, recipientAgreementKey: ByteArray,
             messageId: String): Sealed {
        val eph = curves.newAgreementKeyPair()
        val key = deriveKey(curves.agree(eph.privateKey, recipientAgreementKey), eph.publicKey, senderId, recipientId, messageId)
        val ct = Primitives.aesGcmEncrypt(key, plaintext.toByteArray(Charsets.UTF_8), aad(senderId, recipientId, messageId))
        key.fill(0); eph.privateKey.fill(0)
        return Sealed(eph.publicKey, ct)
    }

    /** Throws GeneralSecurityException if the message was not for us or was altered. */
    fun open(p: Packet, me: Identity): String {
        val eph = p.ephemeralKey ?: throw GeneralSecurityException("no ephemeral key")
        val ct = p.ciphertext ?: throw GeneralSecurityException("no ciphertext")
        if (p.recipientId != me.nodeId) throw GeneralSecurityException("not addressed to this phone")
        val key = deriveKey(curves.agree(me.agreement.privateKey, eph), eph, p.senderId, me.nodeId, p.messageId)
        try {
            return String(Primitives.aesGcmDecrypt(key, ct, aad(p.senderId, me.nodeId, p.messageId)), Charsets.UTF_8)
        } finally {
            key.fill(0)
        }
    }

    private fun deriveKey(shared: ByteArray, ephPub: ByteArray, from: String, to: String, mid: String): ByteArray {
        if (shared.all { it == 0.toByte() }) throw GeneralSecurityException("weak shared secret")
        val k = Primitives.hkdf(shared, Hex.decode(mid), "MeshSOS-DM-v1|$from|$to|".toByteArray() + ephPub, 32)
        shared.fill(0)
        return k
    }

    private fun aad(from: String, to: String, mid: String) = "MeshSOS-DM-v1|$mid|$from|$to".toByteArray()
}
