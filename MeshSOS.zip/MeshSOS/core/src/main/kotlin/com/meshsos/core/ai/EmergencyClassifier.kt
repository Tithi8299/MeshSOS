package com.meshsos.core.ai

import com.meshsos.core.model.Category
import com.meshsos.core.model.Severity

data class ClassificationResult(
    /** UNCLASSIFIED when confidence < threshold (AI-3). */
    val category: Category,
    /** The model's top guess even when below threshold (shown to the sender as a hint). */
    val topGuess: Category,
    val confidence: Float,
    val severity: Severity,
    val severityConfidence: Float,
    val peopleCount: Int,
    /** Probabilities over fine-grained concepts: the semantic embedding used for grouping (AI-5). */
    val concept: FloatArray,
    val vector: SparseVector,
    val elapsedMillis: Double,
    val error: String? = null,
)

/**
 * AI-1 / AI-2 / AI-3: turns free Bangla / English / Banglish / mixed text into a structured
 * suggestion. It never throws: if anything goes wrong the result is UNCLASSIFIED and the
 * original text is still sent (the AI can never block an SOS).
 */
class EmergencyClassifier(private val model: ClassifierModel, val threshold: Float = 0.60f) {
    private val typeHead = model.heads.getValue("type")
    private val sevHead = model.heads.getValue("severity")
    val conceptLabels: List<String> = model.heads["concept"]?.classes ?: emptyList()

    fun classify(text: String): ClassificationResult {
        val t0 = System.nanoTime()
        return try {
            val people = PeopleCountExtractor.extract(text)
            val v = model.vectorize(text)
            if (v.isEmpty) {
                return unclassified(people, v, t0, null)
            }
            val pt = model.probabilities("type", v)
            val ps = model.probabilities("severity", v)
            val pc = if (model.heads.containsKey("concept")) model.probabilities("concept", v) else FloatArray(0)
            val ti = pt.indices.maxBy { pt[it] }
            val si = ps.indices.maxBy { ps[it] }
            val guess = Category.fromLabel(typeHead.classes[ti])
            ClassificationResult(
                category = if (pt[ti] >= threshold) guess else Category.UNCLASSIFIED,
                topGuess = guess, confidence = pt[ti],
                severity = Severity.fromLabel(sevHead.classes[si]), severityConfidence = ps[si],
                peopleCount = people, concept = pc, vector = v, elapsedMillis = (System.nanoTime() - t0) / 1e6,
            )
        } catch (e: Exception) {
            unclassified(0, SparseVector(IntArray(0), FloatArray(0)), t0, e.toString())
        }
    }

    private fun unclassified(people: Int, v: SparseVector, t0: Long, err: String?) = ClassificationResult(
        Category.UNCLASSIFIED, Category.UNCLASSIFIED, 0f, Severity.NORMAL, 0f, people,
        FloatArray(conceptLabels.size), v, (System.nanoTime() - t0) / 1e6, err,
    )

    /** Raw probabilities, used by the parity test. */
    fun typeProbabilities(text: String) = model.probabilities("type", model.vectorize(text))
    fun severityProbabilities(text: String) = model.probabilities("severity", model.vectorize(text))
    val typeClasses get() = typeHead.classes
    val severityClasses get() = sevHead.classes
}

/**
 * Head-count extraction (part of AI-1). This is deliberately a small, transparent parser rather
 * than a learned model: it only reports a number the sender actually wrote ("we are 3",
 * "৩ জন", "5 jon", "six people"), and 0 when no number is stated.
 */
object PeopleCountExtractor {
    private val WORDS = mapOf(
        "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6, "seven" to 7, "eight" to 8,
        "nine" to 9, "ten" to 10, "eleven" to 11, "twelve" to 12, "fifteen" to 15, "twenty" to 20,
        "এক" to 1, "দুই" to 2, "তিন" to 3, "চার" to 4, "পাঁচ" to 5, "ছয়" to 6, "সাত" to 7, "আট" to 8,
        "নয়" to 9, "দশ" to 10, "বারো" to 12, "বিশ" to 20,
        "ek" to 1, "dui" to 2, "tin" to 3, "char" to 4, "pach" to 5, "panch" to 5, "choy" to 6, "sat" to 7,
        "at" to 8, "noy" to 9, "dosh" to 10, "baro" to 12, "bish" to 20,
    )
    private val UNIT_PREFIXES = listOf("people", "person", "persons", "member", "jon", "jan", "জন", "জনে", "lok", "লোক",
        "family", "adult", "children", "kids", "passenger", "worker")
    private val LEADERS = setOf("we", "amra", "আমরা", "total", "mot", "মোট")
    private val LEADER_SKIP = setOf("are", "is", "achi", "আছি", "here", "ekhane", "এখানে")

    private fun num(tok: String): Int? = tok.toIntOrNull()?.takeIf { it in 1..999 } ?: WORDS[tok]

    fun extract(text: String): Int {
        val toks = TextFeaturizer.normalize(text).split(' ').filter { it.isNotEmpty() }
        for (i in toks.indices) {
            val n = num(toks[i]) ?: continue
            val next = toks.getOrNull(i + 1) ?: ""
            if (UNIT_PREFIXES.any { next.startsWith(it) }) return n
            if (next == "of" && toks.getOrNull(i + 2) == "us") return n
            // "we are 5", "amra 3", "আমরা ৩" - digits only: number words such as "at" or "tin" are
            // ordinary words too, so they only count when a unit follows them.
            if (toks[i].toIntOrNull() == null) continue
            var j = i - 1
            while (j >= 0 && toks[j] in LEADER_SKIP) j--
            if (j >= 0 && toks[j] in LEADERS && toks.getOrNull(i + 1)?.startsWith("year") != true &&
                toks.getOrNull(i + 1)?.startsWith("bochor") != true && toks.getOrNull(i + 1)?.startsWith("বছর") != true) return n
        }
        return 0
    }
}
