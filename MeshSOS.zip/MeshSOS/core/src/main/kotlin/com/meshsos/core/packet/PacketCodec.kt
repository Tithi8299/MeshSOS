package com.meshsos.core.packet

import com.meshsos.core.crypto.Hex
import com.meshsos.core.model.Category
import com.meshsos.core.model.PacketType
import com.meshsos.core.model.ReceiptKind
import com.meshsos.core.model.Severity
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException

class PacketFormatException(msg: String) : Exception(msg)

/**
 * Compact, versioned binary wire format (big-endian, java.io.Data* streams).
 *
 *   magic 'M','S' | version u8 | type u8 | flags u16 | fields...
 *
 * Optional fields are announced in the flags word, so the decoder never guesses. Every length
 * is bounded and every enum code is checked: a malformed packet raises [PacketFormatException]
 * and is dropped by the router.
 */
object PacketCodec {
    private const val F_LAST_HOP = 1 shl 0
    private const val F_RECIPIENT = 1 shl 1
    private const val F_LOCATION = 1 shl 2
    private const val F_ACCURACY = 1 shl 3
    private const val F_CIPHER = 1 shl 4
    private const val F_REF = 1 shl 5
    private const val F_RESCUER = 1 shl 6
    private const val F_EDITED = 1 shl 7

    fun encode(p: Packet): ByteArray = write(p, forSigning = false)

    /** Canonical bytes covered by the Ed25519 signature (no ttl / hopCount / lastHop / signature). */
    fun signingBytes(p: Packet): ByteArray = write(p, forSigning = true)

    private fun write(p: Packet, forSigning: Boolean): ByteArray {
        val bos = ByteArrayOutputStream(256)
        val o = DataOutputStream(bos)
        var flags = 0
        if (!forSigning && p.lastHopId != null) flags = flags or F_LAST_HOP
        if (p.recipientId != null) flags = flags or F_RECIPIENT
        if (p.hasLocation) flags = flags or F_LOCATION
        if (p.hasLocation && p.accuracyMeters != null) flags = flags or F_ACCURACY
        if (p.ciphertext != null) flags = flags or F_CIPHER
        if (p.refMessageId != null) flags = flags or F_REF
        if (p.isRescuer) flags = flags or F_RESCUER
        if (p.userEdited) flags = flags or F_EDITED
        o.writeByte('M'.code); o.writeByte('S'.code)
        o.writeByte(Packet.WIRE_VERSION)
        o.writeByte(p.type.code)
        o.writeShort(flags)
        o.write(id16(p.messageId))
        o.write(id16(p.senderId))
        o.write(fixed(p.senderSigningKey, 32, "signing key"))
        o.write(fixed(p.senderAgreementKey, 32, "agreement key"))
        str(o, p.senderName, Packet.MAX_NAME_CHARS * 4)
        o.writeLong(p.createdAtMillis)
        o.writeByte(p.originalTtl)
        if (!forSigning) { o.writeByte(p.ttl); o.writeByte(p.hopCount) }
        if (!forSigning && p.lastHopId != null) o.write(id16(p.lastHopId))
        if (p.recipientId != null) o.write(id16(p.recipientId))
        o.writeByte(p.category.code)
        o.writeByte(p.severity.code)
        o.writeShort(p.peopleCount)
        o.writeFloat(p.aiConfidence)
        if (p.hasLocation) {
            o.writeDouble(p.latitude!!); o.writeDouble(p.longitude!!)
            if (p.accuracyMeters != null) o.writeFloat(p.accuracyMeters)
        }
        str(o, p.text, Packet.MAX_TEXT_CHARS * 4)
        if (p.ciphertext != null) {
            o.write(fixed(p.ephemeralKey ?: throw PacketFormatException("ciphertext without ephemeral key"), 32, "ephemeral key"))
            bytes(o, p.ciphertext, 8_000)
        }
        if (p.refMessageId != null) {
            o.write(id16(p.refMessageId))
            o.writeByte((p.receiptKind ?: throw PacketFormatException("receipt without kind")).code)
        }
        o.writeByte(p.batteryPercent.coerceIn(-1, 100))
        if (!forSigning) bytes(o, p.signature, 64)
        o.flush()
        val out = bos.toByteArray()
        if (out.size > Packet.MAX_WIRE_BYTES) throw PacketFormatException("packet too large: ${out.size}")
        return out
    }

    fun decode(data: ByteArray): Packet {
        if (data.size < 8 || data.size > Packet.MAX_WIRE_BYTES) throw PacketFormatException("bad size ${data.size}")
        try {
            val i = DataInputStream(ByteArrayInputStream(data))
            if (i.readUnsignedByte() != 'M'.code || i.readUnsignedByte() != 'S'.code) throw PacketFormatException("bad magic")
            val version = i.readUnsignedByte()
            if (version != Packet.WIRE_VERSION) throw PacketFormatException("unsupported version $version")
            val type = enumOrFail { PacketType.fromCode(i.readUnsignedByte()) }
            val flags = i.readUnsignedShort()
            val messageId = readId(i)
            val senderId = readId(i)
            val sKey = readFixed(i, 32)
            val aKey = readFixed(i, 32)
            val name = readStr(i, Packet.MAX_NAME_CHARS * 4)
            val created = i.readLong()
            val origTtl = i.readUnsignedByte()
            val ttl = i.readUnsignedByte()
            val hops = i.readUnsignedByte()
            val lastHop = if (flags and F_LAST_HOP != 0) readId(i) else null
            val recipient = if (flags and F_RECIPIENT != 0) readId(i) else null
            val category = enumOrFail { Category.fromCode(i.readUnsignedByte()) }
            val severity = enumOrFail { Severity.fromCode(i.readUnsignedByte()) }
            val people = i.readUnsignedShort()
            val conf = i.readFloat()
            var lat: Double? = null; var lon: Double? = null; var acc: Float? = null
            if (flags and F_LOCATION != 0) {
                lat = i.readDouble(); lon = i.readDouble()
                if (flags and F_ACCURACY != 0) acc = i.readFloat()
            }
            val text = readStr(i, Packet.MAX_TEXT_CHARS * 4)
            var eph: ByteArray? = null; var ct: ByteArray? = null
            if (flags and F_CIPHER != 0) { eph = readFixed(i, 32); ct = readBytes(i, 8_000) }
            var ref: String? = null; var kind: ReceiptKind? = null
            if (flags and F_REF != 0) { ref = readId(i); kind = enumOrFail { ReceiptKind.fromCode(i.readUnsignedByte()) } }
            val battery = i.readByte().toInt()
            val sig = readBytes(i, 64)
            if (i.available() != 0) throw PacketFormatException("trailing bytes")
            return Packet(type, messageId, senderId, sKey, aKey, name, created, origTtl, ttl, hops, lastHop, recipient,
                category, severity, people, conf, flags and F_EDITED != 0, lat, lon, acc, text, ct, eph, ref, kind,
                flags and F_RESCUER != 0, battery, sig)
        } catch (e: EOFException) {
            throw PacketFormatException("truncated packet")
        }
    }

    private inline fun <T> enumOrFail(block: () -> T): T =
        try { block() } catch (e: IllegalArgumentException) { throw PacketFormatException(e.message ?: "bad enum") }

    private fun id16(hex: String): ByteArray {
        val b = try { Hex.decode(hex) } catch (e: IllegalArgumentException) { throw PacketFormatException("bad id") }
        if (b.size != 16) throw PacketFormatException("id must be 16 bytes")
        return b
    }

    private fun fixed(b: ByteArray, n: Int, what: String): ByteArray {
        if (b.size != n) throw PacketFormatException("$what must be $n bytes")
        return b
    }

    private fun str(o: DataOutputStream, s: String, maxBytes: Int) = bytes(o, s.toByteArray(Charsets.UTF_8), maxBytes)

    private fun bytes(o: DataOutputStream, b: ByteArray, max: Int) {
        if (b.size > max) throw PacketFormatException("field too long")
        o.writeShort(b.size); o.write(b)
    }

    private fun readId(i: DataInputStream) = Hex.encode(readFixed(i, 16))
    private fun readFixed(i: DataInputStream, n: Int) = ByteArray(n).also { i.readFully(it) }
    private fun readStr(i: DataInputStream, max: Int) = String(readBytes(i, max), Charsets.UTF_8)
    private fun readBytes(i: DataInputStream, max: Int): ByteArray {
        val n = i.readUnsignedShort()
        if (n > max) throw PacketFormatException("field too long")
        return ByteArray(n).also { i.readFully(it) }
    }
}

/** Semantic checks applied after decoding and before signature verification. */
object PacketValidator {
    private const val MAX_FUTURE_SKEW_MS = 24L * 3600 * 1000    // offline phones often have wrong clocks
    const val MAX_AGE_MS = 48L * 3600 * 1000

    fun problems(p: Packet, nowMillis: Long): String? = when {
        p.originalTtl !in 0..Packet.MAX_TTL -> "ttl out of range"
        p.ttl > p.originalTtl -> "ttl above original"
        p.hopCount > p.originalTtl + 1 -> "too many hops"
        p.text.length > Packet.MAX_TEXT_CHARS -> "text too long"
        p.senderName.length > Packet.MAX_NAME_CHARS -> "name too long"
        p.peopleCount !in 0..999 -> "people count out of range"
        p.aiConfidence.isNaN() || p.aiConfidence !in 0f..1f -> "bad confidence"
        p.latitude != null && (p.latitude !in -90.0..90.0 || p.longitude == null || p.longitude !in -180.0..180.0) -> "bad location"
        p.signature.size != 64 -> "missing signature"
        p.createdAtMillis > nowMillis + MAX_FUTURE_SKEW_MS -> "created in the future"
        nowMillis - p.createdAtMillis > MAX_AGE_MS -> "expired"
        p.type == PacketType.DIRECT_TEXT && (p.recipientId == null || p.ciphertext == null || p.text.isNotEmpty()) -> "bad direct message"
        p.type == PacketType.RECEIPT && (p.recipientId == null || p.refMessageId == null || p.receiptKind == null) -> "bad receipt"
        p.type == PacketType.HELLO && p.originalTtl != 0 -> "hello must not be forwarded"
        else -> null
    }
}
