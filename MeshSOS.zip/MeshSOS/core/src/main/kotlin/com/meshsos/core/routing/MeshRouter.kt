package com.meshsos.core.routing

import com.meshsos.core.crypto.Hex
import com.meshsos.core.crypto.Identity
import com.meshsos.core.crypto.PacketSigner
import com.meshsos.core.crypto.Primitives
import com.meshsos.core.model.PacketType
import com.meshsos.core.model.ReceiptKind
import com.meshsos.core.packet.Packet
import com.meshsos.core.packet.PacketCodec
import com.meshsos.core.packet.PacketFormatException
import com.meshsos.core.packet.PacketValidator

/** Persistent table of message IDs already processed (FR5). The app backs it with Room. */
interface SeenStore {
    /** Atomically records [messageId]; returns false if it was already present. */
    fun markIfNew(messageId: String, atMillis: Long): Boolean
}

class InMemorySeenStore : SeenStore {
    private val ids = HashSet<String>()
    @Synchronized override fun markIfNew(messageId: String, atMillis: Long) = ids.add(messageId)
}

data class RouterConfig(
    val relayEnabled: Boolean = true,
    val isRescuer: Boolean = false,
    /** Only relays this close to the origin send RELAYED receipts, to keep receipt traffic small. */
    val relayReceiptMaxHop: Int = 2,
    val receiptTtl: Int = Packet.DEFAULT_TTL,
)

enum class DropReason { MALFORMED, INVALID, BAD_SIGNATURE, DUPLICATE, OWN_PACKET }

sealed class RouteDecision {
    data class Dropped(val reason: DropReason, val detail: String = "") : RouteDecision()

    /** A neighbour told us who it is. Never forwarded. */
    data class Hello(val packet: Packet) : RouteDecision()

    data class Accepted(
        val packet: Packet,
        /** Show / store for the local user (SOS, broadcast, a DM or receipt addressed to us). */
        val deliverLocally: Boolean,
        /** Copy to put in the store-and-forward queue (TTL already decreased), or null. */
        val forward: Packet?,
        /** Signed receipts to send back toward the origin. */
        val receipts: List<Packet>,
        /** Why nothing was forwarded, for diagnostics. */
        val notForwardedBecause: String? = null,
    ) : RouteDecision()
}

/**
 * Application-layer multi-hop routing (FR3, FR4, FR5, FR10). Pure logic, no Android code:
 * the transport hands raw bytes in, and the decision says what to store, show, forward and
 * acknowledge. Nearby Connections does not relay on its own; every hop is done here.
 *
 * Order of checks for each incoming packet:
 *   decode -> validate fields -> verify signature -> drop own echoes -> HELLO? ->
 *   seen-ID check (persistent) -> deliver? -> forward with TTL-1 if TTL > 0 -> receipts
 */
class MeshRouter(
    private val self: Identity,
    private val signer: PacketSigner,
    private val seen: SeenStore,
    var config: RouterConfig,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    fun onReceive(raw: ByteArray): RouteDecision {
        val p = try { PacketCodec.decode(raw) } catch (e: PacketFormatException) {
            return RouteDecision.Dropped(DropReason.MALFORMED, e.message ?: "")
        }
        return onPacket(p)
    }

    fun onPacket(p: Packet): RouteDecision {
        val now = clock()
        PacketValidator.problems(p, now)?.let { return RouteDecision.Dropped(DropReason.INVALID, it) }
        if (!signer.verify(p)) return RouteDecision.Dropped(DropReason.BAD_SIGNATURE)
        if (p.senderId == self.nodeId) {
            seen.markIfNew(p.messageId, now)
            return RouteDecision.Dropped(DropReason.OWN_PACKET)
        }
        if (p.type == PacketType.HELLO) return RouteDecision.Hello(p)
        if (!seen.markIfNew(p.messageId, now)) return RouteDecision.Dropped(DropReason.DUPLICATE)

        val forMe = p.recipientId == self.nodeId
        val deliver = when (p.type) {
            PacketType.SOS, PacketType.BROADCAST_TEXT -> true
            PacketType.DIRECT_TEXT, PacketType.RECEIPT -> forMe
            PacketType.HELLO -> false
        }
        var reason: String? = null
        val forward = when {
            forMe -> { reason = "addressed to this phone"; null }
            p.ttl <= 0 -> { reason = "ttl exhausted"; null }
            !config.relayEnabled -> { reason = "relaying turned off"; null }
            else -> p.forwardedBy(self.nodeId)
        }
        val receipts = ArrayList<Packet>(2)
        if (p.type != PacketType.RECEIPT) {
            val endpoint = forMe || (p.type == PacketType.SOS && config.isRescuer)
            if (endpoint) receipts += receipt(p, ReceiptKind.DELIVERED)
            else if (forward != null && p.hopCount < config.relayReceiptMaxHop) receipts += receipt(p, ReceiptKind.RELAYED)
        }
        return RouteDecision.Accepted(p, deliver, forward, receipts, reason)
    }

    /** Builds a new signed packet originating here. Marks it seen so our own echo is ignored. */
    fun originate(unsigned: Packet): Packet {
        require(unsigned.senderId == self.nodeId)
        val signed = signer.sign(unsigned, self)
        seen.markIfNew(signed.messageId, clock())
        return signed
    }

    fun receipt(of: Packet, kind: ReceiptKind): Packet = originate(
        Packet(
            type = PacketType.RECEIPT, messageId = newMessageId(), senderId = self.nodeId,
            senderSigningKey = self.signing.publicKey, senderAgreementKey = self.agreement.publicKey,
            senderName = self.displayName, createdAtMillis = clock(), originalTtl = config.receiptTtl,
            ttl = config.receiptTtl, recipientId = of.senderId, refMessageId = of.messageId, receiptKind = kind,
            isRescuer = config.isRescuer, hopCount = 0,
        )
    )

    companion object {
        fun newMessageId(): String = Hex.encode(Primitives.randomBytes(16))
    }
}
