package com.meshsos.core.routing

import com.meshsos.core.ai.LinkContext
import com.meshsos.core.ai.PriorityScorer
import com.meshsos.core.packet.Packet

/**
 * Store-and-forward queue ordered by an AI priority score plus an aging term (AI-4, FR8).
 *
 * Each entry remembers which neighbours already received it, so a packet is offered to every
 * new neighbour exactly once (the receiver's seen-ID table drops any duplicate anyway).
 * Entries leave the queue when they expire or when a DELIVERED receipt arrives. The app keeps a
 * Room copy of this queue so it survives restarts.
 */
class PriorityForwardQueue(
    private val scorer: PriorityScorer,
    private val capacity: Int = 500,
) {
    class Entry(val packet: Packet, val enqueuedAtMillis: Long, val sentTo: MutableSet<String> = HashSet())

    private val entries = LinkedHashMap<String, Entry>()

    @Synchronized fun size() = entries.size
    @Synchronized fun contains(messageId: String) = entries.containsKey(messageId)

    /** Returns false if the packet is already queued. Evicts the lowest-priority entry when full. */
    @Synchronized fun offer(packet: Packet, nowMillis: Long, alreadySentTo: Set<String> = emptySet()): Boolean {
        if (entries.containsKey(packet.messageId)) return false
        if (entries.size >= capacity) {
            val worst = entries.values.minByOrNull { scorer.score(it.packet, nowMillis, LinkContext.UNKNOWN, it.enqueuedAtMillis) }
            if (worst != null) entries.remove(worst.packet.messageId)
        }
        entries[packet.messageId] = Entry(packet, nowMillis, alreadySentTo.toMutableSet())
        return true
    }

    @Synchronized fun remove(messageId: String): Boolean = entries.remove(messageId) != null

    @Synchronized fun removeExpired(nowMillis: Long, maxAgeMillis: Long): List<String> {
        val dead = entries.values.filter { nowMillis - it.packet.createdAtMillis > maxAgeMillis }.map { it.packet.messageId }
        dead.forEach { entries.remove(it) }
        return dead
    }

    /**
     * Next packets to send to [neighbourId], best first. Excludes packets that neighbour already got
     * or that it just sent us ([Packet.lastHopId]). Low battery raises the bar for relayed traffic.
     */
    @Synchronized fun nextFor(neighbourId: String, nowMillis: Long, link: LinkContext, max: Int): List<Packet> =
        entries.values.asSequence()
            .filter { neighbourId !in it.sentTo && it.packet.lastHopId != neighbourId && it.packet.senderId != neighbourId }
            .filter { scorer.shouldSend(it.packet, nowMillis, link, it.enqueuedAtMillis) }
            .sortedByDescending { scorer.score(it.packet, nowMillis, link, it.enqueuedAtMillis) }
            .take(max).map { it.packet }.toList()

    @Synchronized fun markSent(messageId: String, neighbourId: String) {
        entries[messageId]?.sentTo?.add(neighbourId)
    }

    @Synchronized fun snapshot(): List<Entry> = entries.values.toList()
}
