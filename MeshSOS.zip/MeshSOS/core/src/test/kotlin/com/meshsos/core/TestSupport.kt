package com.meshsos.core

import com.meshsos.core.crypto.CurveProvider
import com.meshsos.core.crypto.Identity
import com.meshsos.core.crypto.KeyPairBytes
import com.meshsos.core.crypto.PacketSigner
import com.meshsos.core.model.Category
import com.meshsos.core.model.PacketType
import com.meshsos.core.model.Severity
import com.meshsos.core.packet.Packet
import com.meshsos.core.routing.MeshRouter
import java.io.File
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.Signature
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.KeyAgreement

/**
 * JDK 15+ implementation of [CurveProvider] used only by unit tests (the app uses Tink because
 * Android < 13 lacks these algorithms). Converts between raw 32-byte keys and X.509 / PKCS#8.
 */
object JdkCurveProvider : CurveProvider {
    private val ED_PUB = hex("302a300506032b6570032100"); private val ED_PRIV = hex("302e020100300506032b657004220420")
    private val X_PUB = hex("302a300506032b656e032100"); private val X_PRIV = hex("302e020100300506032b656e04220420")

    private fun hex(s: String) = ByteArray(s.length / 2) { s.substring(2 * it, 2 * it + 2).toInt(16).toByte() }
    private fun raw(encoded: ByteArray) = encoded.copyOfRange(encoded.size - 32, encoded.size)

    override fun newSigningKeyPair(): KeyPairBytes {
        val kp = KeyPairGenerator.getInstance("Ed25519").generateKeyPair()
        return KeyPairBytes(raw(kp.public.encoded), raw(kp.private.encoded))
    }

    override fun sign(privateKey: ByteArray, message: ByteArray): ByteArray {
        val k = KeyFactory.getInstance("Ed25519").generatePrivate(PKCS8EncodedKeySpec(ED_PRIV + privateKey))
        return Signature.getInstance("Ed25519").run { initSign(k); update(message); sign() }
    }

    override fun verify(publicKey: ByteArray, message: ByteArray, signature: ByteArray): Boolean {
        val k = KeyFactory.getInstance("Ed25519").generatePublic(X509EncodedKeySpec(ED_PUB + publicKey))
        return Signature.getInstance("Ed25519").run { initVerify(k); update(message); verify(signature) }
    }

    override fun newAgreementKeyPair(): KeyPairBytes {
        val kp = KeyPairGenerator.getInstance("X25519").generateKeyPair()
        return KeyPairBytes(raw(kp.public.encoded), raw(kp.private.encoded))
    }

    override fun agree(privateKey: ByteArray, peerPublicKey: ByteArray): ByteArray {
        val kf = KeyFactory.getInstance("X25519")
        return KeyAgreement.getInstance("X25519").run {
            init(kf.generatePrivate(PKCS8EncodedKeySpec(X_PRIV + privateKey)))
            doPhase(kf.generatePublic(X509EncodedKeySpec(X_PUB + peerPublicKey)), true)
            generateSecret()
        }
    }
}

object Fixtures {
    val signer = PacketSigner(JdkCurveProvider)
    fun identity(name: String) = Identity.generate(JdkCurveProvider, name)

    fun sos(from: Identity, text: String = "বাবা শ্বাস নিচ্ছে না. My father has stopped breathing.", ttl: Int = 6,
            now: Long = System.currentTimeMillis(), severity: Severity = Severity.CRITICAL) = Packet(
        type = PacketType.SOS, messageId = MeshRouter.newMessageId(), senderId = from.nodeId,
        senderSigningKey = from.signing.publicKey, senderAgreementKey = from.agreement.publicKey,
        senderName = from.displayName, createdAtMillis = now, originalTtl = ttl, ttl = ttl,
        category = Category.MEDICAL, severity = severity, peopleCount = 3, aiConfidence = 0.9f,
        latitude = 24.8731, longitude = 91.4062, accuracyMeters = 8f, text = text,
    )

    /** Finds a file in the repository whether Gradle runs from the root or from core/. */
    fun repoFile(rel: String): File =
        listOf(File(rel), File("../$rel"), File("../../$rel")).firstOrNull { it.exists() }
            ?: error("cannot find $rel from ${File(".").absolutePath}")
}
