package com.meshsos.core

import com.meshsos.core.ai.LinkContext
import com.meshsos.core.ai.RulePriorityScorer
import com.meshsos.core.model.ReceiptKind
import com.meshsos.core.model.Severity
import com.meshsos.core.packet.PacketCodec
import com.meshsos.core.routing.DropReason
import com.meshsos.core.routing.InMemorySeenStore
import com.meshsos.core.routing.MeshRouter
import com.meshsos.core.routing.PriorityForwardQueue
import com.meshsos.core.routing.RouteDecision
import com.meshsos.core.routing.RouterConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Phone A -> Phone B (relay) -> Phone C (rescuer), entirely in memory. */
class RoutingTest {
    private val a = Fixtures.identity("A"); private val b = Fixtures.identity("B"); private val c = Fixtures.identity("C")
    private val ra = MeshRouter(a, Fixtures.signer, InMemorySeenStore(), RouterConfig())
    private val rb = MeshRouter(b, Fixtures.signer, InMemorySeenStore(), RouterConfig())
    private val rc = MeshRouter(c, Fixtures.signer, InMemorySeenStore(), RouterConfig(isRescuer = true))

    private fun wire(p: com.meshsos.core.packet.Packet) = PacketCodec.encode(p)

    @Test fun twoHopSosIsRelayedDeliveredAndAcknowledged() {
        val sos = ra.originate(Fixtures.sos(a))
        val atB = rb.onReceive(wire(sos)) as RouteDecision.Accepted
        assertTrue(atB.deliverLocally)
        val fwd = atB.forward!!
        assertEquals(5, fwd.ttl); assertEquals(1, fwd.hopCount); assertEquals(b.nodeId, fwd.lastHopId)
        assertEquals(ReceiptKind.RELAYED, atB.receipts.single().receiptKind)

        val atC = rc.onReceive(wire(fwd)) as RouteDecision.Accepted
        assertTrue(atC.deliverLocally)
        assertEquals(sos.text, atC.packet.text)                       // original report reaches C
        assertEquals(ReceiptKind.DELIVERED, atC.receipts.single().receiptKind)

        // DELIVERED receipt travels C -> B -> A
        val recAtB = rb.onReceive(wire(atC.receipts.single())) as RouteDecision.Accepted
        assertFalse(recAtB.deliverLocally)
        val recAtA = ra.onReceive(wire(recAtB.forward!!)) as RouteDecision.Accepted
        assertTrue(recAtA.deliverLocally)
        assertEquals(sos.messageId, recAtA.packet.refMessageId)
        assertNull("receipt addressed to A is not forwarded further", recAtA.forward)
    }

    @Test fun duplicatesAreSuppressed() {
        val sos = ra.originate(Fixtures.sos(a))
        assertTrue(rb.onReceive(wire(sos)) is RouteDecision.Accepted)
        val again = rb.onReceive(wire(sos))
        assertEquals(DropReason.DUPLICATE, (again as RouteDecision.Dropped).reason)
        // the same message arriving by a different path (different ttl / hop fields) is still a duplicate
        val other = rb.onReceive(wire(sos.forwardedBy(c.nodeId)))
        assertEquals(DropReason.DUPLICATE, (other as RouteDecision.Dropped).reason)
    }

    @Test fun ttlZeroIsDeliveredButNotForwarded() {
        val sos = ra.originate(Fixtures.sos(a, ttl = 1))
        val atB = rb.onReceive(wire(sos)) as RouteDecision.Accepted
        val atC = rc.onReceive(wire(atB.forward!!)) as RouteDecision.Accepted
        assertEquals(0, atB.forward!!.ttl)
        assertTrue(atC.deliverLocally)
        assertNull(atC.forward)
        assertEquals("ttl exhausted", atC.notForwardedBecause)
    }

    @Test fun ttlCannotBeRaisedByARelay() {
        val sos = ra.originate(Fixtures.sos(a, ttl = 2))
        val d = rb.onReceive(wire(sos.copy(ttl = 9)))
        assertEquals(DropReason.INVALID, (d as RouteDecision.Dropped).reason)
    }

    @Test fun tamperedPacketIsRejected() {
        val bytes = wire(ra.originate(Fixtures.sos(a, text = "Fire at the market")))
        val idx = String(bytes, Charsets.ISO_8859_1).indexOf("Fire")
        bytes[idx] = 'H'.code.toByte()
        assertEquals(DropReason.BAD_SIGNATURE, (rb.onReceive(bytes) as RouteDecision.Dropped).reason)
    }

    @Test fun ownEchoIsDropped() {
        val sos = ra.originate(Fixtures.sos(a))
        val echo = ra.onReceive(wire(sos.forwardedBy(b.nodeId)))
        assertEquals(DropReason.OWN_PACKET, (echo as RouteDecision.Dropped).reason)
    }

    @Test fun relayingCanBeSwitchedOff() {
        rb.config = RouterConfig(relayEnabled = false)
        val atB = rb.onReceive(wire(ra.originate(Fixtures.sos(a)))) as RouteDecision.Accepted
        assertTrue(atB.deliverLocally); assertNull(atB.forward)
    }

    @Test fun meshCannotLoopForever() {
        // A ring of 5 phones where every phone forwards to the next: the message must die out.
        val ids = (0 until 5).map { Fixtures.identity("N$it") }
        val routers = ids.map { MeshRouter(it, Fixtures.signer, InMemorySeenStore(), RouterConfig()) }
        var p = routers[0].originate(Fixtures.sos(ids[0], ttl = 16))
        var transmissions = 0
        var i = 1
        while (true) {
            val d = routers[i % 5].onReceive(wire(p)); transmissions++
            if (d !is RouteDecision.Accepted || d.forward == null) break
            p = d.forward!!; i++
            assertTrue("loop detected", transmissions < 50)
        }
        assertEquals(5, transmissions) // 4 new phones + the origin dropping its own echo
    }

    // ---------------------------------------------------------------- forwarding queue
    @Test fun criticalGoesFirstButOldRoutineMessagesAreNotStarved() {
        val q = PriorityForwardQueue(RulePriorityScorer())
        val t0 = 1_000_000L
        val normal = ra.originate(Fixtures.sos(a, severity = Severity.NORMAL, now = t0))
        q.offer(normal, t0)
        val critical = ra.originate(Fixtures.sos(a, severity = Severity.CRITICAL, now = t0 + 1000))
        q.offer(critical, t0 + 1000)
        assertEquals(critical.messageId, q.nextFor("nb", t0 + 2000, LinkContext.UNKNOWN, 1).single().messageId)
        // after waiting ~8 minutes the routine message outranks a brand-new critical one
        val t1 = t0 + 8 * 60_000
        val fresh = ra.originate(Fixtures.sos(a, severity = Severity.CRITICAL, now = t1))
        q.remove(critical.messageId); q.offer(fresh, t1)
        assertEquals(normal.messageId, q.nextFor("nb", t1, LinkContext.UNKNOWN, 1).single().messageId)
    }

    @Test fun queueSendsEachPacketToEachNeighbourOnceAndSkipsTheSender() {
        val q = PriorityForwardQueue(RulePriorityScorer())
        val sos = ra.originate(Fixtures.sos(a))
        val fwd = (rb.onReceive(wire(sos)) as RouteDecision.Accepted).forward!!
        q.offer(fwd, 0)
        assertTrue("never back to the origin", q.nextFor(a.nodeId, 1, LinkContext.UNKNOWN, 10).isEmpty())
        assertEquals(1, q.nextFor("x", 1, LinkContext.UNKNOWN, 10).size)
        q.markSent(fwd.messageId, "x")
        assertTrue(q.nextFor("x", 2, LinkContext.UNKNOWN, 10).isEmpty())
        assertEquals(1, q.nextFor("y", 2, LinkContext.UNKNOWN, 10).size)
        assertFalse("no duplicate entries", q.offer(fwd, 3))
    }

    @Test fun lowBatteryStopsRelayingRoutineTrafficOnly() {
        val q = PriorityForwardQueue(RulePriorityScorer())
        val low = LinkContext(0.10f, 0.9f)
        val relayedNormal = (rb.onReceive(wire(ra.originate(Fixtures.sos(a, severity = Severity.NORMAL)))) as RouteDecision.Accepted).forward!!
        val ownNormal = rb.originate(Fixtures.sos(b, severity = Severity.NORMAL))
        q.offer(relayedNormal, 0); q.offer(ownNormal, 0)
        assertEquals(listOf(ownNormal.messageId), q.nextFor("z", 1, low, 10).map { it.messageId })
        assertEquals(2, q.nextFor("z", 1, LinkContext(0.8f, 0.9f), 10).size)
    }
}
