package com.meshsos.core

import com.meshsos.core.ai.ClassifierModel
import com.meshsos.core.ai.EmergencyClassifier
import com.meshsos.core.ai.GroupingConfig
import com.meshsos.core.ai.IncidentGrouper
import com.meshsos.core.ai.LearnedPriorityScorer
import com.meshsos.core.ai.LinkContext
import com.meshsos.core.ai.PeopleCountExtractor
import com.meshsos.core.ai.Report
import com.meshsos.core.ai.SparseVector
import com.meshsos.core.ai.TextFeaturizer
import com.meshsos.core.geo.Geo
import com.meshsos.core.model.Category
import com.meshsos.core.model.Severity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AiAndGeoTest {
    private val classifier by lazy {
        EmergencyClassifier(Fixtures.repoFile("ml/models/meshsos_classifier.bin").inputStream().use { ClassifierModel.load(it) })
    }

    /** The Kotlin port must reproduce scikit-learn's probabilities (golden vectors from train_classifier.py). */
    @Test fun kotlinInferenceMatchesPythonGoldenVectors() {
        val lines = Fixtures.repoFile("ml/models/golden_vectors.tsv").readLines(Charsets.UTF_8)
        val classes = lines[1].split('\t')
        assertEquals(classifier.typeClasses.joinToString(","), classes[1])
        assertEquals(classifier.severityClasses.joinToString(","), classes[2])
        var worst = 0.0
        for (line in lines.drop(2)) {
            val (msg, tp, sp) = line.split('\t')
            val got = classifier.typeProbabilities(msg).toList() + classifier.severityProbabilities(msg).toList()
            val want = (tp.split(',') + sp.split(',')).map { it.toDouble() }
            for (k in want.indices) worst = maxOf(worst, kotlin.math.abs(got[k] - want[k]))
        }
        assertTrue("max |diff| = $worst", worst < 1e-4)
    }

    @Test fun normalisationMatchesPythonRules() {
        assertEquals("আমরা 3 জন ছাদে আছি", TextFeaturizer.normalize("আমরা ৩ জন, ছাদে আছি।"))
        assertEquals("help we are 4 people", TextFeaturizer.normalize("HELP!!  We are 4 people..."))
        assertTrue(TextFeaturizer.analyze("ab").containsAll(listOf("w:ab", "c: a", "c:ab", "c:b ", "c: ab", "c:ab ", "c: ab ")))
    }

    @Test fun classifierHandlesPrototypeMessageAndGarbage() {
        val r = classifier.classify("বাবা শ্বাস নিচ্ছে না. My father has stopped breathing. আমরা ৩ জন, ছাদে আছি।")
        assertEquals(Category.MEDICAL, r.topGuess)
        assertEquals(3, r.peopleCount)
        assertTrue("classification should take well under a second", r.elapsedMillis < 1000)
        val g = classifier.classify("!!!")
        assertEquals(Category.UNCLASSIFIED, g.category)
        assertEquals(null, g.error)
    }

    @Test fun peopleCountIsOnlyReportedWhenWritten() {
        mapOf("আমরা ৩ জন, ছাদে আছি" to 3, "Pani uthche, 5 jon, nouka lagbe" to 5, "we are 12 people" to 12,
            "6 of us including kids" to 6, "need food for twenty people" to 20, "amra tin jon" to 3,
            "My father has stopped breathing" to 0, "5 year old boy missing near the school" to 0,
            "We are at the shelter" to 0, "Stranded on the tin roof" to 0, "আমাদের ১০ জনের খাবার লাগবে" to 10)
            .forEach { (t, n) -> assertEquals(t, n, PeopleCountExtractor.extract(t)) }
    }

    private fun report(id: String, sender: String, concept: FloatArray, lat: Double?, lon: Double?, minutes: Int,
                       cat: Category = Category.MEDICAL, sev: Severity = Severity.CRITICAL) =
        Report(id, sender, id, cat, sev, 0, lat, lon, minutes * 60_000L, concept, SparseVector(IntArray(0), FloatArray(0)))

    @Test fun groupingUsesMeaningPlaceAndTime() {
        val breath = floatArrayOf(0.9f, 0.05f, 0.05f); val bleed = floatArrayOf(0.05f, 0.9f, 0.05f)
        val g = IncidentGrouper(GroupingConfig(textThreshold = 0.5)).group(listOf(
            report("en", "s1", breath, 24.8731, 91.4062, 0),
            report("bn", "s2", breath, 24.8735, 91.4065, 3, sev = Severity.HIGH),   // ~50 m away, same meaning
            report("far", "s3", breath, 24.8931, 91.4062, 4),                       // ~2.2 km away
            report("other", "s4", bleed, 24.8732, 91.4063, 5),                      // same place, different emergency
            report("late", "s5", breath, 24.8731, 91.4062, 120),                    // two hours later
            report("noloc", "s6", breath, null, null, 6),                           // no GPS, different sender
        ))
        val first = g.single { it.id == "en" }
        assertEquals(setOf("en", "bn"), first.reports.map { it.id }.toSet())
        assertEquals(Severity.CRITICAL, first.combinedSeverity)
        assertEquals(5, g.size)
    }

    @Test fun learnedPriorityModelLoadsAndPrefersGoodLinks() {
        val s = LearnedPriorityScorer.fromJson(Fixtures.repoFile("sim/results/priority_model.json").readText())
        val now = System.currentTimeMillis()
        val p = Fixtures.sos(Fixtures.identity("x"), now = now)
        assertTrue(s.pUseful(p, now, LinkContext(0.8f, 0.95f)) > s.pUseful(p, now, LinkContext(0.8f, 0.4f)))
        assertTrue(s.score(p, now, LinkContext.UNKNOWN, now) > 0)
    }

    @Test fun distanceAndDirection() {
        assertEquals(111_195.0, Geo.distanceMeters(24.0, 91.0, 25.0, 91.0), 50.0)       // one degree of latitude
        assertEquals(0.0, Geo.bearingDegrees(24.0, 91.0, 25.0, 91.0), 0.01)
        assertEquals(90.0, Geo.bearingDegrees(0.0, 0.0, 0.0, 1.0), 0.01)
        val d = Geo.distanceMeters(24.8700, 91.4030, 24.8731, 91.4062)
        assertTrue(d in 400.0..500.0)
        assertEquals(Geo.Compass.NE, Geo.compass(Geo.bearingDegrees(24.8700, 91.4030, 24.8731, 91.4062)))
        assertEquals(Geo.Compass.N, Geo.compass(359.0))
        assertEquals("420 m", Geo.formatDistance(424.0)); assertEquals("1.1 km", Geo.formatDistance(1100.0))
    }
}
