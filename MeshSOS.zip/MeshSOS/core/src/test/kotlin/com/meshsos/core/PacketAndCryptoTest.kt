package com.meshsos.core

import com.meshsos.core.crypto.Hex
import com.meshsos.core.crypto.Identity
import com.meshsos.core.crypto.Primitives
import com.meshsos.core.crypto.PrivateMessageCipher
import com.meshsos.core.model.PacketType
import com.meshsos.core.model.ReceiptKind
import com.meshsos.core.packet.Packet
import com.meshsos.core.packet.PacketCodec
import com.meshsos.core.packet.PacketFormatException
import com.meshsos.core.packet.PacketValidator
import com.meshsos.core.routing.MeshRouter
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.security.GeneralSecurityException

class PacketAndCryptoTest {
    private val a = Fixtures.identity("Ayesha")
    private val b = Fixtures.identity("Rafiq")

    @Test fun sosRoundTripsThroughWireFormat() {
        val p = Fixtures.signer.sign(Fixtures.sos(a), a)
        val back = PacketCodec.decode(PacketCodec.encode(p))
        assertEquals(p, back)
        assertEquals(p.text, back.text)
        assertEquals(24.8731, back.latitude!!, 1e-9)
        assertEquals(8f, back.accuracyMeters!!, 0f)
        assertTrue(Fixtures.signer.verify(back))
    }

    @Test fun receiptAndHelloRoundTrip() {
        val r = MeshRouter(b, Fixtures.signer, com.meshsos.core.routing.InMemorySeenStore(),
            com.meshsos.core.routing.RouterConfig(isRescuer = true))
        val rec = r.receipt(Fixtures.signer.sign(Fixtures.sos(a), a), ReceiptKind.DELIVERED)
        val back = PacketCodec.decode(PacketCodec.encode(rec))
        assertEquals(ReceiptKind.DELIVERED, back.receiptKind)
        assertEquals(a.nodeId, back.recipientId)
        assertTrue(back.isRescuer)
        assertTrue(Fixtures.signer.verify(back))
    }

    @Test fun truncatedOrGarbageBytesAreRejected() {
        val bytes = PacketCodec.encode(Fixtures.signer.sign(Fixtures.sos(a), a))
        for (cut in listOf(0, 5, 20, bytes.size / 2, bytes.size - 1)) {
            try { PacketCodec.decode(bytes.copyOf(cut)); fail("decoded truncated packet ($cut bytes)") }
            catch (e: PacketFormatException) { /* expected */ }
        }
        try { PacketCodec.decode(ByteArray(100) { 7 }); fail() } catch (e: PacketFormatException) {}
    }

    @Test fun relayFieldsAreNotSignedButEverythingElseIs() {
        val p = Fixtures.signer.sign(Fixtures.sos(a), a)
        assertTrue("relay changes keep the signature valid", Fixtures.signer.verify(p.forwardedBy(b.nodeId)))
        assertFalse(Fixtures.signer.verify(p.copy(text = p.text + "!")))
        assertFalse(Fixtures.signer.verify(p.copy(latitude = 23.0)))
        assertFalse(Fixtures.signer.verify(p.copy(originalTtl = 9, ttl = 9)))
        assertFalse(Fixtures.signer.verify(p.copy(severity = com.meshsos.core.model.Severity.NORMAL)))
    }

    @Test fun senderCannotClaimSomeoneElsesId() {
        val forged = Fixtures.sos(a).copy(senderId = b.nodeId)
        val signedWithA = forged.copy(signature = JdkCurveProvider.sign(a.signing.privateKey, PacketCodec.signingBytes(forged)))
        assertFalse(Fixtures.signer.verify(signedWithA))
    }

    @Test fun validatorCatchesBadFields() {
        val now = System.currentTimeMillis()
        val p = Fixtures.signer.sign(Fixtures.sos(a, now = now), a)
        assertNull(PacketValidator.problems(p, now))
        assertNotNull(PacketValidator.problems(p.copy(ttl = 7), now))                  // above original
        assertNotNull(PacketValidator.problems(p.copy(latitude = 123.0), now))
        assertNotNull(PacketValidator.problems(p, now + PacketValidator.MAX_AGE_MS + 1))
        assertNotNull(PacketValidator.problems(p.copy(signature = ByteArray(0)), now))
    }

    @Test fun hkdfMatchesRfc5869TestCase1() {
        val okm = Primitives.hkdf(ByteArray(22) { 0x0b }, Hex.decode("000102030405060708090a0b0c"),
            Hex.decode("f0f1f2f3f4f5f6f7f8f9"), 42)
        assertEquals("3cb25f25faacd57a90434f64d0362f2a2d2d0a90cf1a5a4c5db02d56ecc4c5bf34007208d5b887185865", Hex.encode(okm))
    }

    @Test fun x25519AgreementIsSymmetric() {
        val s1 = JdkCurveProvider.agree(a.agreement.privateKey, b.agreement.publicKey)
        val s2 = JdkCurveProvider.agree(b.agreement.privateKey, a.agreement.publicKey)
        assertArrayEquals(s1, s2)
    }

    private fun dm(text: String): Packet {
        val mid = MeshRouter.newMessageId()
        val sealed = PrivateMessageCipher(JdkCurveProvider).seal(text, a.nodeId, b.nodeId, b.agreement.publicKey, mid)
        return Fixtures.signer.sign(Packet(PacketType.DIRECT_TEXT, mid, a.nodeId, a.signing.publicKey, a.agreement.publicKey,
            a.displayName, System.currentTimeMillis(), 6, 6, recipientId = b.nodeId,
            ciphertext = sealed.ciphertext, ephemeralKey = sealed.ephemeralPublicKey), a)
    }

    @Test fun onlyTheRecipientCanReadAPrivateMessage() {
        val p = PacketCodec.decode(PacketCodec.encode(dm("হ্যাঁ, ছাদে আছি। ৩ জন।")))
        assertEquals("হ্যাঁ, ছাদে আছি। ৩ জন।", PrivateMessageCipher(JdkCurveProvider).open(p, b))
        assertFalse("plaintext must not appear on the wire", String(PacketCodec.encode(p), Charsets.UTF_8).contains("ছাদে"))
        val eve = Fixtures.identity("Eve")
        try { PrivateMessageCipher(JdkCurveProvider).open(p.copy(recipientId = eve.nodeId), eve); fail() }
        catch (e: GeneralSecurityException) {}
    }

    @Test fun tamperedCiphertextFailsAuthentication() {
        val p = dm("Moving a boat toward Ward 4 now.")
        val ct = p.ciphertext!!.copyOf().also { it[20] = (it[20].toInt() xor 1).toByte() }
        try { PrivateMessageCipher(JdkCurveProvider).open(p.copy(ciphertext = ct), b); fail() }
        catch (e: GeneralSecurityException) {}
    }

    @Test fun twoMessagesWithSameTextHaveDifferentCiphertext() {
        assertFalse(dm("same").ciphertext!!.contentEquals(dm("same").ciphertext!!))
    }

    @Test fun safetyCodeIsSymmetricAndTwelveDigits() {
        val x = Identity.safetyCode(a.signing.publicKey, b.signing.publicKey)
        assertEquals(x, Identity.safetyCode(b.signing.publicKey, a.signing.publicKey))
        assertTrue(Regex("\\d{4} \\d{4} \\d{4}").matches(x))
    }
}
