// Pure Kotlin/JVM module: packets, routing, crypto glue, geo and on-device AI inference.
// No Android dependency, so `./gradlew :core:test` runs on any computer with a JDK.
plugins {
    alias(libs.plugins.kotlin.jvm)
}

// Targets Java 17 bytecode but builds with whatever JDK 17+ Gradle runs on (Android Studio bundles 21).
java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}
kotlin {
    compilerOptions { jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17) }
}

dependencies {
    testImplementation(libs.junit)
}

tasks.test {
    // tests read ml/models/* and sim/results/* from the repository
    workingDir = rootProject.projectDir
    testLogging { events("passed", "failed", "skipped"); showStandardStreams = true }
}
