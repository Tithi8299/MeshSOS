# Architecture

## Layers

```
┌────────────────────────── Presentation (app/ui) ──────────────────────────┐
│ 10 Compose screens · ViewModels · navigation · EN/BN strings · theme      │
├──────────────────────────── App services ─────────────────────────────────┤
│ MeshEngine (serial coroutine dispatcher) · MeshService (foreground)       │
│ IncidentRepository · SettingsRepository · LocationProvider · Notifier     │
├──────────── core (pure Kotlin, no Android) ──────────┬── app/security ────┤
│ packet: Packet, PacketCodec, PacketValidator         │ TinkCurveProvider  │
│ routing: MeshRouter, PriorityForwardQueue, SeenStore │ KeyVault (Keystore)│
│ crypto: Identity, PacketSigner, PrivateMessageCipher │ IdentityStore      │
│ ai: TextFeaturizer, ClassifierModel, EmergencyClass- │                    │
│     ifier, PeopleCountExtractor, PriorityScorer,     │                    │
│     IncidentGrouper · geo: Geo                       │                    │
├──────────────────── Transport ───────────────────────┴── Storage ─────────┤
│ NearbyTransport (Nearby Connections, P2P_CLUSTER)    │ Room / SQLite      │
└──────────────────────────────────────────────────────┴────────────────────┘
```

Dependency injection is manual: `MeshSOSApp` builds one `AppContainer` on a background thread. The UI reaches it through `LocalContainer`.

## How a message travels

1. **Compose.** The user types (or not) and taps Send SOS. `EmergencyClassifier` has already suggested type, severity, people and confidence; the user may change them.
2. **Originate.** `MeshEngine.sendSos` builds a `Packet`, `MeshRouter.originate` signs it with Ed25519 and marks its ID as seen, and Room stores it with status QUEUED. It goes into `PriorityForwardQueue` and the `pending_forward` table.
3. **Send.** For each connected neighbour whose HELLO identified it, `flushTo` takes the best packets that neighbour has not had yet and sends them as Nearby BYTES payloads. A `PayloadTransferUpdate.SUCCESS` sets SENT.
4. **Relay.** The receiving phone's `MeshRouter.onReceive` decodes, validates, verifies the signature, checks the persistent seen-ID table, then decides: deliver locally? forward with TTL − 1? send a receipt? Relays within 2 hops of the origin send a signed RELAYED receipt.
5. **Deliver.** A phone in rescuer mode (or the DM recipient) stores the message and sends a signed DELIVERED receipt. Receipts are routed back through the mesh like any packet.
6. **Confirm.** The sender's phone receives the receipts addressed to it and raises the status (statuses only ever move forward). A DELIVERED receipt seen by any relay also removes that message from the relay's queue.

## Packet format (wire version 1)

Big-endian, built with `java.io.Data*`:

| Field | Size | Signed | Notes |
|---|---|---|---|
| magic `MS`, version, type, flags | 6 B | yes | flags announce optional fields |
| message ID | 16 B | yes | random |
| sender ID | 16 B | yes | SHA-256(Ed25519 public key)[0..16] |
| sender Ed25519 key, X25519 key | 32 + 32 B | yes | lets anyone verify and reply privately |
| sender name | ≤ 160 B | yes | |
| created at | 8 B | yes | sender's clock |
| original TTL | 1 B | yes | caps the TTL forever |
| TTL, hop count | 2 B | **no** | rewritten by each relay |
| last hop ID | 16 B (opt) | **no** | lets the next relay avoid sending back |
| recipient ID | 16 B (opt) | yes | DMs and receipts |
| category, severity, people, AI confidence | 8 B | yes | |
| latitude, longitude, accuracy | 20 B (opt) | yes | only for SOS |
| text | ≤ 4000 B | yes | empty for DMs |
| ephemeral key + ciphertext | 32 B + ≤ 8000 B (opt) | yes | DMs |
| ref message ID + receipt kind | 17 B (opt) | yes | receipts |
| battery | 1 B | yes | HELLO |
| signature | 64 B | — | Ed25519 over every signed field |

Validation rejects: wrong magic or version, truncated data, trailing bytes, TTL above the original, over-long fields, bad coordinates, a timestamp more than 24 h in the future (offline clocks drift) or older than 48 h, a HELLO with a non-zero TTL, and a DM or receipt missing required fields.

## Why P2P_CLUSTER, and what it cannot do

`P2P_CLUSTER` is Nearby's M-to-N strategy: every phone can advertise, discover and hold several connections at once, which is what a mesh needs. `P2P_STAR` forces one hub, and `P2P_POINT_TO_POINT` allows only one connection. The trade-off is bandwidth (mostly Bluetooth), which is fine for short text packets. Nearby never forwards anything on its own, so relaying is entirely `MeshRouter`'s job, and a phone in the middle must be connected to both sides at the same time, or carry the message until it meets the next phone (store-carry-forward).

Connection set-up uses a tie-break (lower node ID requests first; the other phone retries after 7 s), and at most 6 simultaneous connections per phone.

## Security model

- **Identity:** an Ed25519 signing key and an X25519 agreement key, generated on first launch with Tink, and stored encrypted under an AES-256-GCM key inside the Android Keystore. No hard-coded keys.
- **Authenticity (FR10):** every packet is signed. The node ID is derived from the key, so a forger cannot claim someone else's ID.
- **Private messages (FR11):** for every message, a fresh X25519 key pair; ECDH with the recipient's long-term X25519 key; HKDF-SHA256 (salt = message ID, info binds both IDs and the ephemeral key) gives a one-time AES-256 key; AES-GCM with a random 96-bit IV and the header as associated data. One key per message means nonce reuse is impossible.
- **Key trust:** keys arrive inside signed packets, so they cannot be altered on the way, but a nearby attacker could present *their own* keys under a familiar name. The chat screen therefore shows a 12-digit **safety code** for people to compare face to face, and marks the contact *Verified*.
- **Public vs private:** SOS and broadcasts are signed but deliberately not encrypted, because relays and rescuers must read them. DMs are encrypted end to end; relays see only sender, recipient and size.
- **Logging:** no private keys or message contents are logged.

## AI pipeline

| Feature | Training (Python) | On the phone (Kotlin) |
|---|---|---|
| AI-1/2/3 classifier | `ml/train_classifier.py`: word 1–2 grams + char 2–4 grams, TF-IDF, multinomial logistic regression with three heads (type, severity, concept) | `ClassifierModel` reads the binary file; `EmergencyClassifier` returns type (or UNCLASSIFIED below 0.60), severity, confidence, people count, concept vector |
| People count | — | `PeopleCountExtractor`: only numbers the sender wrote ("৩ জন", "5 jon", "we are 4") |
| AI-4 priority | `sim/mesh_sim.py` + `sim/train_priority.py` | `RulePriorityScorer` (default) or `LearnedPriorityScorer`, both with aging (+0.35 per minute, capped at 4) and battery-aware relaying |
| AI-5 grouping | `ml/grouping_eval.py` tunes thresholds | `IncidentGrouper`: similarity = max(concept cosine, TF-IDF cosine); joins only within 250 m and 45 min; a different category needs ≥ 0.85; no-location reports merge only with the same sender |

## Background execution

`MeshService` is a foreground service of type `connectedDevice`. While it runs, discovery, advertising and relaying continue with the screen off. If Android kills the process (low memory, aggressive vendor battery savers) or the user swipes the app away on some brands, relaying stops until the app is opened again. Queued packets survive in Room and resume on the next start.
