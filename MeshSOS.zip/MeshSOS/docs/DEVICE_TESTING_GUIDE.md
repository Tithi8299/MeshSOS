# Physical-device testing guide

These tests need real Android phones. Nothing here can be simulated honestly. Record every result, pass or fail, in `docs/TEST_REPORT.md`.

## What you need

- 3 to 6 Android phones (Android 8.0 or newer), ideally different brands, all with Google Play services.
- The same MeshSOS build installed on every phone (`adb install -r app-debug.apk`).
- A notebook or spreadsheet, and a stopwatch for anything not timed by the app.

## Prepare every phone

1. Install the APK and open MeshSOS. Read the privacy notice, enter a different name on each phone (A, B, C…), and tap **I understand, continue**.
2. Allow every permission Android asks for (Nearby devices, Location, Notifications).
3. **Go offline:** turn on **airplane mode**, then turn **Bluetooth** back on, and turn **Wi-Fi** back on *without* joining any network. Remove the SIM if you want to be strict.
4. On brands with aggressive battery savers (Xiaomi, Oppo, Vivo, Realme, Samsung), set MeshSOS's battery usage to **Unrestricted**, or the service may be killed.
5. On the phone that plays the rescuer, open **Settings** and turn on **Rescuer mode**.

Useful while testing: **Settings → Diagnostics** shows packet counters (received, forwarded, dropped, duplicates, bad signatures, TTL) and the scanning duty cycle.

## Test A: two phones exchange messages without internet (FR1, FR2, FR7)

1. Put phones A and B 1 to 3 m apart, both offline, both on the **Nearby** tab.
2. **Pass if** each phone lists the other as *Connected* within about 30 s.
3. On A, tap the send icon next to B and send "test 1". On B, reply "test 2".
4. **Pass if** both messages appear on the other phone and A's bubble shows *Delivered*.

## Test B: three-phone multi-hop relay (FR3, FR9, NFR1)

Goal: A cannot reach C directly, so the message must go A → B → C.

1. Make A and C unable to see each other: put them far apart (40 to 100 m, or on different floors, or with walls between them) and B in the middle. Check on A's Nearby tab that only B is connected, and on C's that only B is connected.
2. Turn on **Rescuer mode** on C.
3. On A: **SOS** → type "Test B: father not breathing" → **Send SOS**.
4. **Pass if** A's Delivery screen reaches *Sent*, then *Relayed* (by B, hop 1), then *Delivered* (by C, 2 hops), and C shows the SOS with the exact original text.
5. **NFR1:** write down the "x s" figure on the Delivered line. Target: under 10 s with good signal.
6. Repeat 5 times and record each latency.

## Test C: duplicate suppression (FR5)

1. Connect A, B and C all to one another (close together), so every phone hears the SOS from two directions.
2. Send one SOS from A.
3. **Pass if** B and C each show the SOS **once** in the Inbox, and their Diagnostics *duplicate* counter goes up.

## Test D: TTL stops forwarding (FR4)

The default TTL is 6, which is too long to exhaust with a handful of phones. For this test only:

1. In `core/.../packet/Packet.kt`, temporarily set `DEFAULT_TTL = 1`, rebuild and install on all phones.
2. Line up A – B – C – D so each phone only reaches its neighbours (as in Test B).
3. Send an SOS from A.
4. **Pass if** B and C receive it (TTL 1 → 0 at C), D never receives it, and C's Diagnostics *TTL* counter goes up.
5. Set `DEFAULT_TTL` back to 6.

## Test E: a message stays queued with no neighbour (FR8)

1. Use phone A alone (all other phones off or far away).
2. Send an SOS.
3. **Pass if** the Delivery screen shows *Queued* only, Home shows "1 message waiting", and the status stays *Queued*.
4. Force-stop MeshSOS (Android Settings → Apps → MeshSOS → Force stop), then open it again.
5. **Pass if** the message is still waiting (it survived the restart).

## Test F: a queued message is sent when a neighbour appears (FR8)

1. Continue from Test E. Bring phone B (rescuer mode on) close and open MeshSOS on it.
2. **Pass if**, once they connect, A's status moves to *Sent* and then *Delivered*, without any action on A.

## Test G: SOS carries GPS when available (FR6, NFR7)

1. Go outdoors with a clear sky. On A, open **New SOS** and wait for "GPS location attached" with coordinates.
2. Send it to B.
3. **Pass if** B's SOS detail shows the same coordinates, plus distance and direction (B needs its own fix too).
4. Indoors with no fix: **Pass if** the SOS is still sent, and B shows "The sender did not include a location."
5. Privacy check: in Android Settings → Location → *App location permissions*, MeshSOS must show only "Allowed while using the app".

## Test H: private messages are encrypted (FR11)

1. With A – B – C in a line (as in Test B), send a private message from A to C (open C's SOS, tap **Reply**, or use the Nearby tab).
2. **Pass if** C reads it. B relays it (B's *forwarded* counter goes up) but the message **does not** appear in B's Inbox.
3. Optional proof: `adb pull` B's database (`/data/data/com.meshsos.app/databases/meshsos.db`, debug build, `adb shell run-as com.meshsos.app`) and confirm the text is not in `messages` or `pending_forward` in readable form.

## Test I: invalid signatures are rejected (FR10)

On the phone, this is covered by the automated tests (`RoutingTest.tamperedPacketIsRejected`, `TinkInteropTest`). To try it live, build a debug variant that flips one byte in every outgoing SOS (for example in `MeshEngine.flushTo`, change `bytes[bytes.size - 70]` before sending), install it on A only, and send an SOS.

**Pass if** B never shows it and B's *bad signature* counter goes up. Remove the change afterwards.

## Test J: AI classification works offline (AI-6, NFR3)

1. With every phone in airplane mode, open **New SOS** and type: "বাবা শ্বাস নিচ্ছে না", then "Pani uthche, 5 jon, nouka lagbe", then "ভাই একটু আসেন please".
2. **Pass if** the suggestions appear instantly: Medical/Critical, then Flood/High with 5 people, then *Unclassified* (below 60 %).
3. **NFR3:** Settings → Diagnostics → **Time the classifier**. Record the average and slowest times. Target: under 1000 ms on a mid-range phone.

## Test K: duplicate reports are grouped (AI-5)

1. Phones A, B and C stand within 100 m of each other; D is the rescuer (rescuer mode on).
2. Within a few minutes, send: from A "My father has stopped breathing", from B "বাবা শ্বাস নিচ্ছে না", from C "Baba shash nicche na". Then, from A, also send "Fire at the market".
3. **Pass if** D's **Incidents** tab shows one *Medical* incident with 3 reports and a separate *Fire* incident with 1 report.

## Test L: power saving changes scanning (FR12, NFR4)

1. On A, keep power saving **off** for 2 hours, unplugged, screen off, MeshSOS running. Then check Settings → Diagnostics: the duty cycle should be close to 100 %, and *Battery use* shows % per hour for normal mode.
2. Turn power saving **on** and repeat for 2 hours. The duty cycle should drop to about 17 % (5 s out of every 30 s), and *Battery use* shows the power-saving figure.
3. **Record** both battery figures and the phone model. Also note: with power saving on, a new phone can take up to 30 s to be found.

## After testing

Fill in docs/TEST_REPORT.md → "Physical-device results" with the date, phone models, Android versions, distances and every figure, including failures.
