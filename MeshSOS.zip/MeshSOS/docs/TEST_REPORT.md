# Test report

Every number in this report came from actually running the code, on 25 and 26 November 2026, in a Linux build environment (Python 3.13, scikit-learn 1.9.1, NetworkX 3.7). Anything that was **not** run is marked as such.

## 1. What was run, and what was not

| Suite | Run? | Result |
|---|---|---|
| Dataset generation (`ml/generate_dataset.py`) | Yes | 3,971 rows, 450 templates |
| Classifier training and evaluation (`ml/train_classifier.py`) | Yes | See section 2 |
| Exported model vs scikit-learn (`ml/meshsos_model.py`) | Yes | **Pass**: max abs difference 5.16 × 10⁻⁷ over 60 golden vectors |
| Grouping evaluation (`ml/grouping_eval.py`) | Yes | See section 4 |
| Priority model training and simulation (`sim/`) | Yes | See section 3 |
| Kotlin expected values cross-checked in Python | Yes | Normalisation, n-grams, people counts, prototype messages, grouping and geo cases all match the values asserted in the Kotlin tests |
| `./gradlew :core:test` (30 JUnit tests) | **No** | Kotlin compiler download blocked by the environment's safety policy; Maven Central unreachable |
| `./gradlew :app:testDebugUnitTest` | **No** | Android SDK unreachable |
| `./gradlew :app:connectedDebugAndroidTest` | **No** | Needs a phone |
| Physical-device tests A to L | **No** | Need phones (docs/DEVICE_TESTING_GUIDE.md) |

## 2. Emergency classifier (AI-1, AI-2, AI-3, NFR2)

Model: word 1–2 grams + character 2–4 grams, TF-IDF (sublinear tf), multinomial logistic regression (C = 16, balanced class weights). 11,545 features; the model file is 2.06 MB.

### Model selection (grouped 5-fold CV on train + val, single-language rows, type macro F1)

| Model | C | Macro F1 |
|---|---|---|
| Logistic regression | 1 / 4 / 16 | 0.740 / 0.746 / 0.747 |
| Linear SVM | 0.1 / 0.5 / 2 | 0.762 / 0.759 / 0.755 |

A feature sweep (char ranges 1–3, 1–4, 2–4, 2–5, 3–5; with and without word n-grams) moved CV F1 by at most 0.004, so the default was kept. Logistic regression was chosen over the SVM, although the SVM is about 0.015 better, because the app needs calibrated probabilities for the confidence score and the 60 % Unclassified rule.

### Held-out test set (774 messages from 150 templates never seen in training)

| Metric | Logistic regression | Linear SVM |
|---|---|---|
| Accuracy | 0.774 | — |
| Macro precision | 0.850 | — |
| Macro recall | 0.727 | — |
| **Macro F1** (target ≥ 0.80) | **0.756: not met** | 0.762 |

| Class | F1 |
|---|---|
| fire | 0.849 |
| trapped | 0.841 |
| medical | 0.810 |
| missing | 0.805 |
| flood | 0.802 |
| other | 0.675 |
| food and water | 0.509 |

| Language | Macro F1 |
|---|---|
| mixed | 0.824 |
| Banglish | 0.782 |
| Bangla | 0.708 |
| English | 0.647 |

- Severity macro F1: 0.575. **Critical-message recall: 0.753.**
- 64 % of test messages reach the 60 % confidence threshold; on those, macro F1 is 0.801. The other 36 % are sent as Unclassified, with their original text.
- History: dataset v1 scored 0.700. Adding more phrasings to every subtype (v2) raised it to 0.756.

### Hand-written challenge set (70 messages, never used for training or tuning)

- Type macro F1 **0.858** (accuracy 0.857); severity macro F1 0.763; critical recall 0.800; 81 % above the confidence threshold.
- Row-level predictions: `ml/reports/challenge_predictions.csv`.
- The set is small, so this does **not** establish that NFR2 is met.

### Latency (NFR3)

Not measured on a phone yet. The model is one sparse dot product per head, so it should be well under the 1 s target; measure it with Settings → Diagnostics → *Time the classifier*.

## 3. Priority-aware forwarding (AI-4)

Discrete-time simulator (`sim/mesh_sim.py`): random-waypoint mobility, NetworkX geometric graph rebuilt each second, one packet per link per second, per-link loss, TTL, duplicate suppression, low-battery throttling, two rescuer endpoints, 12 % critical / 28 % high / 60 % normal traffic. Eight scenarios: static 40 nodes, walking 40, dense 80, sparse 25, heavy load, TTL 3, TTL 10, 70 % low-battery phones.

The learned model is a logistic regression trained on 321,911 transmission attempts logged under a random queue order. Its label is "this transmission led to a timely delivery". Hold-out AUC: 0.668.

**Selection, honestly reported:** on 4 selection seeds the learned model had the best critical p90 latency and was pre-selected. On 4 fresh seeds it was not better than FIFO, so the comparison was rerun with **20 fresh seeds (301–320)**:

| Policy | Critical median | Critical p90 | Critical delivery | Normal median | Normal delivery |
|---|---|---|---|---|---|
| FIFO | 3.4 s | 56.7 s | 0.925 | 2.6 s | 0.928 |
| **Rule (app default)** | **2.3 s** | **49.1 s** | **0.928** | 2.6 s | 0.928 |
| Learned | 2.9 s | 54.6 s | 0.923 | 3.4 s | 0.926 |
| Hybrid | 3.7 s | 54.0 s | 0.927 | 3.3 s | 0.927 |

(Means over the eight scenarios.)

- Rule-based priority cuts critical median latency by about a third compared with FIFO (3.4 → 2.3 s) and p90 latency by 13 % (56.7 → 49.1 s), **without starving routine messages** (normal delivery ratio unchanged at 0.928).
- The learned model beat FIFO but not the rule, so the app defaults to **Rule** and offers **Learned** in Settings as experimental.
- Differences are modest because the simulated network is rarely congested. In the heavy-load scenario: critical p90 FIFO 66.8 ± 10.8 s, Rule 50.8 ± 9.3 s, Learned 54.9 ± 12.9 s (± standard error).

## 4. Duplicate-report grouping (AI-5)

Synthetic scenarios: 6 to 10 incidents over two hours in a 3 km square, 1 to 6 reports each in mixed languages, sent from up to 150 m away over 25 minutes, 8 % without GPS, plus deliberate hard negatives (a different emergency of the same category 120 to 400 m away, and the same emergency 2.8 km away). Thresholds were tuned on scenarios built from validation messages and scored on scenarios built from test messages.

| Method (test scenarios) | Pairwise precision | Recall | F1 |
|---|---|---|---|
| Same category + distance + time only (naive baseline) | 0.824 | 0.608 | 0.700 |
| TF-IDF text similarity + distance + time | 0.994 | 0.392 | 0.562 |
| Concept embedding + distance + time | 0.849 | 0.803 | 0.826 |
| **Combined: max(concept, TF-IDF) (used in the app)** | **0.874** | **0.804** | **0.838** |

Selected settings: text threshold 0.25, 250 m, 45 minutes, 0.85 for different categories.

## 5. Kotlin unit tests (written, not yet run)

`core/src/test`: 30 tests in `PacketAndCryptoTest`, `RoutingTest` and `AiAndGeoTest`, covering packet round-trips, truncated and garbage input, which fields are signed, ID forgery, HKDF against RFC 5869 test case 1, X25519 symmetry, DM confidentiality and tampering, safety codes, two-hop relay with RELAYED and DELIVERED receipts, duplicates, TTL exhaustion, TTL inflation, tampering, own echoes, relay switch, loop freedom in a 5-phone ring, priority order with aging, per-neighbour sending, low-battery relaying, Kotlin-vs-Python classifier parity, normalisation, people counts, grouping and geo.

`app/src/test`: the bundled model files load and classify. `app/src/androidTest`: Room DAOs and the Tink provider on a real device.

## 6. Physical-device results

*Not run yet. Fill in this section after following docs/DEVICE_TESTING_GUIDE.md.*

| Test | Date | Phones (model, Android) | Result | Notes / figures |
|---|---|---|---|---|
| A Two phones | | | | |
| B Three-phone relay (NFR1 latency) | | | | |
| C Duplicates | | | | |
| D TTL | | | | |
| E Queued with no neighbour | | | | |
| F Retry on reconnect | | | | |
| G GPS | | | | |
| H Encryption | | | | |
| I Bad signature | | | | |
| J AI offline (NFR3 latency) | | | | |
| K Grouping | | | | |
| L Power saving (NFR4 battery) | | | | |
