# Known limitations

An honest list of what this prototype does not do, or does only partly.

## Build and verification

- **The Android app and the Kotlin core were not compiled in the environment where they were written.** That environment blocks Google Maven, Maven Central and the Android SDK, and its safety policy blocked downloading the Kotlin compiler. The Python side was fully run. Expect a few compile errors on the first build in Android Studio.
- **No physical-device test has been run.** Every networking, GPS, battery and latency claim must be confirmed with docs/DEVICE_TESTING_GUIDE.md.

## Networking

- **Range and topology.** Nearby Connections with `P2P_CLUSTER` mostly uses Bluetooth, so each hop covers roughly 10 to 50 m depending on walls. Coverage depends on how many people run the app.
- **Connection limits.** Phones handle only a few simultaneous Bluetooth connections; the app caps itself at 6. Large crowds will form a partial mesh.
- **Background execution.** Relaying works while the foreground service runs. If Android or a vendor battery saver kills the app, or the user force-stops it, that phone stops relaying until MeshSOS is opened again.
- **Link quality** is not radio signal strength (Nearby does not expose RSSI). It is a blend of measured transfer success and Nearby's reported bandwidth quality.
- **Connection medium** (Bluetooth vs Wi-Fi) is not shown, because Nearby does not report it to the app.
- **Power saving** duty-cycles discovery only. Advertising stays on, or nobody could find the phone. The battery saving still has to be measured.
- **Receipts** are flooded back through the mesh like other packets. That is fine for a handful of phones but would need reverse-path routing in a large deployment.
- **The two-hop latency** shown as "Delivered … x s" uses the sender's own clock for both ends, so it is accurate even when phones disagree about the time.

## Security

- **Rescuer mode is self-declared.** Anyone can turn it on. A real deployment would need rescuer keys signed by an authority.
- **Key trust is trust-on-first-use.** Packets cannot be altered on the way, but a nearby attacker could introduce their own key under a familiar name. The safety code protects only contacts who compared it in person.
- **No forward secrecy for the recipient.** If a recipient's long-term X25519 key were stolen, past private messages to them could be decrypted. (Each message does use a fresh sender key.)
- **SOS messages are public by design**: relays and rescuers must read them, and that includes the location.
- **Signatures prove who sent a message, not that it is true.** False alarms are limited by the rate limit and the hide button, not prevented.
- A replayed HELLO could make one link show the wrong name. It cannot forge messages.

## AI

- **The classifier misses the 80 % macro F1 target**: 0.756 on held-out templates. *Food and water* (F1 0.51) and *other* (0.68) are the weakest classes, and English is the weakest language (0.65).
- **The training data is synthetic** (template-generated with an LLM's help, see ml/DATASET.md). Real disaster messages will be messier. The 70-message hand-written challenge set scored 0.858, which is encouraging but far too small to prove the target.
- **No neural model was used.** A pretrained multilingual transformer (for example a sentence-transformers model) could not be downloaded in the build environment, and would also need a TFLite/ONNX runtime on the phone. The linear model runs in plain Kotlin and can be checked against scikit-learn exactly. Trying a small multilingual model is the obvious next step once you have real data.
- **TensorFlow Lite is not used** for the same reason: the model is a sparse linear model, which needs no runtime. The proposal named TFLite; this is a documented deviation.
- **The learned priority model did not beat the transparent rule** in simulation, so rule-based is the default. The simulator also rarely becomes congested, so all differences between policies are modest.
- **Grouping was evaluated on synthetic scenarios** built from the same synthetic messages. Real performance is unknown until Test K and real use.
- **People count** is a small parser. It only reports numbers the sender wrote, and only in the patterns it knows.
- **Severity** depends on how the dataset authors labelled it. Severity macro F1 is 0.575 on held-out templates.

## Interface

- **Fonts.** The prototype uses Barlow, Barlow Condensed and IBM Plex Mono. The app uses the system's condensed sans and monospace so it works offline from the first launch. Bundle the TTF files in `res/font` to match exactly.
- **The compass is north-up.** The needle shows the true bearing to the sender; it does not rotate with the phone (no magnetometer use).
- **Notifications** follow the phone's system language, not the in-app language switch.
- **No maps**, by design (out of scope in the proposal).
