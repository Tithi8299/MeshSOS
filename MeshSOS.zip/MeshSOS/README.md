# MeshSOS

**Offline emergency communication with on-device AI triage.** An Android app that lets nearby phones form a peer-to-peer mesh, so people can send SOS alerts, short messages and their GPS location when both the internet and the mobile network are down. An on-device AI reads each Bangla, English or Banglish message, suggests its type and severity, decides what is forwarded first, and groups duplicate reports for rescuers.

> **Read [PROJECT_STATUS.md](PROJECT_STATUS.md) first.** It says exactly what has been built, what was verified, and what still has to be tested on real phones.

## Repository layout

```
MeshSOS/
├── app/                     Android app (Kotlin, Jetpack Compose, Room, Nearby Connections, Tink)
│   ├── src/main/java/com/meshsos/app/
│   │   ├── data/            Room database (entities, DAOs) and repositories
│   │   ├── network/         MeshEngine + nearby/NearbyTransport (real Nearby Connections)
│   │   ├── security/        Tink Ed25519/X25519 provider, Android Keystore key vault
│   │   ├── location/        One-shot GPS fixes
│   │   ├── service/         Foreground service and notifications
│   │   └── ui/              The ten Compose screens, theme, components, navigation
│   ├── src/main/assets/models/   The trained models shipped in the APK
│   ├── src/test/            JVM unit tests
│   └── src/androidTest/     On-device tests (Room, Tink)
├── core/                    Pure Kotlin module: packets, routing, crypto glue, AI inference, geo
│   └── src/test/            JUnit tests (no Android needed)
├── ml/                      Dataset generator, training, evaluation, exported models, reports
├── sim/                     Mesh simulator and priority-model training
├── docs/                    Architecture, device-testing guide, test report, limitations
├── PROJECT_STATUS.md
└── REQUIREMENTS_TRACEABILITY.md
```

## 1. Open the project in Android Studio

1. Install **Android Studio** (Ladybug 2024.2 or newer) with the Android SDK for API 35.
2. **File → Open**, and choose the `MeshSOS` folder (the one with `settings.gradle.kts`).
3. Let Gradle sync. The first sync downloads Gradle 8.11.1 and every library, so it needs internet once.
4. If Android Studio suggests upgrading the Android Gradle Plugin or libraries, you can accept, but upgrade them together (see `gradle/libs.versions.toml`) and re-run the tests afterwards.

The project uses JDK 17. Android Studio's bundled JDK works.

## 2. Build the APK

From Android Studio: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.

From a terminal in the project folder:

```bash
./gradlew :app:assembleDebug          # app/build/outputs/apk/debug/app-debug.apk
./gradlew :app:assembleRelease        # minified, signed with the debug key for test phones
```

The release build is signed with the debug key so it installs on test phones without extra setup. Create your own signing key before you distribute the app anywhere.

## 3. Install on several phones

Enable **Developer options → USB debugging** on each phone, connect it, and run:

```bash
adb devices                                   # list connected phones
adb -s <serial> install -r app/build/outputs/apk/debug/app-debug.apk
```

Or copy the APK to each phone and open it (allow "install unknown apps"). Every phone needs Google Play services, because Nearby Connections is part of it.

## 4. Test offline communication

Follow **[docs/DEVICE_TESTING_GUIDE.md](docs/DEVICE_TESTING_GUIDE.md)**. In short: put every phone in airplane mode, then switch **Bluetooth** (and Wi-Fi, without joining a network) back on, open MeshSOS on each phone, and accept the permissions. The phones find each other on the **Nearby** tab within a few seconds.

## 5. Run the tests

```bash
./gradlew :core:test                  # routing, TTL, duplicates, signatures, encryption, AI parity, grouping, geo
./gradlew :app:testDebugUnitTest      # bundled model files load and classify
./gradlew :app:connectedDebugAndroidTest   # with a phone attached: Room and Tink on the device
```

`:core:test` needs no Android SDK at all, only a JDK and internet for the first download.

## 6. Train the models

Requires Python 3.10+ with `numpy pandas scikit-learn scipy networkx`:

```bash
pip install numpy pandas scikit-learn scipy networkx
python3 ml/generate_dataset.py        # writes ml/data/meshsos_dataset.csv (synthetic, see ml/DATASET.md)
python3 ml/train_classifier.py        # trains, evaluates, exports ml/models/meshsos_classifier.bin
python3 ml/meshsos_model.py           # checks the exported file reproduces scikit-learn (run from ml/)
python3 ml/grouping_eval.py           # tunes and evaluates duplicate-report grouping
python3 sim/train_priority.py         # trains the learned priority model from simulation
python3 sim/mesh_sim.py --seeds $(seq -s, 301 320)   # FIFO vs rule vs learned, 20 seeds per scenario
```

The scripts are plain Python, so they also run in Google Colab: upload the `ml/` and `sim/` folders and run the same commands with `!python3 ...`.

## 7. Replace or update the model files

The app reads three files from `app/src/main/assets/models/`:

| File | Produced by | Used for |
|---|---|---|
| `meshsos_classifier.bin` | `ml/train_classifier.py` | Emergency type, severity and the concept embedding |
| `grouping_config.json` | `ml/grouping_eval.py` | Incident-grouping thresholds |
| `priority_model.json` | `sim/train_priority.py` | The optional learned forwarding priority |

After retraining:

```bash
cp ml/models/meshsos_classifier.bin ml/models/grouping_config.json app/src/main/assets/models/
cp sim/results/priority_model.json app/src/main/assets/models/
./gradlew :core:test        # the parity test compares Kotlin output with the new golden vectors
```

If you change `ml/featurizer.py`, you **must** make the same change in `core/.../ai/TextFeaturizer.kt`. The parity test fails if they drift apart.

## 8. Run the simulator

```bash
python3 sim/mesh_sim.py --quick                       # 2 seeds, about 15 s
python3 sim/mesh_sim.py --seeds $(seq -s, 301 320)    # the full comparison reported in docs/TEST_REPORT.md
```

Results go to `sim/results/simulation_results.json`. Scenarios (network size, density, mobility, battery, load, TTL) are defined in `SCENARIOS` at the bottom of `sim/mesh_sim.py`.

## More documentation

- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md): layers, packet format, routing, security model, AI pipeline
- [REQUIREMENTS_TRACEABILITY.md](REQUIREMENTS_TRACEABILITY.md): every FR, AI and NFR mapped to code and tests
- [docs/TEST_REPORT.md](docs/TEST_REPORT.md): what was actually run, with the real numbers
- [docs/KNOWN_LIMITATIONS.md](docs/KNOWN_LIMITATIONS.md): honest limits of the prototype
- [ml/DATASET.md](ml/DATASET.md): how the training data was made

MeshSOS does not replace 999 or any official emergency service.
