# Tink uses protobuf-lite reflection
-keep class com.google.crypto.tink.** { *; }
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
# Room entities are accessed by generated code only; nothing extra needed.
