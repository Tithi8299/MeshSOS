package com.meshsos.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalLayoutApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.meshsos.app.LocalContainer
import com.meshsos.app.R
import com.meshsos.app.data.database.Direction
import com.meshsos.app.data.database.MessageEntity
import com.meshsos.app.data.database.PeerEntity
import com.meshsos.app.location.Fix
import com.meshsos.app.location.FixResult
import com.meshsos.app.network.MeshEngine
import com.meshsos.app.ui.components.Avatar
import com.meshsos.app.ui.components.ChipToggle
import com.meshsos.app.ui.components.IconCircle
import com.meshsos.app.ui.components.KeyValue
import com.meshsos.app.ui.components.Lbl
import com.meshsos.app.ui.components.MeshButton
import com.meshsos.app.ui.components.MeshCard
import com.meshsos.app.ui.components.MeshIcons
import com.meshsos.app.ui.components.Pill
import com.meshsos.app.ui.components.PillKind
import com.meshsos.app.ui.components.PulseDot
import com.meshsos.app.ui.components.Seg
import com.meshsos.app.ui.components.SevPill
import com.meshsos.app.ui.components.SignalBars
import com.meshsos.app.ui.components.SmallIcon
import com.meshsos.app.ui.components.StripeItem
import com.meshsos.app.ui.components.TopBar
import com.meshsos.app.ui.components.categoryName
import com.meshsos.app.ui.components.initials
import com.meshsos.app.ui.components.relativeTime
import com.meshsos.app.ui.components.sevColor
import com.meshsos.app.ui.components.severityName
import com.meshsos.app.ui.navigation.Frame
import com.meshsos.app.ui.theme.LocalMesh
import com.meshsos.app.ui.theme.MeshType
import com.meshsos.core.crypto.Identity
import com.meshsos.core.geo.Geo
import com.meshsos.core.model.Category
import com.meshsos.core.model.DeliveryStatus
import com.meshsos.core.model.PacketType
import com.meshsos.core.model.Severity
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

/** This phone's position, used only on-screen for distance and direction. Never sent anywhere. */
@Composable
fun rememberMyFix(): Fix? {
    val container = LocalContainer.current
    val r by produceState<FixResult?>(null) { value = container.location.currentFix(timeoutMillis = 8_000, maxLastKnownAgeMillis = 30 * 60_000) }
    return (r as? FixResult.Ok)?.fix
}

@Composable
fun compassName(d: Geo.Compass) = stringResource(when (d) {
    Geo.Compass.N -> R.string.dir_n; Geo.Compass.NE -> R.string.dir_ne; Geo.Compass.E -> R.string.dir_e; Geo.Compass.SE -> R.string.dir_se
    Geo.Compass.S -> R.string.dir_s; Geo.Compass.SW -> R.string.dir_sw; Geo.Compass.W -> R.string.dir_w; Geo.Compass.NW -> R.string.dir_nw
})

// ------------------------------------------------------------------------- 5. Nearby devices
@Composable
fun NearbyScreen(onChat: (String) -> Unit) {
    val c = LocalMesh.current
    val container = LocalContainer.current
    val mesh by container.engine.state.collectAsStateWithLifecycle()
    val peers by container.db.peers().observeAll().collectAsStateWithLifecycle(emptyList())
    val connected = peers.filter { it.connected }
    val recent = peers.filter { !it.connected && System.currentTimeMillis() - it.lastSeen < 24 * 3600_000L }
    ScreenColumn {
        TopBar(stringResource(R.string.nearby)) {
            if (mesh.discovering) Pill(stringResource(R.string.scanning), PillKind.OK, leading = { PulseDot(c.ok) })
            else Pill(stringResource(R.string.scan_paused), PillKind.UNCL)
        }
        MeshCard {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallIcon(MeshIcons.Bolt, c.mesh)
                Text(stringResource(if (mesh.powerSaving) R.string.scan_line_saving else R.string.scan_line_normal), style = MeshType.small, color = c.mute)
            }
        }
        Lbl(stringResource(R.string.phones_in_range, connected.size + mesh.discovered.size), Modifier.padding(top = 4.dp))
        for (p in connected) PeerRow(p, stringResource(R.string.state_connected), onChat)
        for (d in mesh.discovered) StripeItem(null, null) {
            Avatar(initials(d.name, "?"), false)
            Column(Modifier.weight(1f)) {
                Text(d.name.ifBlank { "MeshSOS" }, style = MeshType.bodyStrong, color = c.ink)
                Text(stringResource(if (d.connecting) R.string.state_connecting else R.string.state_found), style = MeshType.small, color = c.mute)
            }
            if (!d.connecting) ChipToggle(stringResource(R.string.connect), false, { container.engine.connect(d.endpointId) })
        }
        if (connected.isEmpty() && mesh.discovered.isEmpty()) Text(stringResource(R.string.no_peers), style = MeshType.body, color = c.mute)
        for (p in recent) PeerRow(p, stringResource(R.string.state_lost) + " · " + relativeTime(p.lastSeen), onChat)
        MeshButton(stringResource(R.string.message_everyone), { onChat(MeshEngine.BROADCAST_PEER) }, kind = "ghost", icon = MeshIcons.Users)
        Text(stringResource(R.string.low_batt_note), style = MeshType.small, color = c.mute)
    }
}

@Composable
private fun PeerRow(p: PeerEntity, state: String, onChat: (String) -> Unit) {
    val c = LocalMesh.current
    StripeItem(null, null) {
        Avatar(initials(p.displayName, p.nodeId), p.isRescuer)
        Column(Modifier.weight(1f)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(p.displayName.ifBlank { p.nodeId.take(6) }, style = MeshType.bodyStrong, color = c.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (p.isRescuer) Pill(stringResource(R.string.rescuer), PillKind.CRIT)
                if (p.verified) Pill(stringResource(R.string.verified), PillKind.OK)
            }
            val meta = buildList {
                add(state)
                add(if (p.connected) stringResource(R.string.one_hop) else stringResource(R.string.hops_n, p.minHops))
                add(p.linkQuality?.let { stringResource(R.string.link_quality, (it * 100).toInt()) } ?: stringResource(R.string.link_unknown))
                if (p.batteryPercent >= 0) add(stringResource(R.string.battery_pct, p.batteryPercent))
            }.joinToString(" · ")
            Text(meta, style = MeshType.small, color = c.mute)
        }
        if (p.connected) SignalBars(p.linkQuality?.let { (it * 4).toInt().coerceIn(1, 4) } ?: 0)
        IconCircle(MeshIcons.Send, stringResource(R.string.message_peer, p.displayName.ifBlank { p.nodeId.take(6) }), { onChat(p.nodeId) })
    }
}

// ------------------------------------------------------------------------- 6. Inbox
private enum class InboxFilter { ALL, SOS, CHATS }

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun InboxScreen(onSos: (String) -> Unit, onChat: (String) -> Unit) {
    val c = LocalMesh.current
    val container = LocalContainer.current
    val sos by container.db.messages().observeReceivedSos().collectAsStateWithLifecycle(emptyList())
    val chats by container.db.messages().observeChatHeads().collectAsStateWithLifecycle(emptyList())
    val peers by container.db.peers().observeAll().collectAsStateWithLifecycle(emptyList())
    var filter by remember { mutableStateOf(InboxFilter.ALL) }
    var sevFilter by remember { mutableStateOf<Severity?>(null) }
    var catFilter by remember { mutableStateOf<Category?>(null) }
    val me = rememberMyFix()
    val names = peers.associate { it.nodeId to it.displayName }

    ScreenColumn {
        TopBar(stringResource(R.string.inbox))
        Seg(listOf(InboxFilter.ALL to stringResource(R.string.filter_all), InboxFilter.SOS to stringResource(R.string.filter_sos),
            InboxFilter.CHATS to stringResource(R.string.filter_chats)), filter, { filter = it })
        if (filter != InboxFilter.CHATS) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                ChipToggle(stringResource(R.string.any_severity), sevFilter == null, { sevFilter = null })
                for (s in Severity.entries) ChipToggle(severityName(s), sevFilter == s, { sevFilter = if (sevFilter == s) null else s })
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                ChipToggle(stringResource(R.string.any_type), catFilter == null, { catFilter = null })
                for (k in Category.entries) ChipToggle(categoryName(k), catFilter == k, { catFilter = if (catFilter == k) null else k })
            }
        }
        val sosShown = if (filter == InboxFilter.CHATS) emptyList() else sos.filter {
            (sevFilter == null || it.severity == sevFilter!!.code) && (catFilter == null || it.category == catFilter!!.code)
        }
        val chatShown = if (filter == InboxFilter.SOS) emptyList() else chats
        val rows: List<Pair<Long, MessageEntity>> = (sosShown.map { it.receivedAt to it } + chatShown.map { it.createdAt to it }).sortedByDescending { it.first }
        if (rows.isEmpty()) Text(stringResource(R.string.empty_inbox), style = MeshType.body, color = c.mute)
        for ((_, m) in rows) {
            if (m.type == PacketType.SOS.code) SosRow(m, me) { onSos(m.id) }
            else ChatRow(m, names) { onChat(m.peerId) }
        }
    }
}

@Composable
fun SosRow(m: MessageEntity, me: Fix?, onClick: () -> Unit) {
    val c = LocalMesh.current
    val sev = Severity.fromCode(m.severity); val cat = Category.fromCode(m.category)
    val uncl = cat == Category.UNCLASSIFIED
    StripeItem(if (uncl) c.mute else sevColor(sev), onClick) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                SevPill(sev, uncl)
                if (!uncl) Text(categoryName(cat) + if (m.peopleCount > 0) " · " + pluralStringResource(R.plurals.people_n, m.peopleCount, m.peopleCount) else "",
                    style = MeshType.bodyStrong, color = c.ink)
                if (!m.read) Box(Modifier.size(8.dp).clip(CircleShape).background(c.sos))
            }
            Text(m.text, style = MeshType.body, color = c.ink, maxLines = 2, overflow = TextOverflow.Ellipsis)
            val parts = buildList {
                if (me != null && m.latitude != null && m.longitude != null) {
                    val d = Geo.distanceMeters(me.latitude, me.longitude, m.latitude, m.longitude)
                    add(Geo.formatDistance(d) + " " + Geo.compass(Geo.bearingDegrees(me.latitude, me.longitude, m.latitude, m.longitude)).name)
                }
                add(stringResource(R.string.hops_n, m.hopCount + 1))
                add(relativeTime(m.receivedAt))
            }
            Text(parts.joinToString(" · "), style = MeshType.small, color = c.mute)
        }
    }
}

@Composable
private fun ChatRow(m: MessageEntity, names: Map<String, String>, onClick: () -> Unit) {
    val c = LocalMesh.current
    val broadcast = m.peerId == MeshEngine.BROADCAST_PEER
    val name = if (broadcast) stringResource(R.string.broadcast_title) else names[m.peerId]?.ifBlank { null } ?: m.senderName.ifBlank { m.peerId.take(6) }
    StripeItem(null, onClick) {
        Avatar(if (broadcast) "∗" else initials(name, m.peerId), false)
        Column(Modifier.weight(1f)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(name, style = MeshType.bodyStrong, color = c.ink)
                if (!broadcast) SmallIcon(MeshIcons.Lock, c.mute, 14.dp)
            }
            Text(m.text, style = MeshType.body, color = c.ink, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Text(relativeTime(m.createdAt), style = MeshType.small, color = c.mute)
    }
}

// ------------------------------------------------------------------------- 7. Received SOS details
@Composable
fun DetailScreen(nav: NavHostController, messageId: String, onBack: () -> Unit, onReply: (String) -> Unit) {
    val c = LocalMesh.current
    val container = LocalContainer.current
    val scope = rememberCoroutineScope()
    val msg by container.db.messages().observe(messageId).collectAsStateWithLifecycle(null)
    val me = rememberMyFix()
    val incidentSize by produceState(0, messageId, msg) {
        value = container.db.incidents().incidentOf(messageId)?.let { container.db.incidents().reportCount(it) } ?: 0
    }
    val lastHopName by produceState<String?>(null, msg) { value = msg?.lastHopId?.let { container.db.peers().get(it)?.displayName } }
    var confirmHide by remember { mutableStateOf(false) }
    LaunchedEffect(messageId) { container.db.messages().markRead(messageId) }
    val m = msg
    Frame(nav, tabs = false, foot = {
        if (m != null) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MeshButton(stringResource(R.string.reply), { onReply(m.senderId) }, Modifier.weight(1f), icon = MeshIcons.Send)
            Box(Modifier.size(50.dp).clip(RoundedCornerShape(12.dp)).background(c.card).border(1.dp, c.line, RoundedCornerShape(12.dp))
                .clickable(role = Role.Button) { confirmHide = true }, contentAlignment = Alignment.Center) {
                Icon(MeshIcons.Flag, stringResource(R.string.hide_sender), tint = c.ink)
            }
        }
    }) {
        ScreenColumn {
            TopBar(stringResource(R.string.sos_alert), onBack) {
                Pill(stringResource(R.string.signature_valid), PillKind.OK, leading = { SmallIcon(MeshIcons.Shield, c.ok, 14.dp) })
            }
            if (m == null) return@ScreenColumn
            val sev = Severity.fromCode(m.severity); val cat = Category.fromCode(m.category)
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.critSoft).padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SevPill(sev, cat == Category.UNCLASSIFIED)
                Column(Modifier.weight(1f)) {
                    Text(categoryName(cat) + if (m.peopleCount > 0) " · " + pluralStringResource(R.plurals.people_n, m.peopleCount, m.peopleCount) else "",
                        style = MeshType.bodyStrong, color = c.ink)
                    Text(stringResource(R.string.ai_banner, (m.aiConfidence * 100).toInt()) + " " +
                        stringResource(if (m.userEdited) R.string.sender_edited else R.string.sender_confirmed), style = MeshType.small, color = c.mute)
                }
            }
            MeshCard {
                Lbl(stringResource(R.string.original_message))
                Text(m.text, style = MeshType.body.copy(fontSize = 15.sp), color = c.ink)
            }
            MeshCard {
                if (m.latitude == null || m.longitude == null) Text(stringResource(R.string.no_sender_location), style = MeshType.body, color = c.mute)
                else if (me == null) {
                    Text(formatCoord(m.latitude, m.longitude), style = MeshType.mono, color = c.ink)
                    Text(stringResource(R.string.my_location_unknown), style = MeshType.small, color = c.mute)
                } else {
                    val dist = Geo.distanceMeters(me.latitude, me.longitude, m.latitude, m.longitude)
                    val bearing = Geo.bearingDegrees(me.latitude, me.longitude, m.latitude, m.longitude)
                    val dir = compassName(Geo.compass(bearing))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Compass(bearing.toFloat(), stringResource(R.string.compass_cd, dir, Geo.formatDistance(dist)))
                        Column(Modifier.weight(1f)) {
                            Text(Geo.formatDistance(dist), style = MeshType.big, color = c.ink)
                            Text(stringResource(R.string.direction_of, dir), style = MeshType.bodyStrong, color = c.ink)
                            Text(formatCoord(m.latitude, m.longitude), style = MeshType.mono, color = c.mute, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            }
            MeshCard {
                KeyValue(listOf(
                    stringResource(R.string.received) to relativeTime(m.receivedAt) + " (" + DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(m.receivedAt)) + ")",
                    stringResource(R.string.path) to if (m.hopCount == 0) stringResource(R.string.path_direct)
                        else stringResource(R.string.path_via, m.hopCount + 1, lastHopName?.ifBlank { null } ?: m.lastHopId?.take(6) ?: "?"),
                    stringResource(R.string.other_reports) to if (incidentSize > 1) stringResource(R.string.same_incident, incidentSize - 1) else stringResource(R.string.none),
                    stringResource(R.string.from) to (m.senderName.ifBlank { "—" } + " · " + m.senderId.take(8)),
                ))
            }
        }
    }
    if (confirmHide && m != null) AlertDialog(
        onDismissRequest = { confirmHide = false },
        title = { Text(stringResource(R.string.block_title)) },
        text = { Text(stringResource(R.string.block_body, m.senderName.ifBlank { m.senderId.take(6) })) },
        confirmButton = { TextButton({ confirmHide = false; scope.launch { container.engine.setBlocked(m.senderId, true); container.incidents.regroupNow(); onBack() } }) {
            Text(stringResource(R.string.hide), color = c.sos) } },
        dismissButton = { TextButton({ confirmHide = false }) { Text(stringResource(R.string.cancel)) } },
    )
}

/** North-up compass: the needle points from this phone toward the sender (true bearing, no magnetometer). */
@Composable
private fun Compass(bearing: Float, cd: String) {
    val c = LocalMesh.current
    val tm = rememberTextMeasurer()
    val st = TextStyle(fontSize = 10.sp, color = c.mute)
    Canvas(Modifier.size(96.dp).semantics { contentDescription = cd }) {
        val r = size.minDimension / 2
        val ctr = Offset(size.width / 2, size.height / 2)
        drawCircle(c.line, r - 6.dp.toPx(), ctr, style = Stroke(2.dp.toPx()))
        for ((label, ang) in listOf("N" to 0f, "E" to 90f, "S" to 180f, "W" to 270f)) {
            val t = tm.measure(label, st)
            val rad = Math.toRadians(ang.toDouble())
            val p = Offset(ctr.x + (r - 14.dp.toPx()) * kotlin.math.sin(rad).toFloat(), ctr.y - (r - 14.dp.toPx()) * kotlin.math.cos(rad).toFloat())
            drawText(t, topLeft = Offset(p.x - t.size.width / 2, p.y - t.size.height / 2))
        }
        rotate(bearing, ctr) {
            val s = r / 42f
            val needle = Path().apply {
                moveTo(ctr.x, ctr.y - 28 * s); lineTo(ctr.x + 7 * s, ctr.y + 2 * s); lineTo(ctr.x, ctr.y - 2 * s); lineTo(ctr.x - 7 * s, ctr.y + 2 * s); close()
            }
            drawPath(needle, c.sos)
        }
        drawCircle(c.ink, 3.dp.toPx(), ctr)
    }
}

// ------------------------------------------------------------------------- 8. One-to-one chat
@Composable
fun ChatScreen(nav: NavHostController, peerId: String, onBack: () -> Unit) {
    val c = LocalMesh.current
    val container = LocalContainer.current
    val scope = rememberCoroutineScope()
    val broadcast = peerId == MeshEngine.BROADCAST_PEER
    val peer by container.db.peers().observe(peerId).collectAsStateWithLifecycle(null)
    val msgs by container.db.messages().observeChat(peerId).collectAsStateWithLifecycle(emptyList())
    var input by remember { mutableStateOf("") }
    var showCode by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    val list = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.animateScrollToItem(msgs.size - 1) }
    val name = if (broadcast) stringResource(R.string.broadcast_title) else peer?.displayName?.ifBlank { null } ?: peerId.take(6)

    Frame(nav, tabs = false, foot = {
        Column {
            if (failed) Text(stringResource(R.string.no_key), style = MeshType.small, color = c.sos, modifier = Modifier.padding(bottom = 6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(input, { input = it.take(1000) }, Modifier.weight(1f), placeholder = { Text(stringResource(R.string.message_hint)) },
                    shape = RoundedCornerShape(22.dp), maxLines = 4,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = c.mesh, unfocusedBorderColor = c.line,
                        focusedContainerColor = c.card, unfocusedContainerColor = c.card))
                val sendCd = stringResource(R.string.send)
                Box(Modifier.size(46.dp).clip(CircleShape).background(c.mesh).clickable(role = Role.Button) {
                    val t = input.trim()
                    if (t.isNotEmpty()) scope.launch {
                        val ok = if (broadcast) { container.engine.sendBroadcast(t); true } else container.engine.sendDirect(peerId, t)
                        failed = !ok
                        if (ok) input = ""
                    }
                }.semantics { contentDescription = sendCd }, contentAlignment = Alignment.Center) {
                    Icon(MeshIcons.Send, null, tint = c.app, modifier = Modifier.size(20.dp))
                }
            }
        }
    }) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IconCircle(MeshIcons.Back, stringResource(R.string.back), onBack)
                Avatar(if (broadcast) "∗" else initials(name, peerId), peer?.isRescuer == true)
                Column(Modifier.weight(1f)) {
                    Text(name, style = MeshType.screenTitle.copy(fontSize = 22.sp), color = c.ink)
                    val sub = when {
                        broadcast -> stringResource(R.string.broadcast_note)
                        peer?.connected == true -> stringResource(R.string.one_hop)
                        peer != null -> stringResource(R.string.state_lost) + " · " + relativeTime(peer!!.lastSeen)
                        else -> ""
                    }
                    Text(sub, style = MeshType.small, color = c.mute)
                }
                if (!broadcast && peer != null) IconCircle(MeshIcons.Shield, stringResource(R.string.safety_code), { showCode = true },
                    tint = if (peer!!.verified) c.ok else c.ink)
            }
            if (!broadcast) Box(Modifier.fillMaxWidth().padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                Pill(stringResource(R.string.encrypted_only, name), PillKind.NORM, leading = { SmallIcon(MeshIcons.Lock, c.mesh, 13.dp) })
            }
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(msgs, key = { it.id }) { m -> Bubble(m, broadcast) }
            }
        }
    }
    val p = peer
    if (showCode && p != null) AlertDialog(
        onDismissRequest = { showCode = false },
        title = { Text(stringResource(R.string.safety_code)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(Identity.safetyCode(container.identity.signing.publicKey, p.signingKey), style = MeshType.big.copy(fontSize = 28.sp), color = c.ink)
                Text(stringResource(R.string.safety_body, name), style = MeshType.body)
            }
        },
        confirmButton = { TextButton({ showCode = false; scope.launch { container.db.peers().setVerified(p.nodeId) } }) { Text(stringResource(R.string.mark_verified)) } },
        dismissButton = { TextButton({ showCode = false }) { Text(stringResource(R.string.cancel)) } },
    )
}

@Composable
private fun Bubble(m: MessageEntity, broadcast: Boolean) {
    val c = LocalMesh.current
    val mine = m.direction == Direction.OUT
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Column(Modifier.widthIn(max = 280.dp).clip(RoundedCornerShape(14.dp)).background(if (mine) c.mesh else c.card)
            .border(1.dp, if (mine) c.mesh else c.line, RoundedCornerShape(14.dp)).padding(horizontal = 11.dp, vertical = 8.dp)) {
            if (broadcast && !mine) Text(m.senderName.ifBlank { m.senderId.take(6) }, style = MeshType.small, color = c.mesh)
            Text(m.text, style = MeshType.body, color = if (mine) c.app else c.ink)
            val time = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(m.createdAt))
            val st = if (mine) " · " + stringResource(when (DeliveryStatus.fromCode(m.status)) {
                DeliveryStatus.QUEUED -> R.string.msg_queued; DeliveryStatus.SENT -> R.string.msg_sent
                DeliveryStatus.RELAYED -> R.string.msg_relayed; DeliveryStatus.DELIVERED -> R.string.msg_delivered
            }) else ""
            Text(time + st, fontSize = 11.sp, color = (if (mine) c.app else c.ink).copy(alpha = 0.75f))
        }
    }
}
