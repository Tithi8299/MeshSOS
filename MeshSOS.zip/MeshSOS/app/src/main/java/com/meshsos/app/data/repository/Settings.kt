package com.meshsos.app.data.repository

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class PriorityMode { RULE, LEARNED }

data class AppSettings(
    val onboarded: Boolean = false,
    val displayName: String = "",
    val powerSaving: Boolean = false,
    val relayEnabled: Boolean = true,
    val rescuerMode: Boolean = false,
    val language: String = "en",          // "en" or "bn"
    val priorityMode: PriorityMode = PriorityMode.RULE,
)

/** Small key-value settings in SharedPreferences, exposed as a StateFlow for the UI and the mesh engine. */
class SettingsRepository(context: Context) {
    private val prefs = context.getSharedPreferences("meshsos_settings", Context.MODE_PRIVATE)
    private val state = MutableStateFlow(read())
    val settings: StateFlow<AppSettings> = state.asStateFlow()

    private fun read() = AppSettings(
        onboarded = prefs.getBoolean("onboarded", false),
        displayName = prefs.getString("name", "") ?: "",
        powerSaving = prefs.getBoolean("power_saving", false),
        relayEnabled = prefs.getBoolean("relay", true),
        rescuerMode = prefs.getBoolean("rescuer", false),
        language = prefs.getString("lang", "en") ?: "en",
        priorityMode = runCatching { PriorityMode.valueOf(prefs.getString("priority", "RULE")!!) }.getOrDefault(PriorityMode.RULE),
    )

    fun update(change: (AppSettings) -> AppSettings) {
        val n = change(state.value)
        prefs.edit()
            .putBoolean("onboarded", n.onboarded).putString("name", n.displayName.take(40))
            .putBoolean("power_saving", n.powerSaving).putBoolean("relay", n.relayEnabled)
            .putBoolean("rescuer", n.rescuerMode).putString("lang", n.language)
            .putString("priority", n.priorityMode.name)
            .apply()
        state.value = n.copy(displayName = n.displayName.take(40))
    }
}
