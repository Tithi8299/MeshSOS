package com.meshsos.app.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.meshsos.app.MainActivity
import com.meshsos.app.MeshSOSApp
import com.meshsos.app.R
import com.meshsos.core.packet.Packet
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Foreground service that keeps discovery, advertising and relaying alive while the screen is off
 * (Android stops background Bluetooth work otherwise). Type "connectedDevice" (Android 14 rule).
 * If Android or the user kills the process, relaying stops until the app is opened again: we do
 * not pretend otherwise.
 */
class MeshService : LifecycleService() {
    override fun onCreate() {
        super.onCreate()
        val app = application as MeshSOSApp
        Notifier.ensureChannels(this)
        try {
            ServiceCompat.startForeground(this, Notifier.MESH_ID, Notifier.meshNotification(this, 0, true),
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE else 0)
        } catch (e: Exception) {
            // e.g. ForegroundServiceStartNotAllowedException or missing Bluetooth permission on Android 14
            Log.w("MeshService", "could not start in foreground: $e")
        }
        lifecycleScope.launch {
            val c = app.container.await()
            c.engine.start(c.settings.settings.value)
            launch { c.settings.settings.collectLatest { c.engine.applySettings(it) } }
            c.engine.state.collectLatest { s ->
                Notifier.updateMesh(this@MeshService, s.connectedCount, c.settings.settings.value.relayEnabled)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            lifecycleScope.launch { (application as MeshSOSApp).container.await().engine.stop() }
            stopSelf()
        }
        return START_STICKY
    }

    companion object {
        const val ACTION_STOP = "com.meshsos.app.STOP"
        fun start(context: Context) = ContextCompat.startForegroundService(context, Intent(context, MeshService::class.java))
    }
}

object Notifier {
    const val MESH_ID = 1
    private const val CH_MESH = "mesh"
    private const val CH_SOS = "sos"

    fun ensureChannels(c: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_MESH, c.getString(R.string.ch_mesh), NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_SOS, c.getString(R.string.ch_sos), NotificationManager.IMPORTANCE_HIGH).apply {
            enableVibration(true)
        })
    }

    private fun openApp(c: Context): PendingIntent = PendingIntent.getActivity(c, 0,
        Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    fun meshNotification(c: Context, connected: Int, relaying: Boolean): Notification =
        NotificationCompat.Builder(c, CH_MESH)
            .setSmallIcon(R.drawable.ic_stat_mesh)
            .setContentTitle(c.getString(R.string.notif_mesh_title))
            .setContentText(c.getString(R.string.notif_mesh_text, connected, c.getString(if (relaying) R.string.notif_on else R.string.notif_off)))
            .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(openApp(c))
            .build()

    private fun canPost(c: Context) = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun updateMesh(c: Context, connected: Int, relaying: Boolean) {
        if (canPost(c)) NotificationManagerCompat.from(c).notify(MESH_ID, meshNotification(c, connected, relaying))
    }

    private var appContext: Context? = null
    fun init(c: Context) { appContext = c.applicationContext }

    private fun post(id: Int, title: String, text: String) {
        val c = appContext ?: return
        if (!canPost(c)) return
        try {
            NotificationManagerCompat.from(c).notify(id, NotificationCompat.Builder(c, CH_SOS)
                .setSmallIcon(R.drawable.ic_stat_mesh).setContentTitle(title).setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_HIGH).setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setAutoCancel(true).setContentIntent(openApp(c)).build())
        } catch (e: SecurityException) { /* permission revoked meanwhile */ }
    }

    fun sos(p: Packet) {
        val c = appContext ?: return
        post(p.messageId.hashCode(), c.getString(R.string.notif_sos_title, p.senderName.ifBlank { p.senderId.take(6) }), p.text)
    }

    fun delivered(byName: String) {
        val c = appContext ?: return
        post(2, c.getString(R.string.app_name), c.getString(R.string.notif_delivered, byName))
    }

    fun directMessage(fromName: String, fromId: String) {
        val c = appContext ?: return
        post(fromId.hashCode(), c.getString(R.string.notif_dm, fromName.ifBlank { fromId.take(6) }), "🔒")
    }
}
