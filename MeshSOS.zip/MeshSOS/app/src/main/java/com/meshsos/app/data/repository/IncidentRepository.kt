package com.meshsos.app.data.repository

import com.meshsos.app.data.database.IncidentEntity
import com.meshsos.app.data.database.IncidentReportEntity
import com.meshsos.app.data.database.MeshDatabase
import com.meshsos.core.ai.EmergencyClassifier
import com.meshsos.core.ai.IncidentGrouper
import com.meshsos.core.ai.Report
import com.meshsos.core.model.Category
import com.meshsos.core.model.Severity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.nio.ByteBuffer

/**
 * AI-5 on the phone: recomputes incident groups from every SOS received in the last 24 h.
 * The concept embedding of each report is computed once on arrival and stored with the message.
 */
class IncidentRepository(
    private val db: MeshDatabase,
    private val classifier: Deferred<EmergencyClassifier?>,
    private val grouper: IncidentGrouper,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var pending: Job? = null

    suspend fun embed(text: String): ByteArray? {
        val c = classifier.await() ?: return null
        val v = c.classify(text).concept
        if (v.isEmpty()) return null
        return ByteBuffer.allocate(4 * v.size).apply { v.forEach { putFloat(it) } }.array()
    }

    fun regroupSoon() {
        pending?.cancel()
        pending = scope.launch { delay(800); regroupNow() }
    }

    suspend fun regroupNow() {
        val c = classifier.await()
        val since = System.currentTimeMillis() - 24 * 3600_000L
        val blocked = db.peers().blockedIds().toSet()
        val reports = db.messages().receivedSosSince(since).filter { it.senderId !in blocked }.map { m ->
            val r = c?.classify(m.text)
            val concept = m.concept?.let { b -> ByteBuffer.wrap(b).let { bb -> FloatArray(b.size / 4) { bb.float } } }
                ?: r?.concept ?: FloatArray(0)
            Report(m.id, m.senderId, m.text, Category.fromCode(m.category), Severity.fromCode(m.severity), m.peopleCount,
                m.latitude, m.longitude, m.receivedAt, concept, r?.vector ?: com.meshsos.core.ai.SparseVector(IntArray(0), FloatArray(0)))
        }
        val now = System.currentTimeMillis()
        val groups = grouper.group(reports)
        db.incidents().replace(
            groups.map { g -> IncidentEntity(g.id, g.category.code, g.combinedSeverity.code, g.reportCount, g.latitude,
                g.longitude, g.latestMillis, g.peopleCount, g.meanSimilarity, now) },
            groups.flatMap { g -> g.reports.map { IncidentReportEntity(g.id, it.id) } },
        )
    }
}
