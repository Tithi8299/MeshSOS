package com.meshsos.app

import android.Manifest
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.meshsos.app.service.MeshService
import com.meshsos.app.ui.navigation.MeshNavHost
import com.meshsos.app.ui.theme.LocalMesh
import com.meshsos.app.ui.theme.MeshSOSTheme
import java.util.Locale

val LocalContainer = staticCompositionLocalOf<AppContainer> { error("container not ready") }

/** Permission state shared with the screens (Home shows a banner when something is missing). */
class PermissionState(val granted: Boolean, val request: () -> Unit, val openSettings: () -> Unit, val bluetoothOn: Boolean)
val LocalPermissions = staticCompositionLocalOf { PermissionState(true, {}, {}, true) }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as MeshSOSApp
        setContent {
            MeshSOSTheme {
                val container by produceState<AppContainer?>(null) { value = app.container.await() }
                val c = container
                if (c == null) {
                    Box(Modifier.fillMaxSize().background(LocalMesh.current.app), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = LocalMesh.current.mesh)
                    }
                } else {
                    val settings by c.settings.settings.collectAsStateWithLifecycle()
                    var granted by remember { mutableStateOf(hasMeshPermissions(this)) }
                    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
                        granted = hasMeshPermissions(this)
                        if (granted) MeshService.start(this)
                    }
                    val perms = PermissionState(
                        granted = granted,
                        request = { launcher.launch(meshPermissions()) },
                        openSettings = {
                            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)))
                        },
                        bluetoothOn = bluetoothOn(),
                    )
                    if (settings.onboarded && granted) {
                        // Starting an already-running service is a no-op.
                        remember { MeshService.start(this); true }
                    }
                    Localized(settings.language) {
                        CompositionLocalProvider(LocalContainer provides c, LocalPermissions provides perms) {
                            MeshNavHost(startOnboarding = !settings.onboarded)
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Permissions may have been granted in system settings meanwhile.
        if (hasMeshPermissions(this)) {
            val app = application as MeshSOSApp
            if (app.container.getCompletedOrNull()?.settings?.settings?.value?.onboarded == true) MeshService.start(this)
        }
    }

    private fun bluetoothOn(): Boolean =
        (getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter?.isEnabled ?: false

    companion object {
        /** Runtime permissions Nearby Connections needs on each Android version. */
        fun meshPermissions(): Array<String> = buildList {
            add(Manifest.permission.ACCESS_FINE_LOCATION)
            add(Manifest.permission.ACCESS_COARSE_LOCATION)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                add(Manifest.permission.BLUETOOTH_SCAN); add(Manifest.permission.BLUETOOTH_ADVERTISE); add(Manifest.permission.BLUETOOTH_CONNECT)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.NEARBY_WIFI_DEVICES); add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }.toTypedArray()

        fun hasMeshPermissions(c: Context): Boolean = meshPermissions()
            .filter { it != Manifest.permission.POST_NOTIFICATIONS && it != Manifest.permission.ACCESS_COARSE_LOCATION }
            .all { ContextCompat.checkSelfPermission(c, it) == PackageManager.PERMISSION_GRANTED }
    }
}

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
private fun <T> kotlinx.coroutines.Deferred<T>.getCompletedOrNull(): T? = if (isCompleted) getCompleted() else null

/** In-app language switch (English / Bangla) without restarting the activity. */
@Composable
fun Localized(lang: String, content: @Composable () -> Unit) {
    val base = LocalContext.current
    val ctx = remember(lang, base) {
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(Locale.forLanguageTag(lang))
        base.createConfigurationContext(cfg)
    }
    CompositionLocalProvider(LocalContext provides ctx, LocalConfiguration provides ctx.resources.configuration) { content() }
}
