package com.meshsos.app.network.nearby

import android.content.Context
import android.os.SystemClock
import android.util.Log
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.BandwidthInfo
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

/**
 * Real peer-to-peer transport on Google Nearby Connections (FR1, FR2). No internet is used.
 *
 * Topology: Strategy.P2P_CLUSTER (M-to-N). Every phone advertises AND discovers at the same time,
 * and may hold several connections, which is what a mesh needs. Nearby itself only moves bytes
 * between DIRECTLY connected phones; all multi-hop relaying is done by MeshEngine/MeshRouter.
 *
 * Connection set-up: both phones usually discover each other, so only the phone with the lower
 * node ID requests the connection; the other one requests after a back-off if nothing happened.
 * Connections are accepted automatically: trust comes from the signed HELLO and the signature on
 * every packet, not from the Nearby link.
 *
 * Power saving (FR12): advertising stays on (otherwise nobody could find us), discovery runs
 * continuously in normal mode and for 5 s out of every 30 s in power-saving mode. Time spent
 * discovering is measured so the effect can be reported (NFR4).
 */
class NearbyTransport(context: Context, private val scope: CoroutineScope, private val listener: Listener) {

    interface Listener {
        fun onEndpointFound(endpointId: String, nodeIdPrefix: String?, name: String)
        fun onEndpointLost(endpointId: String)
        fun onConnecting(endpointId: String)
        fun onConnected(endpointId: String, name: String)
        fun onConnectionFailed(endpointId: String, statusCode: Int)
        fun onDisconnected(endpointId: String)
        fun onBytes(endpointId: String, bytes: ByteArray)
        fun onTransferResult(endpointId: String, payloadId: Long, success: Boolean)
        fun onBandwidth(endpointId: String, quality: Int)
        fun onTransportError(what: String, statusCode: Int)
    }

    companion object {
        const val SERVICE_ID = "com.meshsos.app.mesh.v1"
        val STRATEGY: Strategy = Strategy.P2P_CLUSTER
        const val MAX_CONNECTIONS = 6
        const val SCAN_WINDOW_MS = 5_000L
        const val SAVING_PERIOD_MS = 30_000L
        private const val TAG = "MeshNearby"

        fun endpointName(nodeId: String, displayName: String) = "MS1|${nodeId.take(16)}|${displayName.take(20)}"
        fun parse(name: String): Pair<String?, String> {
            val parts = name.split('|', limit = 3)
            return if (parts.size == 3 && parts[0] == "MS1") parts[1] to parts[2] else null to name
        }
    }

    private val client = Nearby.getConnectionsClient(context)
    private val connected = ConcurrentHashMap.newKeySet<String>()
    private val pending = ConcurrentHashMap.newKeySet<String>()
    private val outgoing = ConcurrentHashMap<Long, String>()     // payloadId -> endpointId
    private var myNodeId = ""
    private var myName = ""
    private var scanJob: Job? = null
    @Volatile var powerSaving = false
        private set
    @Volatile var discovering = false
        private set
    @Volatile var advertising = false
        private set

    // discovery duty-cycle measurement
    private var discoveryStartedAt = 0L
    private var discoveryOnTotal = 0L
    private val measureSince = SystemClock.elapsedRealtime()
    fun discoveryOnMillis(): Long = discoveryOnTotal + if (discovering) SystemClock.elapsedRealtime() - discoveryStartedAt else 0
    fun measuredForMillis(): Long = SystemClock.elapsedRealtime() - measureSince

    fun connectedEndpoints(): Set<String> = connected.toSet()

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type == Payload.Type.BYTES) payload.asBytes()?.let { listener.onBytes(endpointId, it) }
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {
            val ep = outgoing[update.payloadId] ?: return     // only track what we sent
            when (update.status) {
                PayloadTransferUpdate.Status.SUCCESS -> { outgoing.remove(update.payloadId); listener.onTransferResult(ep, update.payloadId, true) }
                PayloadTransferUpdate.Status.FAILURE, PayloadTransferUpdate.Status.CANCELED -> {
                    outgoing.remove(update.payloadId); listener.onTransferResult(ep, update.payloadId, false)
                }
                else -> {}
            }
        }
    }

    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            if (connected.size >= MAX_CONNECTIONS) { client.rejectConnection(endpointId); return }
            pending += endpointId
            listener.onConnecting(endpointId)
            client.acceptConnection(endpointId, payloadCallback)
                .addOnFailureListener { e -> Log.w(TAG, "accept failed: ${code(e)}") }
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            pending -= endpointId
            if (result.status.statusCode == ConnectionsStatusCodes.STATUS_OK) {
                connected += endpointId
                listener.onConnected(endpointId, "")
            } else {
                listener.onConnectionFailed(endpointId, result.status.statusCode)
            }
        }

        override fun onDisconnected(endpointId: String) {
            connected -= endpointId; pending -= endpointId
            listener.onDisconnected(endpointId)
        }

        override fun onBandwidthChanged(endpointId: String, bandwidthInfo: BandwidthInfo) {
            listener.onBandwidth(endpointId, bandwidthInfo.quality)
        }
    }

    private val discovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            if (info.serviceId != SERVICE_ID) return
            val (prefix, name) = parse(info.endpointName)
            listener.onEndpointFound(endpointId, prefix, name)
            if (endpointId in connected || endpointId in pending || connected.size >= MAX_CONNECTIONS) return
            // Tie-break so both phones do not request at once; the higher ID retries after a back-off.
            val iRequest = prefix == null || myNodeId.take(16) < prefix
            scope.launch {
                if (!iRequest) delay(7_000)
                if (endpointId !in connected && endpointId !in pending) requestConnection(endpointId)
            }
        }

        override fun onEndpointLost(endpointId: String) = listener.onEndpointLost(endpointId)
    }

    fun start(nodeId: String, displayName: String, powerSaving: Boolean) {
        myNodeId = nodeId; myName = displayName; this.powerSaving = powerSaving
        startAdvertising()
        restartScanLoop()
    }

    fun stop() {
        scanJob?.cancel(); scanJob = null
        stopDiscovery()
        client.stopAdvertising(); advertising = false
        client.stopAllEndpoints()
        connected.clear(); pending.clear(); outgoing.clear()
    }

    fun setPowerSaving(on: Boolean) {
        if (on == powerSaving) return
        powerSaving = on
        restartScanLoop()
    }

    /** Called from the UI ("Connect") or automatically after discovery. */
    fun requestConnection(endpointId: String) {
        if (endpointId in connected || !pending.add(endpointId)) return
        listener.onConnecting(endpointId)
        client.requestConnection(endpointName(myNodeId, myName), endpointId, lifecycle)
            .addOnFailureListener { e ->
                pending -= endpointId
                val c = code(e)
                if (c != ConnectionsStatusCodes.STATUS_ALREADY_CONNECTED_TO_ENDPOINT) listener.onConnectionFailed(endpointId, c)
            }
    }

    /** Sends one packet to one directly connected phone. Returns the payload id, or null if not connected. */
    fun send(endpointId: String, bytes: ByteArray): Long? {
        if (endpointId !in connected) return null
        val payload = Payload.fromBytes(bytes)
        outgoing[payload.id] = endpointId
        client.sendPayload(endpointId, payload).addOnFailureListener {
            if (outgoing.remove(payload.id) != null) listener.onTransferResult(endpointId, payload.id, false)
        }
        return payload.id
    }

    fun disconnect(endpointId: String) {
        client.disconnectFromEndpoint(endpointId); connected -= endpointId
    }

    private fun startAdvertising() {
        val opts = AdvertisingOptions.Builder().setStrategy(STRATEGY).build()
        client.startAdvertising(endpointName(myNodeId, myName), SERVICE_ID, lifecycle, opts)
            .addOnSuccessListener { advertising = true }
            .addOnFailureListener { e ->
                val c = code(e)
                if (c == ConnectionsStatusCodes.STATUS_ALREADY_ADVERTISING) advertising = true
                else listener.onTransportError("advertising", c)
            }
    }

    private fun startDiscovery() {
        val opts = DiscoveryOptions.Builder().setStrategy(STRATEGY).build()
        client.startDiscovery(SERVICE_ID, discovery, opts)
            .addOnSuccessListener { if (!discovering) { discovering = true; discoveryStartedAt = SystemClock.elapsedRealtime() } }
            .addOnFailureListener { e ->
                val c = code(e)
                if (c == ConnectionsStatusCodes.STATUS_ALREADY_DISCOVERING) {
                    if (!discovering) { discovering = true; discoveryStartedAt = SystemClock.elapsedRealtime() }
                } else listener.onTransportError("discovery", c)
            }
    }

    private fun stopDiscovery() {
        client.stopDiscovery()
        if (discovering) { discoveryOnTotal += SystemClock.elapsedRealtime() - discoveryStartedAt; discovering = false }
    }

    private fun restartScanLoop() {
        scanJob?.cancel()
        scanJob = scope.launch {
            while (isActive) {
                startDiscovery()
                if (powerSaving) {
                    delay(SCAN_WINDOW_MS)
                    stopDiscovery()
                    delay(SAVING_PERIOD_MS - SCAN_WINDOW_MS)
                } else {
                    // Continuous discovery; restarted every 5 minutes because long discovery
                    // sessions sometimes stop reporting new endpoints on some phones.
                    delay(5 * 60_000L)
                    stopDiscovery()
                    delay(250)
                }
            }
        }
    }

    private fun code(e: Exception) = (e as? ApiException)?.statusCode ?: -1
}
