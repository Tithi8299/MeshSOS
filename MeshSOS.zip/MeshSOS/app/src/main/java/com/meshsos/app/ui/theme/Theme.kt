package com.meshsos.app.ui.theme

import android.graphics.Typeface
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Colour tokens copied from the HTML prototype's CSS variables (light and dark). */
@Immutable
data class MeshColors(
    val panel: Color, val ink: Color, val mute: Color, val line: Color, val app: Color, val card: Color,
    val sos: Color, val sosInk: Color, val critSoft: Color, val mesh: Color, val meshSoft: Color,
    val amber: Color, val amberSoft: Color, val ok: Color, val okSoft: Color,
)

val LightMesh = MeshColors(
    panel = Color(0xFFF6F9FA), ink = Color(0xFF11212A), mute = Color(0xFF566870), line = Color(0xFFD0DADE),
    app = Color(0xFFF2F6F7), card = Color(0xFFFFFFFF), sos = Color(0xFFD4243B), sosInk = Color(0xFFFFFFFF),
    critSoft = Color(0xFFFADADF), mesh = Color(0xFF0B7A87), meshSoft = Color(0xFFD5EDEF), amber = Color(0xFF9A5A00),
    amberSoft = Color(0xFFFBE8C8), ok = Color(0xFF17794A), okSoft = Color(0xFFD7EFE2),
)

val DarkMesh = MeshColors(
    panel = Color(0xFF101C22), ink = Color(0xFFE5EDF0), mute = Color(0xFF92A5AD), line = Color(0xFF243740),
    app = Color(0xFF0F1B21), card = Color(0xFF17262D), sos = Color(0xFFF0485D), sosInk = Color(0xFF1A0508),
    critSoft = Color(0xFF451A22), mesh = Color(0xFF3CC4D1), meshSoft = Color(0xFF0F3A40), amber = Color(0xFFF2AE48),
    amberSoft = Color(0xFF3A2A0E), ok = Color(0xFF4CCB8A), okSoft = Color(0xFF10331F),
)

/**
 * The prototype uses Barlow Condensed / Barlow / IBM Plex Mono. The app must work offline from the
 * first launch, so it uses the system's condensed sans (closest match) instead of downloadable
 * fonts. To match the prototype exactly, add the TTFs under res/font and swap these families.
 * Bangla renders with the system Noto Sans Bengali font.
 */
object MeshFonts {
    val display = FontFamily(Typeface.create("sans-serif-condensed", Typeface.BOLD))
    val body = FontFamily.SansSerif
    val mono = FontFamily.Monospace
}

object MeshType {
    val screenTitle = TextStyle(fontFamily = MeshFonts.display, fontWeight = FontWeight.Bold, fontSize = 26.sp, lineHeight = 28.sp)
    val hero = TextStyle(fontFamily = MeshFonts.display, fontWeight = FontWeight.Bold, fontSize = 38.sp, lineHeight = 39.sp)
    val label = TextStyle(fontFamily = MeshFonts.display, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, letterSpacing = 1.4.sp)
    val body = TextStyle(fontFamily = MeshFonts.body, fontSize = 14.sp, lineHeight = 20.sp)
    val bodyStrong = body.copy(fontWeight = FontWeight.SemiBold)
    val small = TextStyle(fontFamily = MeshFonts.body, fontSize = 12.sp, lineHeight = 16.sp)
    val mono = TextStyle(fontFamily = MeshFonts.mono, fontSize = 12.sp)
    val big = TextStyle(fontFamily = MeshFonts.display, fontWeight = FontWeight.Bold, fontSize = 34.sp, lineHeight = 34.sp)
}

val LocalMesh = staticCompositionLocalOf { LightMesh }

@Composable
fun MeshSOSTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val c = if (dark) DarkMesh else LightMesh
    val scheme = if (dark) darkColorScheme(primary = c.mesh, error = c.sos, background = c.app, surface = c.card,
        onSurface = c.ink, onBackground = c.ink, outline = c.line)
    else lightColorScheme(primary = c.mesh, error = c.sos, background = c.app, surface = c.card,
        onSurface = c.ink, onBackground = c.ink, outline = c.line)
    CompositionLocalProvider(LocalMesh provides c) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
