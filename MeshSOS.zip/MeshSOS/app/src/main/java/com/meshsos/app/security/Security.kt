package com.meshsos.app.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.google.crypto.tink.subtle.Ed25519Sign
import com.google.crypto.tink.subtle.Ed25519Verify
import com.google.crypto.tink.subtle.X25519
import com.meshsos.app.data.database.KeyMetadataDao
import com.meshsos.app.data.database.KeyMetadataEntity
import com.meshsos.core.crypto.CurveProvider
import com.meshsos.core.crypto.Hex
import com.meshsos.core.crypto.Identity
import com.meshsos.core.crypto.KeyPairBytes
import java.security.GeneralSecurityException
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Ed25519 and X25519 through Google Tink's raw-key primitives. Android's own JCA only gained
 * these curves in API 33, and the app must run on API 26.
 */
object TinkCurveProvider : CurveProvider {
    override fun newSigningKeyPair(): KeyPairBytes {
        val kp = Ed25519Sign.KeyPair.newKeyPair()
        return KeyPairBytes(kp.publicKey, kp.privateKey)
    }

    override fun sign(privateKey: ByteArray, message: ByteArray): ByteArray = Ed25519Sign(privateKey).sign(message)

    override fun verify(publicKey: ByteArray, message: ByteArray, signature: ByteArray): Boolean = try {
        Ed25519Verify(publicKey).verify(signature, message); true
    } catch (e: GeneralSecurityException) {
        false
    }

    override fun newAgreementKeyPair(): KeyPairBytes {
        val priv = X25519.generatePrivateKey()
        return KeyPairBytes(X25519.publicFromPrivate(priv), priv)
    }

    override fun agree(privateKey: ByteArray, peerPublicKey: ByteArray): ByteArray =
        X25519.computeSharedSecret(privateKey, peerPublicKey)
}

/**
 * Stores this phone's private keys encrypted with an AES-256-GCM key that never leaves the
 * Android Keystore. Private keys are never logged and never leave the phone.
 */
class KeyVault(context: Context) {
    private val prefs = context.getSharedPreferences("meshsos_keys", Context.MODE_PRIVATE)
    private val alias = "meshsos_identity_wrap_v1"

    private fun wrappingKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getEntry(alias, null) as? KeyStore.SecretKeyEntry)?.let { return it.secretKey }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun put(name: String, secret: ByteArray) {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, wrappingKey())       // Keystore picks a random IV
        val blob = c.iv + c.doFinal(secret)
        prefs.edit().putString(name, Base64.encodeToString(blob, Base64.NO_WRAP)).apply()
    }

    fun get(name: String): ByteArray? {
        val s = prefs.getString(name, null) ?: return null
        val blob = Base64.decode(s, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, wrappingKey(), GCMParameterSpec(128, blob, 0, 12))
        return c.doFinal(blob, 12, blob.size - 12)
    }

    fun putPlain(name: String, value: ByteArray) =
        prefs.edit().putString(name, Base64.encodeToString(value, Base64.NO_WRAP)).apply()

    fun getPlain(name: String): ByteArray? = prefs.getString(name, null)?.let { Base64.decode(it, Base64.NO_WRAP) }
}

/** Creates the identity on first launch and loads it afterwards. */
class IdentityStore(private val vault: KeyVault, private val keyMeta: KeyMetadataDao) {
    suspend fun loadOrCreate(displayName: String): Identity {
        val sPub = vault.getPlain("sign_pub"); val sPriv = vault.get("sign_priv")
        val aPub = vault.getPlain("agree_pub"); val aPriv = vault.get("agree_priv")
        if (sPub != null && sPriv != null && aPub != null && aPriv != null) {
            return Identity(KeyPairBytes(sPub, sPriv), KeyPairBytes(aPub, aPriv), displayName)
        }
        val id = Identity.generate(TinkCurveProvider, displayName)
        vault.putPlain("sign_pub", id.signing.publicKey); vault.put("sign_priv", id.signing.privateKey)
        vault.putPlain("agree_pub", id.agreement.publicKey); vault.put("agree_priv", id.agreement.privateKey)
        val now = System.currentTimeMillis()
        keyMeta.upsert(KeyMetadataEntity("identity_signing", "Ed25519", Hex.encode(id.signing.publicKey), now))
        keyMeta.upsert(KeyMetadataEntity("identity_agreement", "X25519", Hex.encode(id.agreement.publicKey), now))
        return id
    }
}
