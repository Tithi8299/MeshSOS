package com.meshsos.app.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration

@Database(
    entities = [MessageEntity::class, SeenIdEntity::class, PeerEntity::class, IncidentEntity::class,
        IncidentReportEntity::class, ReceiptEntity::class, KeyMetadataEntity::class, PendingForwardEntity::class,
        BatterySampleEntity::class],
    version = 1,
    exportSchema = true,
)
abstract class MeshDatabase : RoomDatabase() {
    abstract fun messages(): MessageDao
    abstract fun seenIds(): SeenIdDao
    abstract fun peers(): PeerDao
    abstract fun incidents(): IncidentDao
    abstract fun receipts(): ReceiptDao
    abstract fun keys(): KeyMetadataDao
    abstract fun pending(): PendingForwardDao
    abstract fun battery(): BatteryDao

    companion object {
        /**
         * Schema history. Version 1 is the first release. When an entity changes: bump `version`,
         * add a Migration(n, n + 1) here, and commit the new JSON from app/schemas/. Never use
         * fallbackToDestructiveMigration: stored SOS messages must survive app updates.
         */
        val MIGRATIONS: Array<Migration> = emptyArray()

        fun build(context: Context): MeshDatabase =
            Room.databaseBuilder(context, MeshDatabase::class.java, "meshsos.db")
                .addMigrations(*MIGRATIONS)
                .build()
    }
}
