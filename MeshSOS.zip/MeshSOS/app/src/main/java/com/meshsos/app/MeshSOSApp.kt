package com.meshsos.app

import android.app.Application
import android.content.Context
import android.util.Log
import com.meshsos.app.data.database.MeshDatabase
import com.meshsos.app.data.repository.IncidentRepository
import com.meshsos.app.data.repository.SettingsRepository
import com.meshsos.app.location.LocationProvider
import com.meshsos.app.network.MeshEngine
import com.meshsos.app.security.IdentityStore
import com.meshsos.app.security.KeyVault
import com.meshsos.app.service.Notifier
import com.meshsos.core.ai.ClassifierModel
import com.meshsos.core.ai.EmergencyClassifier
import com.meshsos.core.ai.GroupingConfig
import com.meshsos.core.ai.IncidentGrouper
import com.meshsos.core.ai.LearnedPriorityScorer
import com.meshsos.core.ai.RulePriorityScorer
import com.meshsos.core.crypto.Identity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async

/** Manual dependency injection: one place that builds every long-lived object. */
class AppContainer(
    val db: MeshDatabase,
    val settings: SettingsRepository,
    val identity: Identity,
    val classifier: Deferred<EmergencyClassifier?>,
    val incidents: IncidentRepository,
    val engine: MeshEngine,
    val location: LocationProvider,
)

class MeshSOSApp : Application() {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    lateinit var container: Deferred<AppContainer>
        private set

    override fun onCreate() {
        super.onCreate()
        Notifier.init(this)
        Notifier.ensureChannels(this)
        val ctx: Context = this
        // The model loads in parallel; until it is ready (or if it fails) SOS still works, unclassified.
        val classifier = appScope.async(Dispatchers.IO) {
            try {
                EmergencyClassifier(ctx.assets.open("models/meshsos_classifier.bin").use { ClassifierModel.load(it) })
            } catch (e: Exception) {
                Log.e("MeshSOS", "classifier failed to load: $e"); null
            }
        }
        container = appScope.async(Dispatchers.IO) {
            val db = MeshDatabase.build(ctx)
            val settings = SettingsRepository(ctx)
            val identity = IdentityStore(KeyVault(ctx), db.keys()).loadOrCreate(settings.settings.value.displayName)
            val grouping = runCatching {
                GroupingConfig.fromJson(ctx.assets.open("models/grouping_config.json").bufferedReader().readText())
            }.getOrDefault(GroupingConfig())
            val learned = runCatching {
                LearnedPriorityScorer.fromJson(ctx.assets.open("models/priority_model.json").bufferedReader().readText())
            }.getOrNull()
            val incidents = IncidentRepository(db, classifier, IncidentGrouper(grouping))
            val engine = MeshEngine(ctx, db, identity, incidents, Notifier, RulePriorityScorer(), learned)
            AppContainer(db, settings, identity, classifier, incidents, engine, LocationProvider(ctx))
        }
    }
}
