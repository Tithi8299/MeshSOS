package com.meshsos.app.ui.screens

import androidx.compose.foundation.ExperimentalLayoutApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavHostController
import com.meshsos.app.AppContainer
import com.meshsos.app.LocalContainer
import com.meshsos.app.R
import com.meshsos.app.location.FixResult
import com.meshsos.app.network.SosDraft
import com.meshsos.app.ui.components.ChipToggle
import com.meshsos.app.ui.components.Lbl
import com.meshsos.app.ui.components.MeshButton
import com.meshsos.app.ui.components.MeshCard
import com.meshsos.app.ui.components.MeshIcons
import com.meshsos.app.ui.components.Meter
import com.meshsos.app.ui.components.Pill
import com.meshsos.app.ui.components.PillKind
import com.meshsos.app.ui.components.Seg
import com.meshsos.app.ui.components.SevPill
import com.meshsos.app.ui.components.SmallIcon
import com.meshsos.app.ui.components.Stepper
import com.meshsos.app.ui.components.TopBar
import com.meshsos.app.ui.components.categoryName
import com.meshsos.app.ui.components.severityName
import com.meshsos.app.ui.navigation.Frame
import com.meshsos.app.ui.theme.LocalMesh
import com.meshsos.app.ui.theme.MeshType
import com.meshsos.core.ai.ClassificationResult
import com.meshsos.core.model.Category
import com.meshsos.core.model.DeliveryStatus
import com.meshsos.core.model.Severity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

// ------------------------------------------------------------------------- 3. New SOS with AI triage
class ComposeViewModel(private val c: AppContainer) : ViewModel() {
    var text by mutableStateOf("")
        private set
    var ai by mutableStateOf<ClassificationResult?>(null)
        private set
    var category by mutableStateOf(Category.UNCLASSIFIED)
        private set
    var severity by mutableStateOf(Severity.HIGH)   // a bare SOS with no text is treated as High until edited
        private set
    var people by mutableStateOf(1)
        private set
    var edited by mutableStateOf(false)
        private set
    var fix by mutableStateOf<FixResult?>(null)      // null while waiting for GPS
        private set
    var sending by mutableStateOf(false)
        private set
    var rateLimited by mutableStateOf(false)
        private set
    private var job: Job? = null

    init { viewModelScope.launch { fix = c.location.currentFix() } }

    fun onText(t: String) {
        text = t.take(1000)
        job?.cancel()
        job = viewModelScope.launch {
            delay(200)
            val cl = c.classifier.await() ?: return@launch
            val r = withContext(Dispatchers.Default) { cl.classify(text) }
            ai = r
            if (!edited) { category = r.category; severity = if (text.isBlank()) Severity.HIGH else r.severity; if (r.peopleCount > 0) people = r.peopleCount }
        }
    }

    fun pickType(cat: Category) { category = cat; severity = DEFAULT_SEVERITY.getValue(cat); edited = true }
    fun pickSeverity(s: Severity) { severity = s; edited = true }
    fun changePeople(d: Int) { people = (people + d).coerceIn(1, 99); edited = true }
    fun useAi() { edited = false; ai?.let { category = it.category; severity = it.severity; if (it.peopleCount > 0) people = it.peopleCount } }

    /** Returns the new message id, or null if the rate limit blocks it. */
    suspend fun send(defaultText: String): String? {
        if (sending) return null
        sending = true
        try {
            if (c.engine.ownSosInLastTenMinutes() >= 6) { rateLimited = true; return null }
            val f = (fix as? FixResult.Ok)?.fix
            return c.engine.sendSos(SosDraft(text.trim().ifEmpty { defaultText }, category, severity, people,
                ai?.confidence ?: 0f, edited, f?.latitude, f?.longitude, f?.accuracyMeters))
        } finally { sending = false }
    }

    companion object {
        val DEFAULT_SEVERITY = mapOf(Category.MEDICAL to Severity.CRITICAL, Category.TRAPPED to Severity.HIGH,
            Category.FIRE to Severity.CRITICAL, Category.FLOOD to Severity.HIGH, Category.FOOD to Severity.NORMAL,
            Category.MISSING to Severity.HIGH, Category.OTHER to Severity.NORMAL, Category.UNCLASSIFIED to Severity.NORMAL)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ComposeSosScreen(nav: NavHostController, onBack: () -> Unit, onSent: (String) -> Unit) {
    val c = LocalMesh.current
    val container = LocalContainer.current
    val vm: ComposeViewModel = viewModel(factory = viewModelFactory { initializer { ComposeViewModel(container) } })
    val scope = rememberCoroutineScope()
    val defaultText = stringResource(R.string.default_sos_text)
    Frame(nav, tabs = false, foot = {
        MeshButton(stringResource(R.string.send_sos), kind = "sos", icon = MeshIcons.Send, enabled = !vm.sending, onClick = {
            scope.launch { vm.send(defaultText)?.let(onSent) }
        })
    }) {
        ScreenColumn {
            TopBar(stringResource(R.string.new_sos), onBack)
            MeshCard {
                Row { Lbl(stringResource(R.string.what_happening)); Text(" " + stringResource(R.string.lang_hint), style = MeshType.small, color = c.mute) }
                val cd = stringResource(R.string.what_happening)
                BasicTextField(vm.text, vm::onText, Modifier.fillMaxWidth().heightIn(min = 92.dp).semantics { contentDescription = cd },
                    textStyle = MeshType.body.copy(fontSize = 15.sp, color = c.ink), cursorBrush = SolidColor(c.mesh),
                    decorationBox = { inner ->
                        Box { if (vm.text.isEmpty()) Text(stringResource(R.string.msg_placeholder), style = MeshType.body.copy(fontSize = 15.sp), color = c.mute); inner() }
                    })
            }
            MeshCard {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SmallIcon(MeshIcons.Sparkle, c.mesh)
                        Text(stringResource(R.string.ai_suggested), style = MeshType.bodyStrong, color = c.ink, modifier = Modifier.weight(1f))
                        Pill(stringResource(R.string.works_offline), PillKind.NORM)
                    }
                    Column {
                        Lbl(stringResource(R.string.type))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            for (cat in Category.entries.filter { it != Category.UNCLASSIFIED })
                                ChipToggle(categoryName(cat), vm.category == cat, { vm.pickType(cat) })
                        }
                    }
                    Column {
                        Lbl(stringResource(R.string.severity))
                        Seg(Severity.entries.map { it to severityName(it) }, vm.severity, vm::pickSeverity, activeColor = { s ->
                            when (s) { Severity.CRITICAL -> c.sos; Severity.HIGH -> c.amber; Severity.NORMAL -> c.mesh }
                        })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Lbl(stringResource(R.string.people), Modifier.weight(1f))
                        Stepper(vm.people, { vm.changePeople(-1) }, { vm.changePeople(1) },
                            stringResource(R.string.fewer_people), stringResource(R.string.more_people))
                    }
                    val r = vm.ai
                    val pct = ((r?.confidence ?: 0f) * 100).toInt()
                    val uncl = vm.category == Category.UNCLASSIFIED
                    Column {
                        Row {
                            Text(when {
                                vm.edited -> stringResource(R.string.set_by_you)
                                r == null -> "–"
                                uncl -> stringResource(R.string.conf_low, pct)
                                else -> stringResource(R.string.conf_pct, pct)
                            }, style = MeshType.small, color = c.mute, modifier = Modifier.weight(1f))
                            if (vm.edited && r != null) Text(stringResource(R.string.use_ai_again), style = MeshType.small, color = c.mesh,
                                modifier = Modifier.padding(start = 8.dp).clickable(onClick = vm::useAi))
                            else Text(stringResource(if (vm.edited) R.string.edited else R.string.ai_suggestion), style = MeshType.small, color = c.mute)
                        }
                        Spacer(Modifier.height(4.dp))
                        Meter(if (vm.edited) 1f else pct / 100f)
                    }
                    if (uncl && !vm.edited && vm.text.isNotBlank())
                        Text(stringResource(R.string.uncl_note), style = MeshType.small, color = c.mute)
                    if (vm.rateLimited) Text(stringResource(R.string.rate_limited), style = MeshType.small, color = c.sos)
                }
            }
            MeshCard {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallIcon(MeshIcons.Pin, c.mesh)
                    Column(Modifier.weight(1f)) {
                        when (val f = vm.fix) {
                            null -> Text(stringResource(R.string.gps_getting), style = MeshType.bodyStrong, color = c.ink)
                            is FixResult.Ok -> {
                                Text(stringResource(R.string.gps_attached), style = MeshType.bodyStrong, color = c.ink)
                                Text(formatCoord(f.fix.latitude, f.fix.longitude) + (f.fix.accuracyMeters?.let { " · ±${it.toInt()} m" } ?: ""),
                                    style = MeshType.mono, color = c.mute)
                                Text(stringResource(R.string.gps_signed), style = MeshType.small, color = c.mute)
                            }
                            FixResult.NoPermission -> Text(stringResource(R.string.gps_perm_off), style = MeshType.body, color = c.amber)
                            FixResult.Unavailable -> Text(stringResource(R.string.gps_none), style = MeshType.body, color = c.amber)
                        }
                    }
                }
            }
        }
    }
}

fun formatCoord(lat: Double, lon: Double): String =
    String.format(Locale.US, "%.4f° %s, %.4f° %s", kotlin.math.abs(lat), if (lat >= 0) "N" else "S", kotlin.math.abs(lon), if (lon >= 0) "E" else "W")

// ------------------------------------------------------------------------- 4. Delivery status
@Composable
fun DeliveryScreen(nav: NavHostController, messageId: String, onHome: () -> Unit, onAlerts: () -> Unit) {
    val c = LocalMesh.current
    val container = LocalContainer.current
    val msg by container.db.messages().observe(messageId).collectAsStateWithLifecycle(null)
    val prio by produceState<Triple<Double, Int, Int>?>(null, messageId) {
        while (true) { value = container.engine.priorityOf(messageId); delay(2_000) }
    }
    Frame(nav, tabs = false, foot = { MeshButton(stringResource(R.string.view_alerts), onAlerts, kind = "ghost") }) {
        ScreenColumn {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                com.meshsos.app.ui.components.IconCircle(MeshIcons.Home, stringResource(R.string.tab_home), onHome)
                Text(stringResource(R.string.sos_sent), style = MeshType.screenTitle, color = c.ink)
            }
            val m = msg ?: return@ScreenColumn
            val sev = Severity.fromCode(m.severity); val cat = Category.fromCode(m.category)
            MeshCard {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SevPill(sev, unclassified = cat == Category.UNCLASSIFIED)
                    if (cat != Category.UNCLASSIFIED) Pill(categoryName(cat), PillKind.NORM)
                    Spacer(Modifier.weight(1f))
                    Text(pluralStringResource(R.plurals.people_n, m.peopleCount, m.peopleCount), style = MeshType.small, color = c.mute)
                }
                Spacer(Modifier.height(6.dp))
                Text(m.text, style = MeshType.body, color = c.ink)
            }
            val status = DeliveryStatus.fromCode(m.status)
            MeshCard {
                Lbl(stringResource(R.string.delivery))
                Step(true, stringResource(R.string.st_queued), stringResource(R.string.st_queued_sub))
                Step(status >= DeliveryStatus.SENT, stringResource(R.string.st_sent),
                    if (status >= DeliveryStatus.SENT) stringResource(R.string.st_sent_sub, m.handedToCount) else stringResource(R.string.st_sent_wait))
                Step(status >= DeliveryStatus.RELAYED, stringResource(R.string.st_relayed), when {
                    m.relayedByName != null -> stringResource(R.string.st_relayed_sub, m.relayedByName, m.relayedAtHop)
                    status == DeliveryStatus.DELIVERED -> stringResource(R.string.path_direct)
                    else -> stringResource(R.string.st_waiting_receipt)
                })
                Step(status == DeliveryStatus.DELIVERED, stringResource(R.string.st_delivered), last = true, sub =
                    if (m.deliveredAt != null) stringResource(R.string.st_delivered_sub, m.deliveredByName ?: "", m.deliveredHops,
                        String.format(Locale.US, "%.1f", (m.deliveredAt - m.createdAt) / 1000.0))
                    else stringResource(R.string.st_waiting_receipt))
            }
            MeshCard {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallIcon(MeshIcons.Sparkle, c.mesh)
                    Column {
                        val p = prio
                        if (p != null) {
                            Text(stringResource(R.string.priority_score, String.format(Locale.US, "%.2f", p.first)), style = MeshType.bodyStrong, color = c.ink)
                            Text(stringResource(R.string.priority_sub, p.second, p.third), style = MeshType.small, color = c.mute)
                        } else Text(stringResource(R.string.priority_done), style = MeshType.small, color = c.mute)
                    }
                }
            }
        }
    }
}

@Composable
private fun Step(done: Boolean, title: String, sub: String, last: Boolean = false) {
    val c = LocalMesh.current
    Row(Modifier.fillMaxWidth().padding(bottom = if (last) 0.dp else 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(28.dp).clip(CircleShape).background(if (done) c.ok else c.card).border(2.dp, if (done) c.ok else c.line, CircleShape),
            contentAlignment = Alignment.Center) {
            if (done) Icon(MeshIcons.Check, null, tint = c.card, modifier = Modifier.size(15.dp))
        }
        Column {
            Text(title, style = MeshType.bodyStrong, color = if (done) c.ink else c.mute)
            Text(sub, style = MeshType.small, color = c.mute)
        }
    }
}
