package com.meshsos.app.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.unit.dp

/** The prototype's stroke icons (24 x 24, 1.8 stroke, round caps), path data copied from its SVG symbols. */
object MeshIcons {
    private fun circle(cx: Float, cy: Float, r: Float) = "M${cx - r},${cy}a$r,$r 0 1,0 ${2 * r},0a$r,$r 0 1,0 ${-2 * r},0"

    private fun icon(name: String, vararg paths: String): ImageVector =
        ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f).apply {
            for (d in paths) addPath(pathData = addPathNodes(d), fill = null, stroke = SolidColor(Color.Black),
                strokeLineWidth = 1.8f, strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round)
        }.build()

    val Home = icon("home", "M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z")
    val Near = icon("near", circle(12f, 12f, 1.8f), "M7.8 7.8a6 6 0 0 0 0 8.4M16.2 7.8a6 6 0 0 1 0 8.4M4.6 4.6a10.5 10.5 0 0 0 0 14.8M19.4 4.6a10.5 10.5 0 0 1 0 14.8")
    val Inbox = icon("inbox", "M3 13l3-8h12l3 8v6H3zM3 13h5l1 2h6l1-2h5")
    val Alert = icon("alert", "M12 3l10 18H2zM12 10v5M12 18v.01")
    val Settings = icon("settings", "M4 7h8M18 7h2M4 17h2M12 17h8", circle(15f, 7f, 2.2f), circle(9f, 17f, 2.2f))
    val Back = icon("back", "M15 5l-7 7 7 7")
    val Send = icon("send", "M3 11l18-8-8 18-2-8z")
    val Lock = icon("lock", "M7 11h10a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2z", "M8 11V8a4 4 0 0 1 8 0v3")
    val Check = icon("check", "M5 12.5l4.5 4.5L19 7")
    val Pin = icon("pin", "M12 21s7-6.2 7-11a7 7 0 0 0-14 0c0 4.8 7 11 7 11z", circle(12f, 10f, 2.5f))
    val Shield = icon("shield", "M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z", "M9 12l2 2 4-4")
    val Bolt = icon("bolt", "M13 2L5 13h6l-1 9 8-11h-6z")
    val Users = icon("users", circle(9f, 8f, 3f), "M3 20a6 6 0 0 1 12 0", circle(17f, 9f, 2.5f), "M16.5 14.2A5 5 0 0 1 22 19")
    val Chevron = icon("chev", "M9 5l7 7-7 7")
    val Sparkle = icon("sparkle", "M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M18 6l-2.5 2.5M8.5 15.5L6 18")
    val Flag = icon("flag", "M5 21V4M5 4h11l-2 4 2 4H5")
    val Mark = ImageVector.Builder("mark", 26.dp, 26.dp, 32f, 32f).apply {
        for (d in listOf(circle(6f, 16f, 3f), circle(25f, 7f, 3f), circle(25f, 25f, 3f), "M9 15l13-6.5M9 17l13 6.5"))
            addPath(pathData = addPathNodes(d), stroke = SolidColor(Color.Black), strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round)
    }.build()
}
