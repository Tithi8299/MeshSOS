package com.meshsos.app.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(m: MessageEntity): Long

    @Query("SELECT * FROM messages WHERE id = :id")
    fun observe(id: String): Flow<MessageEntity?>

    @Query("SELECT * FROM messages WHERE id = :id")
    suspend fun get(id: String): MessageEntity?

    /** Received SOS alerts, newest first. type 2 = SOS. */
    @Query("SELECT * FROM messages WHERE type = 2 AND direction = 1 ORDER BY receivedAt DESC")
    fun observeReceivedSos(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE type = 2 AND direction = 1 AND receivedAt >= :since")
    suspend fun receivedSosSince(since: Long): List<MessageEntity>

    /** A chat thread: private messages (type 4) with one peer, or broadcasts (type 3) when peerId = "all". */
    @Query("SELECT * FROM messages WHERE type IN (3, 4) AND peerId = :peerId ORDER BY createdAt ASC")
    fun observeChat(peerId: String): Flow<List<MessageEntity>>

    /** Latest message per conversation. */
    @Query("""SELECT * FROM messages WHERE type IN (3, 4) AND createdAt = (SELECT MAX(m2.createdAt) FROM messages m2
              WHERE m2.type IN (3, 4) AND m2.peerId = messages.peerId) ORDER BY createdAt DESC""")
    fun observeChatHeads(): Flow<List<MessageEntity>>

    @Query("SELECT COUNT(*) FROM messages WHERE type = 2 AND direction = 0 AND senderId = :me AND createdAt >= :since")
    suspend fun ownSosSince(me: String, since: Long): Int

    @Query("SELECT COUNT(*) FROM messages")
    fun observeCount(): Flow<Int>

    @Query("SELECT COALESCE(SUM(LENGTH(text)), 0) FROM messages")
    fun observeTextBytes(): Flow<Long>

    @Query("SELECT COUNT(*) FROM messages WHERE direction = 0 AND status < 3 AND type IN (2,3,4)")
    fun observeUndeliveredOwn(): Flow<Int>

    @Query("UPDATE messages SET status = :status, statusAt = :at WHERE id = :id AND status < :status")
    suspend fun raiseStatus(id: String, status: Int, at: Long): Int

    @Query("UPDATE messages SET handedToCount = handedToCount + 1 WHERE id = :id")
    suspend fun incrementHandedTo(id: String)

    @Query("UPDATE messages SET relayedByName = :name, relayedAtHop = :hop WHERE id = :id AND relayedByName IS NULL")
    suspend fun setRelayedBy(id: String, name: String, hop: Int)

    @Query("UPDATE messages SET deliveredByName = :name, deliveredHops = :hops, deliveredAt = :at WHERE id = :id AND deliveredAt IS NULL")
    suspend fun setDelivered(id: String, name: String, hops: Int, at: Long)

    @Query("UPDATE messages SET read = 1 WHERE id = :id")
    suspend fun markRead(id: String)

    @Query("SELECT COUNT(*) FROM messages WHERE type = 2 AND direction = 1 AND read = 0")
    fun observeUnreadSos(): Flow<Int>

    @Query("DELETE FROM messages")
    suspend fun deleteAll()
}

@Dao
interface SeenIdDao {
    /** Blocking on purpose: called by the router on the mesh engine's background thread. -1 = already seen. */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insertBlocking(e: SeenIdEntity): Long

    @Query("DELETE FROM seen_ids")
    suspend fun deleteAll()

    @Query("DELETE FROM seen_ids WHERE seenAt < :before")
    suspend fun prune(before: Long)
}

@Dao
interface PeerDao {
    @Upsert suspend fun upsert(p: PeerEntity)

    @Query("SELECT * FROM peers WHERE nodeId = :id")
    suspend fun get(id: String): PeerEntity?

    @Query("SELECT * FROM peers WHERE nodeId = :id")
    fun observe(id: String): Flow<PeerEntity?>

    @Query("SELECT * FROM peers WHERE endpointId = :endpointId LIMIT 1")
    suspend fun byEndpoint(endpointId: String): PeerEntity?

    @Query("SELECT * FROM peers WHERE blocked = 0 ORDER BY connected DESC, lastSeen DESC")
    fun observeAll(): Flow<List<PeerEntity>>

    @Query("SELECT nodeId FROM peers WHERE blocked = 1")
    fun observeBlockedIds(): Flow<List<String>>

    @Query("SELECT nodeId FROM peers WHERE blocked = 1")
    suspend fun blockedIds(): List<String>

    @Query("UPDATE peers SET connected = 0, endpointId = NULL WHERE endpointId = :endpointId")
    suspend fun markDisconnected(endpointId: String)

    @Query("UPDATE peers SET connected = 0, endpointId = NULL")
    suspend fun markAllDisconnected()

    @Query("UPDATE peers SET linkQuality = :q, medium = COALESCE(:medium, medium) WHERE nodeId = :id")
    suspend fun setLink(id: String, q: Float?, medium: String?)

    @Query("UPDATE peers SET blocked = :blocked WHERE nodeId = :id")
    suspend fun setBlocked(id: String, blocked: Boolean)

    @Query("UPDATE peers SET blocked = 0")
    suspend fun unblockAll()

    @Query("UPDATE peers SET verified = 1 WHERE nodeId = :id")
    suspend fun setVerified(id: String)

    @Query("SELECT COUNT(*) FROM peers WHERE blocked = 1")
    fun observeBlockedCount(): Flow<Int>
}

@Dao
abstract class IncidentDao {
    @Query("SELECT * FROM incidents ORDER BY severity ASC, latestAt DESC")
    abstract fun observeAll(): Flow<List<IncidentEntity>>

    @Query("SELECT * FROM incident_reports")
    abstract fun observeLinks(): Flow<List<IncidentReportEntity>>

    @Query("SELECT incidentId FROM incident_reports WHERE messageId = :messageId LIMIT 1")
    abstract suspend fun incidentOf(messageId: String): String?

    @Query("SELECT reportCount FROM incidents WHERE incidentId = :id")
    abstract suspend fun reportCount(id: String): Int?

    @Insert(onConflict = OnConflictStrategy.REPLACE) abstract suspend fun insertAll(i: List<IncidentEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) abstract suspend fun insertLinks(l: List<IncidentReportEntity>)
    @Query("DELETE FROM incidents") abstract suspend fun clear()
    @Query("DELETE FROM incident_reports") abstract suspend fun clearLinks()

    /** Replaces the whole grouping in one transaction (grouping is recomputed from all reports). */
    @Transaction
    open suspend fun replace(incidents: List<IncidentEntity>, links: List<IncidentReportEntity>) {
        clearLinks(); clear(); insertAll(incidents); insertLinks(links)
    }
}

@Dao
interface ReceiptDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insert(r: ReceiptEntity): Long
    @Query("SELECT * FROM receipts WHERE refMessageId = :id ORDER BY receivedAt ASC")
    fun observeFor(id: String): Flow<List<ReceiptEntity>>
    @Query("DELETE FROM receipts") suspend fun deleteAll()
}

@Dao
interface KeyMetadataDao {
    @Upsert suspend fun upsert(k: KeyMetadataEntity)
}

@Dao
interface PendingForwardDao {
    @Upsert suspend fun upsert(p: PendingForwardEntity)
    @Query("SELECT * FROM pending_forward ORDER BY enqueuedAt ASC") suspend fun all(): List<PendingForwardEntity>
    @Query("DELETE FROM pending_forward WHERE messageId = :id") suspend fun delete(id: String)
    @Query("UPDATE pending_forward SET sentTo = :sentTo WHERE messageId = :id") suspend fun setSentTo(id: String, sentTo: String)
    @Query("DELETE FROM pending_forward WHERE createdAt < :before") suspend fun pruneOlderThan(before: Long)
    @Query("DELETE FROM pending_forward") suspend fun deleteAll()
    @Query("SELECT COUNT(*) FROM pending_forward") fun observeCount(): Flow<Int>
}

@Dao
interface BatteryDao {
    @Insert suspend fun insert(s: BatterySampleEntity)
    @Query("SELECT * FROM battery_samples WHERE at >= :since ORDER BY at ASC") suspend fun since(since: Long): List<BatterySampleEntity>
}
