package com.meshsos.app.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.meshsos.app.LocalContainer
import com.meshsos.app.LocalPermissions
import com.meshsos.app.R
import com.meshsos.app.ui.components.ChipToggle
import com.meshsos.app.ui.components.Lbl
import com.meshsos.app.ui.components.MeshButton
import com.meshsos.app.ui.components.MeshCard
import com.meshsos.app.ui.components.MeshIcons
import com.meshsos.app.ui.components.Pill
import com.meshsos.app.ui.components.PillKind
import com.meshsos.app.ui.components.PulseDot
import com.meshsos.app.ui.components.SmallIcon
import com.meshsos.app.ui.components.StripeItem
import com.meshsos.app.ui.components.relativeTime
import com.meshsos.app.ui.theme.LocalMesh
import com.meshsos.app.ui.theme.MeshFonts
import com.meshsos.app.ui.theme.MeshType
import com.meshsos.core.model.Severity

/** Scrollable screen body with the prototype's 16 dp side padding and 12 dp gaps. */
@Composable
fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 18.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp), content = content,
)

@Composable
fun Brand(size: Int = 26) {
    val c = LocalMesh.current
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(MeshIcons.Mark, null, tint = c.ink, modifier = Modifier.size(size.dp))
        Text(stringResource(R.string.app_name), style = MeshType.screenTitle.copy(fontSize = size.sp), color = c.ink)
    }
}

// ------------------------------------------------------------------------- 1. Privacy notice
@Composable
fun OnboardingScreen(onDone: () -> Unit) {
    val c = LocalMesh.current
    val container = LocalContainer.current
    val perms = LocalPermissions.current
    var name by remember { mutableStateOf(container.settings.settings.value.displayName) }
    Column(Modifier.fillMaxSize().background(c.app).windowInsetsPadding(WindowInsets.safeDrawing)) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Spacer(Modifier.height(8.dp))
            Brand(30)
            Text(stringResource(R.string.onb_title), style = MeshType.hero, color = c.ink)
            Text(stringResource(R.string.onb_sub), color = c.mute, style = MeshType.body)
            MeshCard {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    for ((icon, tint, text) in listOf(
                        Triple(MeshIcons.Pin, c.mesh, R.string.onb_p_location), Triple(MeshIcons.Users, c.mesh, R.string.onb_p_visible),
                        Triple(MeshIcons.Lock, c.mesh, R.string.onb_p_storage), Triple(MeshIcons.Alert, c.sos, R.string.onb_p_999),
                    )) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SmallIcon(icon, tint); Text(stringResource(text), style = MeshType.body, color = c.ink)
                    }
                }
            }
            OutlinedTextField(name, { name = it.take(40) }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text(stringResource(R.string.onb_name_hint)) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = c.mesh, unfocusedBorderColor = c.line,
                    focusedContainerColor = c.card, unfocusedContainerColor = c.card))
            Text(stringResource(R.string.onb_permissions), style = MeshType.small, color = c.mute)
        }
        HorizontalDivider(color = c.line)
        Box(Modifier.padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 14.dp)) {
            MeshButton(stringResource(R.string.onb_continue), onClick = {
                container.settings.update { it.copy(onboarded = true, displayName = name.trim()) }
                perms.request()
                onDone()
            })
        }
    }
}

// ------------------------------------------------------------------------- 2. Home and SOS
@Composable
fun HomeScreen(onSos: () -> Unit, onAlerts: () -> Unit) {
    val c = LocalMesh.current
    val container = LocalContainer.current
    val perms = LocalPermissions.current
    val mesh by container.engine.state.collectAsStateWithLifecycle()
    val sos by container.db.messages().observeReceivedSos().collectAsStateWithLifecycle(emptyList())
    val since = System.currentTimeMillis() - 24 * 3600_000L
    val recent = sos.filter { it.receivedAt >= since }

    ScreenColumn {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Brand()
            Spacer(Modifier.weight(1f))
            when {
                mesh.running -> Pill(stringResource(R.string.mesh_on), PillKind.OK, leading = { PulseDot(c.ok) })
                perms.granted -> Pill(stringResource(R.string.mesh_starting), PillKind.UNCL)
                else -> Pill(stringResource(R.string.mesh_off), PillKind.CRIT)
            }
        }
        if (!perms.granted) MeshCard {
            Text(stringResource(R.string.perm_needed), style = MeshType.body, color = c.ink)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChipToggle(stringResource(R.string.perm_retry), false, perms.request)
                ChipToggle(stringResource(R.string.perm_open_settings), false, perms.openSettings)
            }
        } else if (!perms.bluetoothOn) MeshCard { Text(stringResource(R.string.bt_off), style = MeshType.body, color = c.amber) }

        SosButton(onSos)

        MeshCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Lbl(stringResource(R.string.phones_around), Modifier.weight(1f))
                Pill(stringResource(if (mesh.powerSaving) R.string.scan_30s else R.string.scan_5s), PillKind.NORM)
            }
            MeshGraph(connected = mesh.connectedCount, found = mesh.discovered.size, rescuerHops = mesh.rescuerHops)
            Text(stringResource(R.string.phones_summary, mesh.connectedCount, mesh.discovered.size) + " " +
                (mesh.rescuerHops?.let { stringResource(R.string.rescuer_hops, it) } ?: stringResource(R.string.rescuer_none)),
                style = MeshType.small, color = c.mute)
        }

        val crit = recent.count { it.severity == Severity.CRITICAL.code }
        val stripe = when { crit > 0 -> c.sos; recent.isNotEmpty() -> c.amber; else -> c.line }
        StripeItem(stripe, onAlerts) {
            Column(Modifier.weight(1f)) {
                if (recent.isEmpty()) Text(stringResource(R.string.no_alerts), style = MeshType.bodyStrong, color = c.ink)
                else {
                    Text(stringResource(R.string.alerts_near, recent.size), style = MeshType.bodyStrong, color = c.ink)
                    Text(stringResource(R.string.alerts_meta, crit, relativeTime(recent.first().receivedAt)), style = MeshType.small, color = c.mute)
                }
            }
            SmallIcon(MeshIcons.Chevron, c.mute)
        }

        MeshCard {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                SmallIcon(MeshIcons.Bolt, c.amber)
                Column(Modifier.weight(1f)) {
                    if (mesh.queueSize == 0) Text(stringResource(R.string.nothing_waiting), style = MeshType.bodyStrong, color = c.ink)
                    else {
                        Text(stringResource(R.string.waiting_title, mesh.queueSize), style = MeshType.bodyStrong, color = c.ink)
                        Text(stringResource(R.string.waiting_sub), style = MeshType.small, color = c.mute)
                    }
                }
            }
        }
    }
}

@Composable
private fun SosButton(onClick: () -> Unit) {
    val c = LocalMesh.current
    val t = rememberInfiniteTransition(label = "ring")
    val k by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "k")
    val cd = stringResource(R.string.sos_cd)
    Box(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 18.dp), contentAlignment = Alignment.Center) {
        Box(
            Modifier.size(176.dp)
                .drawBehind {
                    val r = size.minDimension / 2
                    drawCircle(c.sos.copy(alpha = 0.08f - 0.03f * k), radius = r + (22 + 8 * k).dp.toPx())
                    drawCircle(c.sos.copy(alpha = 0.16f - 0.02f * k), radius = r + (10 + 4 * k).dp.toPx())
                }
                .clip(CircleShape).background(c.sos)
                .clickable(role = Role.Button, onClick = onClick).semantics { contentDescription = cd },
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("SOS", color = c.sosInk, style = TextStyle(fontFamily = MeshFonts.display, fontWeight = FontWeight.Bold,
                    fontSize = 58.sp, letterSpacing = 2.sp))
                Text(stringResource(R.string.sos_tap), color = c.sosInk, fontSize = 12.5.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

/** Live picture of the local mesh: you, up to three connected phones, phones only found, and a rescuer if known. */
@Composable
private fun MeshGraph(connected: Int, found: Int, rescuerHops: Int?) {
    val c = LocalMesh.current
    val measurer = rememberTextMeasurer()
    val you = stringResource(R.string.graph_you)
    val resc = stringResource(R.string.graph_rescuer)
    val hop = stringResource(R.string.graph_hop, 1)
    val labelStyle = TextStyle(fontSize = 10.sp, color = c.mute)
    Canvas(Modifier.fillMaxWidth().height(84.dp)) {
        val w = size.width; val h = size.height
        val me = Offset(w * 0.11f, h * 0.5f)
        val slots = listOf(Offset(w * 0.42f, h * 0.22f), Offset(w * 0.42f, h * 0.78f), Offset(w * 0.62f, h * 0.5f))
        val shownConnected = minOf(connected, 3)
        val shownFound = minOf(found, 3 - shownConnected)
        for (i in 0 until shownConnected) drawLine(c.mesh, me, slots[i], strokeWidth = 2.5.dp.toPx())
        for (i in 0 until shownFound) drawLine(c.line, me, slots[shownConnected + i], strokeWidth = 2.dp.toPx())
        val rescuerAt = Offset(w * 0.89f, h * 0.5f)
        if (rescuerHops != null && shownConnected > 0) {
            drawLine(c.mesh, slots[0], rescuerAt, strokeWidth = 2.5.dp.toPx())
        }
        for (i in 0 until shownConnected) drawCircle(c.mesh, 8.dp.toPx(), slots[i])
        for (i in 0 until shownFound) {
            drawCircle(c.meshSoft, 8.dp.toPx(), slots[shownConnected + i])
            drawCircle(c.mesh, 8.dp.toPx(), slots[shownConnected + i], style = Stroke(2.dp.toPx()))
        }
        if (rescuerHops != null) {
            drawCircle(c.card, 10.dp.toPx(), rescuerAt); drawCircle(c.ink, 10.dp.toPx(), rescuerAt, style = Stroke(2.5.dp.toPx()))
            val t = measurer.measure(resc, labelStyle)
            drawText(t, topLeft = Offset(rescuerAt.x - t.size.width / 2, rescuerAt.y + 13.dp.toPx()))
        }
        drawCircle(c.sos, 11.dp.toPx(), me)
        val tYou = measurer.measure(you, labelStyle)
        drawText(tYou, topLeft = Offset(me.x - tYou.size.width / 2, me.y + 14.dp.toPx()))
        if (shownConnected > 0) {
            val tHop = measurer.measure(hop, labelStyle)
            drawText(tHop, topLeft = Offset(slots[0].x - tHop.size.width / 2, 0f))
        }
    }
}
