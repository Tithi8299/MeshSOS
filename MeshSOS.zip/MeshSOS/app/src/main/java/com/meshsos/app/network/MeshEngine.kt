package com.meshsos.app.network

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.util.Log
import com.google.android.gms.nearby.connection.BandwidthInfo
import com.meshsos.app.data.database.Direction
import com.meshsos.app.data.database.MeshDatabase
import com.meshsos.app.data.database.MessageEntity
import com.meshsos.app.data.database.PeerEntity
import com.meshsos.app.data.database.PendingForwardEntity
import com.meshsos.app.data.database.ReceiptEntity
import com.meshsos.app.data.database.SeenIdEntity
import com.meshsos.app.data.database.BatterySampleEntity
import com.meshsos.app.data.repository.AppSettings
import com.meshsos.app.data.repository.IncidentRepository
import com.meshsos.app.data.repository.PriorityMode
import com.meshsos.app.network.nearby.NearbyTransport
import com.meshsos.app.service.Notifier
import com.meshsos.core.ai.LinkContext
import com.meshsos.core.ai.PriorityScorer
import com.meshsos.core.crypto.Identity
import com.meshsos.core.crypto.PacketSigner
import com.meshsos.core.crypto.PrivateMessageCipher
import com.meshsos.core.model.Category
import com.meshsos.core.model.DeliveryStatus
import com.meshsos.core.model.PacketType
import com.meshsos.core.model.ReceiptKind
import com.meshsos.core.model.Severity
import com.meshsos.core.packet.Packet
import com.meshsos.core.packet.PacketCodec
import com.meshsos.core.packet.PacketValidator
import com.meshsos.core.routing.DropReason
import com.meshsos.core.routing.MeshRouter
import com.meshsos.core.routing.PriorityForwardQueue
import com.meshsos.core.routing.RouteDecision
import com.meshsos.core.routing.RouterConfig
import com.meshsos.core.routing.SeenStore
import com.meshsos.app.security.TinkCurveProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

data class MeshCounters(
    val received: Int = 0, val forwarded: Int = 0, val dropped: Int = 0, val duplicates: Int = 0,
    val badSignature: Int = 0, val ttlExhausted: Int = 0, val malformed: Int = 0,
)

data class DiscoveredEndpoint(val endpointId: String, val name: String, val nodeIdPrefix: String?, val connecting: Boolean)

data class MeshState(
    val running: Boolean = false,
    val advertising: Boolean = false,
    val discovering: Boolean = false,
    val powerSaving: Boolean = false,
    val connectedCount: Int = 0,
    /** Found by discovery but not (yet) connected. */
    val discovered: List<DiscoveredEndpoint> = emptyList(),
    val queueSize: Int = 0,
    val counters: MeshCounters = MeshCounters(),
    val discoveryOnMillis: Long = 0,
    val measuredMillis: Long = 0,
    /** Fewest hops to a phone in rescuer mode we have heard from, or null. */
    val rescuerHops: Int? = null,
    val lastError: String? = null,
)

data class SosDraft(
    val text: String, val category: Category, val severity: Severity, val peopleCount: Int,
    val aiConfidence: Float, val userEdited: Boolean, val latitude: Double?, val longitude: Double?, val accuracy: Float?,
)

/**
 * Glues the pure-Kotlin router and priority queue to Nearby Connections, Room, the classifier
 * and notifications. All mesh state changes run on one serial background dispatcher, so the
 * router, queue and database always see events in order.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class MeshEngine(
    private val context: Context,
    private val db: MeshDatabase,
    private val identity: Identity,
    private val incidents: IncidentRepository,
    private val notifier: Notifier,
    private val ruleScorer: PriorityScorer,
    private val learnedScorer: PriorityScorer?,
) : NearbyTransport.Listener {
    private val serial = Dispatchers.IO.limitedParallelism(1)
    private val scope = CoroutineScope(SupervisorJob() + serial)
    private val signer = PacketSigner(TinkCurveProvider)
    private val dmCipher = PrivateMessageCipher(TinkCurveProvider)
    private val seenStore = object : SeenStore {
        override fun markIfNew(messageId: String, atMillis: Long) = db.seenIds().insertBlocking(SeenIdEntity(messageId, atMillis)) != -1L
    }
    private val router = MeshRouter(identity, signer, seenStore, RouterConfig())
    @Volatile private var scorer: PriorityScorer = ruleScorer
    private val queue = PriorityForwardQueue(object : PriorityScorer {
        override fun score(p: Packet, nowMillis: Long, link: LinkContext, enqueuedAtMillis: Long) = scorer.score(p, nowMillis, link, enqueuedAtMillis)
        override fun shouldSend(p: Packet, nowMillis: Long, link: LinkContext, enqueuedAtMillis: Long) = scorer.shouldSend(p, nowMillis, link, enqueuedAtMillis)
    })
    private val transport = NearbyTransport(context, CoroutineScope(SupervisorJob() + Dispatchers.Main), this)

    private val endpointToNode = ConcurrentHashMap<String, String>()
    private val discovered = ConcurrentHashMap<String, DiscoveredEndpoint>()
    private val inFlight = ConcurrentHashMap<Long, Pair<String, String>>()   // payloadId -> (messageId, nodeId)
    private val linkEwma = ConcurrentHashMap<String, Float>()                 // nodeId -> success ratio
    private val bandwidth = ConcurrentHashMap<String, Int>()                  // nodeId -> BandwidthInfo.Quality
    private val recentSosBySender = ConcurrentHashMap<String, ArrayDeque<Long>>()
    private var settings = AppSettings()
    private var periodic: Job? = null

    private val _state = MutableStateFlow(MeshState())
    val state: StateFlow<MeshState> = _state.asStateFlow()
    val nodeId get() = identity.nodeId

    // ------------------------------------------------------------------ lifecycle
    fun start(s: AppSettings) {
        scope.launch {
            if (_state.value.running) return@launch
            applySettingsInternal(s)
            db.peers().markAllDisconnected()
            restoreQueue()
            withContext(Dispatchers.Main) { transport.start(identity.nodeId, s.displayName.ifBlank { "MeshSOS" }, s.powerSaving) }
            _state.update { it.copy(running = true, powerSaving = s.powerSaving) }
            periodic = scope.launch { periodicLoop() }
        }
    }

    fun stop() {
        scope.launch {
            periodic?.cancel()
            withContext(Dispatchers.Main) { transport.stop() }
            endpointToNode.clear(); discovered.clear()
            db.peers().markAllDisconnected()
            _state.update { it.copy(running = false, connectedCount = 0, discovered = emptyList(), discovering = false, advertising = false) }
        }
    }

    fun applySettings(s: AppSettings) { scope.launch { applySettingsInternal(s) } }

    private suspend fun applySettingsInternal(s: AppSettings) {
        settings = s
        identity.displayName = s.displayName.take(Packet.MAX_NAME_CHARS)
        router.config = RouterConfig(relayEnabled = s.relayEnabled, isRescuer = s.rescuerMode)
        scorer = if (s.priorityMode == PriorityMode.LEARNED && learnedScorer != null) learnedScorer else ruleScorer
        withContext(Dispatchers.Main) { transport.setPowerSaving(s.powerSaving) }
        _state.update { it.copy(powerSaving = s.powerSaving) }
    }

    private suspend fun periodicLoop() {
        var tick = 0
        while (scope.isActive) {
            delay(10_000)
            tick++
            val now = System.currentTimeMillis()
            queue.removeExpired(now, PacketValidator.MAX_AGE_MS).forEach { db.pending().delete(it) }
            flushAll()
            if (tick % 60 == 0) {   // every 10 minutes
                sampleBattery()
                db.seenIds().prune(now - 72 * 3600_000L)   // keep longer than the 48 h packet lifetime
                db.pending().pruneOlderThan(now - PacketValidator.MAX_AGE_MS)
            }
            publishState()
        }
    }

    // ------------------------------------------------------------------ user actions
    /** Builds, signs, stores and queues an SOS. Returns the message id. Never blocked by the AI. */
    suspend fun sendSos(d: SosDraft): String = withContext(serial) {
        val now = System.currentTimeMillis()
        val unsigned = Packet(
            type = PacketType.SOS, messageId = MeshRouter.newMessageId(), senderId = identity.nodeId,
            senderSigningKey = identity.signing.publicKey, senderAgreementKey = identity.agreement.publicKey,
            senderName = settings.displayName.take(Packet.MAX_NAME_CHARS), createdAtMillis = now,
            originalTtl = Packet.DEFAULT_TTL, ttl = Packet.DEFAULT_TTL, category = d.category, severity = d.severity,
            peopleCount = d.peopleCount.coerceIn(0, 999), aiConfidence = d.aiConfidence.coerceIn(0f, 1f),
            userEdited = d.userEdited, latitude = d.latitude, longitude = d.longitude, accuracyMeters = d.accuracy,
            text = d.text.take(Packet.MAX_TEXT_CHARS), isRescuer = settings.rescuerMode,
        )
        val p = router.originate(unsigned)
        db.messages().insert(entityFor(p, Direction.OUT, now, identity.nodeId, p.text))
        enqueue(p, isOwn = true)
        flushAll()
        p.messageId
    }

    suspend fun ownSosInLastTenMinutes(): Int = withContext(serial) {
        db.messages().ownSosSince(identity.nodeId, System.currentTimeMillis() - 10 * 60_000)
    }

    /** One-to-one encrypted message (FR7, FR11). Needs the recipient's X25519 key from a signed packet. */
    suspend fun sendDirect(peerId: String, text: String): Boolean = withContext(serial) {
        val peer = db.peers().get(peerId) ?: return@withContext false
        val now = System.currentTimeMillis()
        val mid = MeshRouter.newMessageId()
        val sealed = dmCipher.seal(text.take(Packet.MAX_TEXT_CHARS), identity.nodeId, peerId, peer.agreementKey, mid)
        val p = router.originate(Packet(
            type = PacketType.DIRECT_TEXT, messageId = mid, senderId = identity.nodeId,
            senderSigningKey = identity.signing.publicKey, senderAgreementKey = identity.agreement.publicKey,
            senderName = settings.displayName.take(Packet.MAX_NAME_CHARS), createdAtMillis = now,
            originalTtl = Packet.DEFAULT_TTL, ttl = Packet.DEFAULT_TTL, recipientId = peerId,
            ciphertext = sealed.ciphertext, ephemeralKey = sealed.ephemeralPublicKey,
        ))
        // The plaintext of our own message is stored locally only; the wire carries ciphertext.
        db.messages().insert(entityFor(p, Direction.OUT, now, peerId, text))
        enqueue(p, isOwn = true); flushAll()
        true
    }

    /** Public short text to everyone nearby (FR7). */
    suspend fun sendBroadcast(text: String): String = withContext(serial) {
        val now = System.currentTimeMillis()
        val p = router.originate(Packet(
            type = PacketType.BROADCAST_TEXT, messageId = MeshRouter.newMessageId(), senderId = identity.nodeId,
            senderSigningKey = identity.signing.publicKey, senderAgreementKey = identity.agreement.publicKey,
            senderName = settings.displayName.take(Packet.MAX_NAME_CHARS), createdAtMillis = now,
            originalTtl = Packet.DEFAULT_TTL, ttl = Packet.DEFAULT_TTL, text = text.take(Packet.MAX_TEXT_CHARS),
        ))
        db.messages().insert(entityFor(p, Direction.OUT, now, BROADCAST_PEER, p.text))
        enqueue(p, isOwn = true); flushAll()
        p.messageId
    }

    fun connect(endpointId: String) = transport.requestConnection(endpointId)

    suspend fun setBlocked(nodeId: String, blocked: Boolean) = withContext(serial) { db.peers().setBlocked(nodeId, blocked) }

    suspend fun deleteAllStored() = withContext(serial) {
        db.messages().deleteAll(); db.receipts().deleteAll(); db.pending().deleteAll()
        queue.snapshot().forEach { queue.remove(it.packet.messageId) }
        incidents.regroupNow()
        publishState()
    }

    /** Priority score and position of a queued message, for the Delivery status screen. */
    fun priorityOf(messageId: String): Triple<Double, Int, Int>? {
        val now = System.currentTimeMillis()
        val entries = queue.snapshot()
        val ranked = entries.sortedByDescending { scorer.score(it.packet, now, LinkContext(batteryFraction(), null), it.enqueuedAtMillis) }
        val idx = ranked.indexOfFirst { it.packet.messageId == messageId }
        if (idx < 0) return null
        val e = ranked[idx]
        return Triple(scorer.score(e.packet, now, LinkContext(batteryFraction(), null), e.enqueuedAtMillis), idx + 1, ranked.size)
    }

    // ------------------------------------------------------------------ queue
    /** [alreadyHas]: neighbours known to hold the packet already (e.g. the one that just sent it to us). */
    private suspend fun enqueue(p: Packet, isOwn: Boolean, alreadyHas: Set<String> = emptySet()) {
        val now = System.currentTimeMillis()
        if (queue.offer(p, now, alreadyHas)) {
            db.pending().upsert(PendingForwardEntity(p.messageId, PacketCodec.encode(p), p.severity.code, isOwn, now,
                p.createdAtMillis, alreadyHas.joinToString(",")))
        }
    }

    private suspend fun restoreQueue() {
        for (e in db.pending().all()) {
            val p = runCatching { PacketCodec.decode(e.packet) }.getOrNull() ?: run { db.pending().delete(e.messageId); null } ?: continue
            queue.offer(p, e.enqueuedAt, e.sentTo.split(',').filter { it.isNotBlank() }.toSet())
        }
    }

    private suspend fun flushAll() {
        for ((endpoint, node) in endpointToNode) flushTo(endpoint, node)
        publishState()
    }

    private suspend fun flushTo(endpointId: String, nodeId: String) {
        if (endpointId !in transport.connectedEndpoints()) return
        val link = LinkContext(batteryFraction(), linkQualityOf(nodeId))
        val next = queue.nextFor(nodeId, System.currentTimeMillis(), link, max = 16)
        for (p in next) {
            val bytes = PacketCodec.encode(p)
            val payloadId = withContext(Dispatchers.Main) { transport.send(endpointId, bytes) } ?: break
            inFlight[payloadId] = p.messageId to nodeId
            queue.markSent(p.messageId, nodeId)
            val sentTo = queue.snapshot().firstOrNull { it.packet.messageId == p.messageId }?.sentTo?.joinToString(",") ?: nodeId
            db.pending().setSentTo(p.messageId, sentTo)
            if (p.senderId != identity.nodeId) bump { it.copy(forwarded = it.forwarded + 1) }
        }
    }

    // ------------------------------------------------------------------ transport callbacks
    override fun onEndpointFound(endpointId: String, nodeIdPrefix: String?, name: String) {
        discovered[endpointId] = DiscoveredEndpoint(endpointId, name, nodeIdPrefix, false)
        scope.launch { publishState() }
    }

    override fun onEndpointLost(endpointId: String) {
        discovered.remove(endpointId); scope.launch { publishState() }
    }

    override fun onConnecting(endpointId: String) {
        discovered[endpointId]?.let { discovered[endpointId] = it.copy(connecting = true) }
        scope.launch { publishState() }
    }

    override fun onConnected(endpointId: String, name: String) {
        discovered.remove(endpointId)
        scope.launch {
            sendHello(endpointId)
            publishState()
        }
    }

    override fun onConnectionFailed(endpointId: String, statusCode: Int) {
        discovered[endpointId]?.let { discovered[endpointId] = it.copy(connecting = false) }
        scope.launch { _state.update { it.copy(lastError = "connection failed ($statusCode)") }; publishState() }
    }

    override fun onDisconnected(endpointId: String) {
        scope.launch {
            endpointToNode.remove(endpointId)
            db.peers().markDisconnected(endpointId)
            publishState()
        }
    }

    override fun onBytes(endpointId: String, bytes: ByteArray) {
        scope.launch { handleIncoming(endpointId, bytes) }
    }

    override fun onTransferResult(endpointId: String, payloadId: Long, success: Boolean) {
        scope.launch {
            val (messageId, nodeId) = inFlight.remove(payloadId) ?: return@launch
            val old = linkEwma[nodeId] ?: 0.75f
            linkEwma[nodeId] = old * 0.8f + (if (success) 1f else 0f) * 0.2f
            db.peers().setLink(nodeId, linkQualityOf(nodeId), null)
            val msg = db.messages().get(messageId)
            if (success) {
                // "Sent" is set only from a real Nearby transfer SUCCESS, never from a timer.
                if (msg != null && msg.direction == Direction.OUT) {
                    db.messages().incrementHandedTo(messageId)
                    db.messages().raiseStatus(messageId, DeliveryStatus.SENT.code, System.currentTimeMillis())
                }
            } else {
                // allow a retry to this neighbour
                queue.snapshot().firstOrNull { it.packet.messageId == messageId }?.sentTo?.remove(nodeId)
            }
        }
    }

    override fun onBandwidth(endpointId: String, quality: Int) {
        scope.launch {
            val node = endpointToNode[endpointId] ?: return@launch
            bandwidth[node] = quality
            val medium = when (quality) {
                BandwidthInfo.Quality.HIGH -> "high"; BandwidthInfo.Quality.MEDIUM -> "medium"; BandwidthInfo.Quality.LOW -> "low"; else -> null
            }
            db.peers().setLink(node, linkQualityOf(node), medium)
        }
    }

    override fun onTransportError(what: String, statusCode: Int) {
        Log.w(TAG, "$what failed with status $statusCode")
        scope.launch { _state.update { it.copy(lastError = "$what failed ($statusCode)") } }
    }

    // ------------------------------------------------------------------ incoming packets
    private suspend fun sendHello(endpointId: String) {
        val hello = router.originate(Packet(
            type = PacketType.HELLO, messageId = MeshRouter.newMessageId(), senderId = identity.nodeId,
            senderSigningKey = identity.signing.publicKey, senderAgreementKey = identity.agreement.publicKey,
            senderName = settings.displayName.take(Packet.MAX_NAME_CHARS), createdAtMillis = System.currentTimeMillis(),
            originalTtl = 0, ttl = 0, isRescuer = settings.rescuerMode, batteryPercent = batteryPercent(),
        ))
        withContext(Dispatchers.Main) { transport.send(endpointId, PacketCodec.encode(hello)) }
    }

    private suspend fun handleIncoming(endpointId: String, bytes: ByteArray) {
        bump { it.copy(received = it.received + 1) }
        when (val d = router.onReceive(bytes)) {
            is RouteDecision.Dropped -> {
                bump {
                    when (d.reason) {
                        DropReason.DUPLICATE -> it.copy(dropped = it.dropped + 1, duplicates = it.duplicates + 1)
                        DropReason.BAD_SIGNATURE -> it.copy(dropped = it.dropped + 1, badSignature = it.badSignature + 1)
                        DropReason.MALFORMED, DropReason.INVALID -> it.copy(dropped = it.dropped + 1, malformed = it.malformed + 1)
                        DropReason.OWN_PACKET -> it.copy(dropped = it.dropped + 1)
                    }
                }
            }
            is RouteDecision.Hello -> onHello(endpointId, d.packet)
            is RouteDecision.Accepted -> onAccepted(d, endpointToNode[endpointId])
        }
        publishState()
    }

    private suspend fun onHello(endpointId: String, p: Packet) {
        val now = System.currentTimeMillis()
        val old = db.peers().get(p.senderId)
        if (old != null && !old.signingKey.contentEquals(p.senderSigningKey)) return   // impossible unless SHA-256 collides
        endpointToNode[endpointId] = p.senderId
        db.peers().upsert(PeerEntity(
            nodeId = p.senderId, displayName = p.senderName, signingKey = p.senderSigningKey,
            agreementKey = p.senderAgreementKey, isRescuer = p.isRescuer, firstSeen = old?.firstSeen ?: now, lastSeen = now,
            endpointId = endpointId, connected = true, batteryPercent = p.batteryPercent, linkQuality = linkQualityOf(p.senderId),
            medium = old?.medium, verified = old?.verified ?: false, blocked = old?.blocked ?: false, minHops = 1,
        ))
        if (p.isRescuer) _state.update { it.copy(rescuerHops = 1) }
        flushTo(endpointId, p.senderId)   // store-and-forward: a new neighbour gets everything queued
    }

    private suspend fun onAccepted(d: RouteDecision.Accepted, fromNode: String?) {
        val p = d.packet
        val now = System.currentTimeMillis()
        val blocked = p.senderId in db.peers().blockedIds()
        if (blocked) return                                   // hidden senders are neither shown nor relayed
        rememberSender(p, now)
        var forward = d.forward
        if (p.type == PacketType.SOS && overRateLimit(p.senderId, now)) forward = null
        if (forward == null && d.notForwardedBecause == "ttl exhausted") bump { it.copy(ttlExhausted = it.ttlExhausted + 1) }

        if (d.deliverLocally) when (p.type) {
            PacketType.SOS -> {
                val r = incidents.embed(p.text)
                db.messages().insert(entityFor(p, Direction.IN, now, p.senderId, p.text).copy(concept = r))
                incidents.regroupSoon()
                notifier.sos(p)
            }
            PacketType.BROADCAST_TEXT -> db.messages().insert(entityFor(p, Direction.IN, now, BROADCAST_PEER, p.text))
            PacketType.DIRECT_TEXT -> {
                val plain = runCatching { dmCipher.open(p, identity) }.getOrNull()
                if (plain != null) {
                    db.messages().insert(entityFor(p, Direction.IN, now, p.senderId, plain))
                    notifier.directMessage(p.senderName, p.senderId)
                }
            }
            PacketType.RECEIPT -> onReceiptForMe(p, now)
            PacketType.HELLO -> {}
        }
        // A DELIVERED receipt passing through means we can stop carrying that message.
        if (p.type == PacketType.RECEIPT && p.receiptKind == ReceiptKind.DELIVERED) {
            p.refMessageId?.let { ref -> if (queue.remove(ref)) db.pending().delete(ref) }
        }
        if (forward != null) enqueue(forward, isOwn = false, alreadyHas = setOfNotNull(fromNode))
        for (r in d.receipts) enqueue(r, isOwn = true)
        flushAll()
    }

    private suspend fun onReceiptForMe(p: Packet, now: Long) {
        val ref = p.refMessageId ?: return
        val mine = db.messages().get(ref) ?: return
        if (mine.direction != Direction.OUT) return
        val kind = p.receiptKind ?: return
        db.receipts().insert(ReceiptEntity(p.messageId, ref, kind.code, p.senderId, p.senderName, p.isRescuer, p.hopCount + 1, now))
        when (kind) {
            ReceiptKind.RELAYED -> {
                db.messages().setRelayedBy(ref, p.senderName.ifBlank { p.senderId.take(6) }, p.hopCount + 1)
                db.messages().raiseStatus(ref, DeliveryStatus.RELAYED.code, now)
            }
            ReceiptKind.DELIVERED -> {
                // Hops travelled by the SOS ~ hops travelled by the receipt (receipts take the reverse mesh).
                db.messages().setDelivered(ref, p.senderName.ifBlank { p.senderId.take(6) }, p.hopCount + 1, now)
                db.messages().raiseStatus(ref, DeliveryStatus.DELIVERED.code, now)
                if (queue.remove(ref)) db.pending().delete(ref)
                if (p.isRescuer) _state.update { s -> s.copy(rescuerHops = minOf(s.rescuerHops ?: 99, p.hopCount + 1)) }
                if (mine.type == PacketType.SOS.code) notifier.delivered(p.senderName)
            }
        }
    }

    /** Keeps the signed public keys of every sender, so a received SOS can be answered privately. */
    private suspend fun rememberSender(p: Packet, now: Long) {
        if (p.type == PacketType.RECEIPT && p.recipientId != identity.nodeId) return
        val old = db.peers().get(p.senderId)
        db.peers().upsert(PeerEntity(
            nodeId = p.senderId, displayName = p.senderName.ifBlank { old?.displayName ?: "" }, signingKey = p.senderSigningKey,
            agreementKey = p.senderAgreementKey, isRescuer = p.isRescuer || (old?.isRescuer ?: false),
            firstSeen = old?.firstSeen ?: now, lastSeen = now, endpointId = old?.endpointId, connected = old?.connected ?: false,
            batteryPercent = old?.batteryPercent ?: -1, linkQuality = old?.linkQuality, medium = old?.medium,
            verified = old?.verified ?: false, blocked = old?.blocked ?: false,
            minHops = minOf(old?.minHops ?: 99, p.hopCount + 1),
        ))
    }

    /** Proposal 5.3: at most 6 SOS per 10 minutes per sender are relayed. */
    private fun overRateLimit(sender: String, now: Long): Boolean {
        val q = recentSosBySender.getOrPut(sender) { ArrayDeque() }
        while (q.isNotEmpty() && now - q.first() > 10 * 60_000) q.removeFirst()
        q.addLast(now)
        return q.size > 6
    }

    // ------------------------------------------------------------------ helpers
    private fun entityFor(p: Packet, dir: Int, now: Long, peer: String, text: String) = MessageEntity(
        id = p.messageId, type = p.type.code, direction = dir, senderId = p.senderId, senderName = p.senderName,
        recipientId = p.recipientId, peerId = peer, text = text, category = p.category.code, severity = p.severity.code,
        peopleCount = p.peopleCount, aiConfidence = p.aiConfidence, userEdited = p.userEdited, latitude = p.latitude,
        longitude = p.longitude, accuracyMeters = p.accuracyMeters, createdAt = p.createdAtMillis, receivedAt = now,
        hopCount = p.hopCount, lastHopId = p.lastHopId, status = DeliveryStatus.QUEUED.code, statusAt = now,
        read = dir == Direction.OUT,
    )

    private fun linkQualityOf(nodeId: String): Float? {
        val e = linkEwma[nodeId]
        val bw = when (bandwidth[nodeId]) {
            BandwidthInfo.Quality.HIGH -> 0.95f; BandwidthInfo.Quality.MEDIUM -> 0.75f; BandwidthInfo.Quality.LOW -> 0.5f; else -> null
        }
        return when {
            e != null && bw != null -> 0.6f * e + 0.4f * bw
            else -> e ?: bw
        }
    }

    private fun batteryStatus(): Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

    fun batteryPercent(): Int {
        val i = batteryStatus() ?: return -1
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1); val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        return if (level >= 0 && scale > 0) level * 100 / scale else -1
    }

    private fun batteryFraction(): Float? = batteryPercent().takeIf { it >= 0 }?.div(100f)

    private suspend fun sampleBattery() {
        val i = batteryStatus() ?: return
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1); val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        if (level < 0 || scale <= 0) return
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        db.battery().insert(BatterySampleEntity(at = System.currentTimeMillis(), percent = level * 100f / scale,
            charging = plugged, powerSaving = settings.powerSaving, discoveryOnMillis = transport.discoveryOnMillis()))
    }

    private fun bump(f: (MeshCounters) -> MeshCounters) = _state.update { it.copy(counters = f(it.counters)) }

    private fun publishState() {
        _state.update {
            it.copy(
                advertising = transport.advertising, discovering = transport.discovering,
                connectedCount = transport.connectedEndpoints().size, discovered = discovered.values.toList(),
                queueSize = queue.size(), discoveryOnMillis = transport.discoveryOnMillis(),
                measuredMillis = transport.measuredForMillis(),
            )
        }
    }

    companion object {
        const val BROADCAST_PEER = "all"
        private const val TAG = "MeshEngine"
    }
}
