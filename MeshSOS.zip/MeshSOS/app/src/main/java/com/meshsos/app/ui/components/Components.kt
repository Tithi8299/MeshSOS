package com.meshsos.app.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.meshsos.app.R
import com.meshsos.app.ui.theme.LocalMesh
import com.meshsos.app.ui.theme.MeshType
import com.meshsos.core.model.Category
import com.meshsos.core.model.Severity

@Composable
fun MeshCard(modifier: Modifier = Modifier, padding: Dp = 12.dp, content: @Composable ColumnScope.() -> Unit) {
    val c = LocalMesh.current
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.card)
            .border(1.dp, c.line, RoundedCornerShape(12.dp)).padding(padding),
        content = content,
    )
}

@Composable
fun Lbl(text: String, modifier: Modifier = Modifier) =
    Text(text.uppercase(), style = MeshType.label, color = LocalMesh.current.mute, modifier = modifier.padding(bottom = 6.dp))

enum class PillKind { CRIT, HIGH, NORM, UNCL, OK }

@Composable
fun Pill(text: String, kind: PillKind, leading: (@Composable () -> Unit)? = null) {
    val c = LocalMesh.current
    val (bg, fg) = when (kind) {
        PillKind.CRIT -> c.critSoft to c.sos; PillKind.HIGH -> c.amberSoft to c.amber
        PillKind.NORM -> c.meshSoft to c.mesh; PillKind.OK -> c.okSoft to c.ok; PillKind.UNCL -> Color.Transparent to c.mute
    }
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(bg)
            .then(if (kind == PillKind.UNCL) Modifier.border(1.dp, c.mute, RoundedCornerShape(50)) else Modifier)
            .padding(horizontal = 9.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        leading?.invoke()
        Text(text, color = fg, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

fun sevKind(s: Severity) = when (s) { Severity.CRITICAL -> PillKind.CRIT; Severity.HIGH -> PillKind.HIGH; Severity.NORMAL -> PillKind.NORM }

@Composable
fun sevColor(s: Severity?): Color {
    val c = LocalMesh.current
    return when (s) { Severity.CRITICAL -> c.sos; Severity.HIGH -> c.amber; Severity.NORMAL -> c.mesh; null -> c.mute }
}

@Composable
fun severityName(s: Severity) = stringResource(when (s) {
    Severity.CRITICAL -> R.string.sev_critical; Severity.HIGH -> R.string.sev_high; Severity.NORMAL -> R.string.sev_normal
})

@Composable
fun categoryName(c: Category) = stringResource(when (c) {
    Category.MEDICAL -> R.string.cat_medical; Category.TRAPPED -> R.string.cat_trapped; Category.FIRE -> R.string.cat_fire
    Category.FLOOD -> R.string.cat_flood; Category.FOOD -> R.string.cat_food; Category.MISSING -> R.string.cat_missing
    Category.OTHER -> R.string.cat_other; Category.UNCLASSIFIED -> R.string.cat_unclassified
})

@Composable
fun SevPill(s: Severity, unclassified: Boolean = false) =
    if (unclassified) Pill(categoryName(Category.UNCLASSIFIED), PillKind.UNCL) else Pill(severityName(s), sevKind(s))

@Composable
fun SmallIcon(v: ImageVector, tint: Color, size: Dp = 20.dp, cd: String? = null) = Icon(v, cd, tint = tint, modifier = Modifier.size(size))

/** List row with a coloured severity stripe on the left (prototype `.item`). */
@Composable
fun StripeItem(stripe: Color?, onClick: (() -> Unit)?, modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    val c = LocalMesh.current
    Row(
        modifier.fillMaxWidth().height(IntrinsicSize.Min).clip(RoundedCornerShape(12.dp)).background(c.card)
            .border(1.dp, c.line, RoundedCornerShape(12.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (stripe != null) Box(Modifier.width(5.dp).fillMaxHeight().background(stripe))
        Row(Modifier.weight(1f).padding(start = if (stripe != null) 11.dp else 12.dp, end = 12.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

/** Segmented control (prototype `.seg`). [activeColor] lets severity buttons turn red / amber / teal. */
@Composable
fun <T> Seg(options: List<Pair<T, String>>, selected: T?, onSelect: (T) -> Unit, activeColor: @Composable (T) -> Color? = { null }) {
    val c = LocalMesh.current
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(c.card).border(1.dp, c.line, RoundedCornerShape(10.dp))) {
        options.forEachIndexed { i, (key, label) ->
            val on = key == selected
            val bg = if (on) activeColor(key) ?: c.ink else Color.Transparent
            val fg = if (on) (if (activeColor(key) != null) c.app else c.card) else c.ink
            if (i > 0) Box(Modifier.width(1.dp).height(36.dp).background(c.line))
            Box(
                Modifier.weight(1f).heightIn(min = 36.dp).background(bg)
                    .clickable(role = Role.Tab) { onSelect(key) }.semantics { this.selected = on }
                    .padding(vertical = 8.dp, horizontal = 6.dp),
                contentAlignment = Alignment.Center,
            ) { Text(label, color = fg, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis) }
        }
    }
}

@Composable
fun ChipToggle(label: String, selected: Boolean, onClick: () -> Unit, danger: Boolean = false) {
    val c = LocalMesh.current
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(if (selected) c.ink else c.card)
            .border(1.dp, if (danger) c.sos else if (selected) c.ink else c.line, RoundedCornerShape(50))
            .clickable(role = Role.Button, onClick = onClick).semantics { this.selected = selected }
            .padding(horizontal = 12.dp, vertical = 6.dp),
    ) { Text(label, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = if (danger) c.sos else if (selected) c.card else c.ink) }
}

@Composable
fun MeshSwitch(checked: Boolean, onChange: (Boolean) -> Unit, enabled: Boolean = true, cd: String) {
    val c = LocalMesh.current
    Switch(checked, onChange, enabled = enabled, modifier = Modifier.semantics { contentDescription = cd },
        colors = SwitchDefaults.colors(checkedTrackColor = c.mesh, checkedThumbColor = c.card, uncheckedTrackColor = c.line,
            uncheckedThumbColor = c.card, uncheckedBorderColor = c.line, disabledCheckedTrackColor = c.mesh.copy(alpha = 0.55f),
            disabledCheckedThumbColor = c.card))
}

@Composable
fun Meter(fraction: Float) {
    val c = LocalMesh.current
    Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(c.line)) {
        Box(Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).fillMaxHeight().clip(RoundedCornerShape(3.dp)).background(c.mesh))
    }
}

@Composable
fun IconCircle(v: ImageVector, cd: String, onClick: () -> Unit, tint: Color = LocalMesh.current.ink) {
    val c = LocalMesh.current
    Box(
        Modifier.size(40.dp).clip(CircleShape).background(c.card).border(1.dp, c.line, CircleShape)
            .clickable(role = Role.Button, onClick = onClick).semantics { contentDescription = cd },
        contentAlignment = Alignment.Center,
    ) { Icon(v, null, tint = tint, modifier = Modifier.size(20.dp)) }
}

@Composable
fun TopBar(title: String, onBack: (() -> Unit)? = null, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth().heightIn(min = 44.dp), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (onBack != null) IconCircle(MeshIcons.Back, stringResource(R.string.back), onBack)
        Text(title, style = MeshType.screenTitle, color = LocalMesh.current.ink, modifier = Modifier.weight(1f))
        trailing()
    }
}

@Composable
fun PulseDot(color: Color = LocalMesh.current.mesh) {
    val t = rememberInfiniteTransition(label = "pulse")
    val r by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1600), RepeatMode.Restart), label = "r")
    Box(Modifier.size(9.dp).drawBehind {
        drawCircle(color.copy(alpha = 0.55f * (1 - r)), radius = size.minDimension / 2 + 9.dp.toPx() * r)
        drawCircle(color)
    })
}

@Composable
fun Avatar(initials: String, rescuer: Boolean) {
    val c = LocalMesh.current
    Box(Modifier.size(38.dp).clip(CircleShape).background(if (rescuer) c.critSoft else c.meshSoft), contentAlignment = Alignment.Center) {
        Text(initials, color = if (rescuer) c.sos else c.mesh, fontWeight = FontWeight.SemiBold)
    }
}

/** Four bars; [level] 0..4. */
@Composable
fun SignalBars(level: Int) {
    val c = LocalMesh.current
    Row(Modifier.height(14.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
        listOf(5, 8, 11, 14).forEachIndexed { i, h ->
            Box(Modifier.width(4.dp).height(h.dp).clip(RoundedCornerShape(1.dp)).background(if (i < level) c.mesh else c.line))
        }
    }
}

@Composable
fun Stepper(value: Int, onMinus: () -> Unit, onPlus: () -> Unit, minusCd: String, plusCd: String) {
    val c = LocalMesh.current
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        for ((label, cd, action) in listOf(Triple("−", minusCd, onMinus), Triple("", "", {}), Triple("+", plusCd, onPlus))) {
            if (label.isEmpty()) {
                Text("$value", fontWeight = FontWeight.SemiBold, fontSize = 16.sp, modifier = Modifier.width(28.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            } else Box(
                Modifier.size(34.dp).clip(CircleShape).background(c.card).border(1.dp, c.line, CircleShape)
                    .clickable(role = Role.Button, onClick = action).semantics { contentDescription = cd },
                contentAlignment = Alignment.Center,
            ) { Text(label, fontSize = 18.sp, color = c.ink) }
        }
    }
}

@Composable
fun MeshButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, kind: String = "pri", enabled: Boolean = true,
               icon: ImageVector? = null) {
    val c = LocalMesh.current
    val (bg, fg) = when (kind) { "sos" -> c.sos to c.sosInk; "ghost" -> c.card to c.ink; else -> c.mesh to c.app }
    Row(
        modifier.fillMaxWidth().heightIn(min = 50.dp).clip(RoundedCornerShape(12.dp)).background(if (enabled) bg else c.line)
            .then(if (kind == "ghost") Modifier.border(BorderStroke(1.dp, c.line), RoundedCornerShape(12.dp)) else Modifier)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick).padding(PaddingValues(horizontal = 16.dp, vertical = 12.dp)),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) { Icon(icon, null, tint = fg, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        Text(if (kind == "sos") text.uppercase() else text, color = fg,
            style = if (kind == "sos") MeshType.screenTitle.copy(fontSize = 22.sp, letterSpacing = 0.9.sp) else MeshType.bodyStrong.copy(fontSize = 15.sp))
    }
}

@Composable
fun KeyValue(rows: List<Pair<String, String>>) {
    val c = LocalMesh.current
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for ((k, v) in rows) Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(k, color = c.mute, style = MeshType.body)
            Text(v, color = c.ink, style = MeshType.body.copy(fontWeight = FontWeight.Medium), modifier = Modifier.weight(1f),
                textAlign = androidx.compose.ui.text.style.TextAlign.End)
        }
    }
}

@Composable
fun relativeTime(millis: Long, now: Long = System.currentTimeMillis()): String {
    val m = ((now - millis) / 60_000).coerceAtLeast(0)
    return when {
        m < 1 -> stringResource(R.string.just_now)
        m < 60 -> stringResource(R.string.min_ago, m.toInt())
        m < 48 * 60 -> stringResource(R.string.h_ago, (m / 60).toInt())
        else -> stringResource(R.string.d_ago, (m / 1440).toInt())
    }
}

fun initials(name: String, fallback: String): String {
    val parts = name.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
    return when {
        parts.size >= 2 -> "${parts[0].first()}${parts[1].first()}".uppercase()
        parts.size == 1 -> parts[0].take(2).uppercase()
        else -> fallback.take(2).uppercase()
    }
}
