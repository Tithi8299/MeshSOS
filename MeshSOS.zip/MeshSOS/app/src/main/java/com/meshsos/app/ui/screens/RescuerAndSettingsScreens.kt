package com.meshsos.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.meshsos.app.LocalContainer
import com.meshsos.app.R
import com.meshsos.app.data.database.BatterySampleEntity
import com.meshsos.app.data.database.IncidentEntity
import com.meshsos.app.data.database.MessageEntity
import com.meshsos.app.data.repository.PriorityMode
import com.meshsos.app.ui.components.ChipToggle
import com.meshsos.app.ui.components.KeyValue
import com.meshsos.app.ui.components.Lbl
import com.meshsos.app.ui.components.MeshCard
import com.meshsos.app.ui.components.MeshIcons
import com.meshsos.app.ui.components.MeshSwitch
import com.meshsos.app.ui.components.Pill
import com.meshsos.app.ui.components.PillKind
import com.meshsos.app.ui.components.Seg
import com.meshsos.app.ui.components.SevPill
import com.meshsos.app.ui.components.SmallIcon
import com.meshsos.app.ui.components.TopBar
import com.meshsos.app.ui.components.categoryName
import com.meshsos.app.ui.components.relativeTime
import com.meshsos.app.ui.components.sevColor
import com.meshsos.app.ui.theme.LocalMesh
import com.meshsos.app.ui.theme.MeshFonts
import com.meshsos.app.ui.theme.MeshType
import com.meshsos.core.geo.Geo
import com.meshsos.core.model.Category
import com.meshsos.core.model.Severity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

// ------------------------------------------------------------------------- 9. Rescuer incident view
private enum class IncidentSort { SEVERITY, DISTANCE }

@Composable
fun IncidentsScreen(onReport: (String) -> Unit) {
    val c = LocalMesh.current
    val container = LocalContainer.current
    val settings by container.settings.settings.collectAsStateWithLifecycle()
    val incidents by container.db.incidents().observeAll().collectAsStateWithLifecycle(emptyList())
    val links by container.db.incidents().observeLinks().collectAsStateWithLifecycle(emptyList())
    val reports by container.db.messages().observeReceivedSos().collectAsStateWithLifecycle(emptyList())
    var sort by remember { mutableStateOf(IncidentSort.SEVERITY) }
    var open by remember { mutableStateOf(setOf<String>()) }
    val me = rememberMyFix()
    val byId = reports.associateBy { it.id }
    fun distanceOf(i: IncidentEntity): Double? =
        if (me != null && i.latitude != null && i.longitude != null) Geo.distanceMeters(me.latitude, me.longitude, i.latitude, i.longitude) else null
    val sorted = when (sort) {
        IncidentSort.SEVERITY -> incidents.sortedWith(compareBy<IncidentEntity> { Severity.fromCode(it.severity).rank * -1 }
            .thenBy { distanceOf(it) ?: Double.MAX_VALUE })
        IncidentSort.DISTANCE -> incidents.sortedBy { distanceOf(it) ?: Double.MAX_VALUE }
    }
    ScreenColumn {
        TopBar(stringResource(R.string.incidents)) { Pill(stringResource(R.string.rescuer_view), PillKind.CRIT) }
        if (!settings.rescuerMode) MeshCard { Text(stringResource(R.string.rescuer_off_note), style = MeshType.small, color = c.amber) }
        MeshCard {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallIcon(MeshIcons.Sparkle, c.mesh)
                Column {
                    Text(stringResource(R.string.grouped_n, links.size, incidents.size), style = MeshType.bodyStrong, color = c.ink)
                    Text(stringResource(R.string.grouped_sub), style = MeshType.small, color = c.mute)
                }
            }
        }
        Seg(listOf(IncidentSort.SEVERITY to stringResource(R.string.most_severe), IncidentSort.DISTANCE to stringResource(R.string.nearest)), sort, { sort = it })
        if (incidents.isEmpty()) Text(stringResource(R.string.no_incidents), style = MeshType.body, color = c.mute)
        for (i in sorted) {
            val members = links.filter { it.incidentId == i.incidentId }.mapNotNull { byId[it.messageId] }.sortedByDescending { it.receivedAt }
            IncidentCard(i, members, distanceOf(i), i.incidentId in open,
                onToggle = { open = if (i.incidentId in open) open - i.incidentId else open + i.incidentId }, onReport = onReport)
        }
    }
}

@Composable
private fun IncidentCard(i: IncidentEntity, members: List<MessageEntity>, dist: Double?, expanded: Boolean, onToggle: () -> Unit, onReport: (String) -> Unit) {
    val c = LocalMesh.current
    val sev = Severity.fromCode(i.severity); val cat = Category.fromCode(i.category)
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min).clip(RoundedCornerShape(12.dp)).background(c.card).border(1.dp, c.line, RoundedCornerShape(12.dp))) {
        Box(Modifier.width(5.dp).fillMaxHeight().background(if (cat == Category.UNCLASSIFIED) c.mute else sevColor(sev)))
        Column(Modifier.weight(1f)) {
            Row(Modifier.fillMaxWidth().clickable(role = Role.Button, onClick = onToggle)
                .semantics { stateDescription = if (expanded) "expanded" else "collapsed" }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(Modifier.widthIn(min = 34.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${i.reportCount}", style = MeshType.big.copy(fontSize = 30.sp), color = c.ink)
                    Text(stringResource(if (i.reportCount == 1) R.string.report_caps else R.string.reports_caps), fontSize = 10.sp, color = c.mute, fontWeight = FontWeight.Medium)
                }
                Column(Modifier.weight(1f)) {
                    Text(categoryName(cat), style = MeshType.bodyStrong, color = c.ink)
                    val parts = buildList {
                        members.firstOrNull()?.text?.let { add(it.take(40)) }
                        if (i.peopleCount > 0) add(pluralStringResource(R.plurals.people_n, i.peopleCount, i.peopleCount))
                        add(dist?.let { Geo.formatDistance(it) } ?: stringResource(R.string.distance_unknown))
                        add(relativeTime(i.latestAt))
                    }
                    Text(parts.joinToString(" · "), style = MeshType.small, color = c.mute, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                SevPill(sev, cat == Category.UNCLASSIFIED)
                Icon(MeshIcons.Chevron, null, tint = c.mute, modifier = Modifier.rotate(if (expanded) 90f else 0f))
            }
            if (expanded) {
                HorizontalDivider(color = c.line)
                Column(Modifier.padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (m in members) Row(Modifier.fillMaxWidth().clickable { onReport(m.id) }, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("“${m.text}”", style = MeshType.body.copy(fontSize = 13.sp), color = c.ink, modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(relativeTime(m.receivedAt), style = MeshType.small, color = c.mute)
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------------- 10. Settings
private val BENCHMARK = listOf(
    "বাবা শ্বাস নিচ্ছে না. My father has stopped breathing. আমরা ৩ জন, ছাদে আছি।", "Pani uthche, 5 jon, nouka lagbe.",
    "ভাই একটু আসেন please, ঘরের পাশে", "আগুন লেগেছে, দোকানে", "Fire near bazar, please hurry", "Water is up to the door",
    "আমার মেয়েকে খুঁজে পাচ্ছি না", "Khabar ar khabar pani nai, 20 jon", "building dhose poreche, niche manush atka",
    "My uncle got hit by a tin sheet, lots of blood", "snake bit my brother in the field", "we are stuck on the 2nd floor",
    "রাস্তায় গাছ পড়ে আছে", "need insulin for my mother", "amar chele ke paitesi na, boyosh 7", "the shelter is full",
    "gas smell in the kitchen", "pregnant woman needs hospital", "landslide buried two houses", "we are safe at the cyclone centre",
)

@Composable
fun SettingsScreen() {
    val c = LocalMesh.current
    val container = LocalContainer.current
    val scope = rememberCoroutineScope()
    val s by container.settings.settings.collectAsStateWithLifecycle()
    val mesh by container.engine.state.collectAsStateWithLifecycle()
    val count by container.db.messages().observeCount().collectAsStateWithLifecycle(0)
    val bytes by container.db.messages().observeTextBytes().collectAsStateWithLifecycle(0L)
    val blocked by container.db.peers().observeBlockedCount().collectAsStateWithLifecycle(0)
    var askDelete by remember { mutableStateOf(false) }
    var deleted by remember { mutableStateOf(false) }
    var name by remember(s.displayName) { mutableStateOf(s.displayName) }
    var bench by remember { mutableStateOf<String?>(null) }
    val battery by produceState<List<BatterySampleEntity>>(emptyList()) {
        value = container.db.battery().since(System.currentTimeMillis() - 48 * 3600_000L)
    }

    ScreenColumn {
        TopBar(stringResource(R.string.settings))
        MeshCard(padding = 0.dp) {
            Column(Modifier.padding(horizontal = 12.dp)) {
                SettingRow(R.string.power_saving, R.string.power_saving_sub, s.powerSaving) { v -> container.settings.update { it.copy(powerSaving = v) } }
                HorizontalDivider(color = c.line)
                SettingRow(R.string.relay_others, R.string.relay_others_sub, s.relayEnabled) { v -> container.settings.update { it.copy(relayEnabled = v) } }
                HorizontalDivider(color = c.line)
                SettingRow(R.string.share_location, R.string.share_location_sub, true, enabled = false) {}
                HorizontalDivider(color = c.line)
                SettingRow(R.string.rescuer_mode, R.string.rescuer_mode_sub, s.rescuerMode) { v -> container.settings.update { it.copy(rescuerMode = v) } }
            }
        }
        MeshCard {
            Lbl(stringResource(R.string.priority_mode))
            Seg(listOf(PriorityMode.RULE to stringResource(R.string.prio_rule), PriorityMode.LEARNED to stringResource(R.string.prio_learned)),
                s.priorityMode, { m -> container.settings.update { it.copy(priorityMode = m) } })
            Spacer(Modifier.height(6.dp))
            Text(stringResource(R.string.prio_note), style = MeshType.small, color = c.mute)
        }
        MeshCard {
            Lbl(stringResource(R.string.language))
            Seg(listOf("en" to "English", "bn" to "বাংলা"), s.language, { l -> container.settings.update { it.copy(language = l) } })
        }
        MeshCard {
            Lbl(stringResource(R.string.your_name))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it.take(40) }, Modifier.weight(1f), singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = c.mesh, unfocusedBorderColor = c.line))
                ChipToggle(stringResource(R.string.save), false, { container.settings.update { it.copy(displayName = name.trim()) } })
            }
            Spacer(Modifier.height(8.dp))
            KeyValue(listOf(stringResource(R.string.phone_id) to container.identity.nodeId.chunked(4).take(4).joinToString(" ")))
        }
        MeshCard {
            Lbl(stringResource(R.string.safety))
            KeyValue(listOf(
                stringResource(R.string.unsure_results) to stringResource(R.string.unsure_val),
                stringResource(R.string.msg_limit) to stringResource(R.string.msg_limit_val),
                stringResource(R.string.blocked_senders) to "$blocked",
            ))
            if (blocked > 0) { Spacer(Modifier.height(8.dp)); ChipToggle(stringResource(R.string.unhide_all), false, {
                scope.launch { container.db.peers().unblockAll(); container.incidents.regroupNow() } }) }
        }
        MeshCard {
            Lbl(stringResource(R.string.stored))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.stored_n, count, formatBytes(bytes)), style = MeshType.body, color = c.ink, modifier = Modifier.weight(1f))
                ChipToggle(stringResource(R.string.delete_all), false, { askDelete = true; deleted = false }, danger = true)
            }
            if (askDelete) Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(stringResource(R.string.cannot_undo), style = MeshType.small, color = c.mute, modifier = Modifier.weight(1f))
                ChipToggle(stringResource(R.string.keep), false, { askDelete = false })
                ChipToggle(stringResource(R.string.delete), false, { askDelete = false; scope.launch { container.engine.deleteAllStored(); deleted = true } }, danger = true)
            }
            if (deleted) Text(stringResource(R.string.deleted), style = MeshType.small, color = c.ok, modifier = Modifier.padding(top = 8.dp))
        }
        MeshCard {
            Lbl(stringResource(R.string.diagnostics))
            val benchLabel = stringResource(R.string.run_bench)
            val benchFmt = stringResource(R.string.bench_result)
            ChipToggle(benchLabel, false, {
                scope.launch {
                    val cl = container.classifier.await() ?: return@launch
                    val times = withContext(Dispatchers.Default) {
                        cl.classify(BENCHMARK[0])                      // warm-up, not counted
                        BENCHMARK.map { cl.classify(it).elapsedMillis }
                    }
                    bench = String.format(Locale.US, benchFmt, times.size, String.format(Locale.US, "%.1f", times.average()),
                        String.format(Locale.US, "%.1f", times.max()))
                }
            })
            bench?.let { Text(it, style = MeshType.mono, color = c.ink, modifier = Modifier.padding(top = 6.dp)) }
            Spacer(Modifier.height(8.dp))
            val duty = if (mesh.measuredMillis > 0) 100.0 * mesh.discoveryOnMillis / mesh.measuredMillis else 0.0
            val batteryLines = batteryRates(battery).map { (saving, rate) ->
                stringResource(R.string.battery_use_val, String.format(Locale.US, "%.1f", rate.first), String.format(Locale.US, "%.1f", rate.second),
                    stringResource(if (saving) R.string.mode_saving else R.string.mode_normal))
            }
            KeyValue(listOf(
                stringResource(R.string.scan_duty) to stringResource(R.string.scan_duty_val, String.format(Locale.US, "%.0f", duty),
                    String.format(Locale.US, "%.0f", mesh.measuredMillis / 60_000.0)),
                stringResource(R.string.battery_use) to (batteryLines.joinToString("\n").ifEmpty { stringResource(R.string.battery_use_none) }),
                stringResource(R.string.packets) to stringResource(R.string.packets_val, mesh.counters.received, mesh.counters.forwarded,
                    mesh.counters.dropped, mesh.counters.duplicates, mesh.counters.badSignature, mesh.counters.ttlExhausted),
            ))
        }
        MeshCard {
            Lbl(stringResource(R.string.privacy))
            Text(stringResource(R.string.privacy_body), style = MeshType.small, color = c.ink)
        }
        Text(stringResource(R.string.not_999), style = MeshType.small, color = c.mute)
    }
}

@Composable
private fun SettingRow(title: Int, sub: Int, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    val c = LocalMesh.current
    val t = stringResource(title)
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f)) {
            Text(t, style = MeshType.bodyStrong, color = c.ink)
            Text(stringResource(sub), style = MeshType.small.copy(fontSize = 12.5.sp), color = c.mute)
        }
        MeshSwitch(checked, onChange, enabled, t)
    }
}

private fun formatBytes(b: Long) = when {
    b < 1024 -> "$b B"; b < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
    else -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
}

/**
 * NFR4: battery drain per hour from 10-minute samples, only across unplugged intervals in the
 * same mode. Returns mode -> (percent per hour, hours observed). Needs at least 1 h of data.
 */
private fun batteryRates(samples: List<BatterySampleEntity>): Map<Boolean, Pair<Double, Double>> {
    val drop = HashMap<Boolean, Double>(); val hours = HashMap<Boolean, Double>()
    for ((a, b) in samples.zipWithNext()) {
        if (a.charging || b.charging || a.powerSaving != b.powerSaving) continue
        val h = (b.at - a.at) / 3_600_000.0
        if (h <= 0 || h > 0.5) continue          // skip gaps (app was not running)
        drop[a.powerSaving] = (drop[a.powerSaving] ?: 0.0) + (a.percent - b.percent)
        hours[a.powerSaving] = (hours[a.powerSaving] ?: 0.0) + h
    }
    return hours.filter { it.value >= 1.0 }.mapValues { (k, h) -> (drop[k]!! / h) to h }
}
