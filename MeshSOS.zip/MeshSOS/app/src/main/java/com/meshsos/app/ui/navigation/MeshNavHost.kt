package com.meshsos.app.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.meshsos.app.LocalContainer
import com.meshsos.app.R
import com.meshsos.app.ui.components.MeshIcons
import com.meshsos.app.ui.screens.ChatScreen
import com.meshsos.app.ui.screens.ComposeSosScreen
import com.meshsos.app.ui.screens.DeliveryScreen
import com.meshsos.app.ui.screens.DetailScreen
import com.meshsos.app.ui.screens.HomeScreen
import com.meshsos.app.ui.screens.InboxScreen
import com.meshsos.app.ui.screens.IncidentsScreen
import com.meshsos.app.ui.screens.NearbyScreen
import com.meshsos.app.ui.screens.OnboardingScreen
import com.meshsos.app.ui.screens.SettingsScreen
import com.meshsos.app.ui.theme.LocalMesh

object Routes {
    const val ONBOARD = "onboard"; const val HOME = "home"; const val COMPOSE = "compose"; const val SENT = "sent/{id}"
    const val NEARBY = "nearby"; const val INBOX = "inbox"; const val DETAIL = "detail/{id}"; const val CHAT = "chat/{peer}"
    const val INCIDENTS = "incidents"; const val SETTINGS = "settings"
    fun sent(id: String) = "sent/$id"; fun detail(id: String) = "detail/$id"; fun chat(peer: String) = "chat/$peer"
}

private val TAB_ROUTES = listOf(Routes.HOME, Routes.NEARBY, Routes.INBOX, Routes.INCIDENTS, Routes.SETTINGS)

/** Screen frame: content area plus the five-tab bar on tab screens (prototype `.device`). */
@Composable
fun Frame(nav: NavHostController, tabs: Boolean, foot: (@Composable () -> Unit)? = null, body: @Composable () -> Unit) {
    val c = LocalMesh.current
    Column(Modifier.fillMaxSize().background(c.app).windowInsetsPadding(WindowInsets.safeDrawing)) {
        Box(Modifier.weight(1f).fillMaxWidth()) { body() }
        if (foot != null) {
            HorizontalDivider(color = c.line)
            Box(Modifier.fillMaxWidth().background(c.app).padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 14.dp)) { foot() }
        }
        if (tabs) TabBar(nav)
    }
}

@Composable
private fun TabBar(nav: NavHostController) {
    val c = LocalMesh.current
    val entry by nav.currentBackStackEntryAsState()
    val current = entry?.destination?.route
    val unread by LocalContainer.current.db.messages().observeUnreadSos().collectAsStateWithLifecycle(0)
    HorizontalDivider(color = c.line)
    Row(Modifier.fillMaxWidth().background(c.card).padding(top = 6.dp, bottom = 10.dp, start = 4.dp, end = 4.dp)) {
        val items = listOf(
            Triple(Routes.HOME, R.string.tab_home, MeshIcons.Home), Triple(Routes.NEARBY, R.string.tab_nearby, MeshIcons.Near),
            Triple(Routes.INBOX, R.string.tab_inbox, MeshIcons.Inbox), Triple(Routes.INCIDENTS, R.string.tab_incidents, MeshIcons.Alert),
            Triple(Routes.SETTINGS, R.string.tab_settings, MeshIcons.Settings),
        )
        for ((route, label, icon) in items) {
            val on = current == route
            Column(
                Modifier.weight(1f).sizeIn(minHeight = 48.dp).clip(RoundedCornerShape(8.dp))
                    .clickable(role = Role.Tab) {
                        if (!on) nav.navigate(route) { popUpTo(Routes.HOME) { saveState = true }; launchSingleTop = true; restoreState = true }
                    }.semantics { selected = on }.padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Box {
                    Icon(icon, null, tint = if (on) c.mesh else c.mute, modifier = Modifier.size(22.dp))
                    if (route == Routes.INBOX && unread > 0) Box(
                        Modifier.offset(x = 12.dp, y = (-4).dp).clip(RoundedCornerShape(8.dp)).background(c.sos)
                            .padding(horizontal = 4.dp).height(16.dp), contentAlignment = Alignment.Center,
                    ) { Text("${minOf(unread, 99)}", color = c.sosInk, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) }
                }
                Text(stringResource(label), fontSize = 11.sp, color = if (on) c.mesh else c.mute,
                    fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1)
            }
        }
    }
}

@Composable
fun MeshNavHost(startOnboarding: Boolean) {
    val nav = rememberNavController()
    val back: () -> Unit = { if (!nav.popBackStack()) nav.navigate(Routes.HOME) }
    NavHost(nav, startDestination = if (startOnboarding) Routes.ONBOARD else Routes.HOME) {
        composable(Routes.ONBOARD) {
            OnboardingScreen(onDone = { nav.navigate(Routes.HOME) { popUpTo(Routes.ONBOARD) { inclusive = true } } })
        }
        composable(Routes.HOME) { Frame(nav, tabs = true) { HomeScreen(onSos = { nav.navigate(Routes.COMPOSE) }, onAlerts = { nav.navigate(Routes.INBOX) }) } }
        composable(Routes.COMPOSE) {
            ComposeSosScreen(nav, onBack = back, onSent = { id -> nav.navigate(Routes.sent(id)) { popUpTo(Routes.HOME) } })
        }
        composable(Routes.SENT, arguments = listOf(navArgument("id") { type = NavType.StringType })) {
            DeliveryScreen(nav, it.arguments?.getString("id") ?: "", onHome = { nav.navigate(Routes.HOME) { popUpTo(Routes.HOME) { inclusive = true } } },
                onAlerts = { nav.navigate(Routes.INBOX) })
        }
        composable(Routes.NEARBY) { Frame(nav, tabs = true) { NearbyScreen(onChat = { nav.navigate(Routes.chat(it)) }) } }
        composable(Routes.INBOX) {
            Frame(nav, tabs = true) { InboxScreen(onSos = { nav.navigate(Routes.detail(it)) }, onChat = { nav.navigate(Routes.chat(it)) }) }
        }
        composable(Routes.DETAIL, arguments = listOf(navArgument("id") { type = NavType.StringType })) {
            DetailScreen(nav, it.arguments?.getString("id") ?: "", onBack = back, onReply = { peer -> nav.navigate(Routes.chat(peer)) })
        }
        composable(Routes.CHAT, arguments = listOf(navArgument("peer") { type = NavType.StringType })) {
            ChatScreen(nav, it.arguments?.getString("peer") ?: "", onBack = back)
        }
        composable(Routes.INCIDENTS) { Frame(nav, tabs = true) { IncidentsScreen(onReport = { nav.navigate(Routes.detail(it)) }) } }
        composable(Routes.SETTINGS) { Frame(nav, tabs = true) { SettingsScreen() } }
    }
}
