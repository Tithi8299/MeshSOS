package com.meshsos.app.data.database

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Direction of a stored message relative to this phone. */
object Direction { const val OUT = 0; const val IN = 1 }

/**
 * Every SOS, broadcast and private message this phone sent or received (offline history).
 * [type] = PacketType.code, [category] = Category.code, [severity] = Severity.code,
 * [status] = DeliveryStatus.code (outgoing messages only).
 */
@Entity(tableName = "messages", indices = [Index("peerId"), Index("type"), Index("createdAt")])
data class MessageEntity(
    @PrimaryKey val id: String,
    val type: Int,
    val direction: Int,
    val senderId: String,
    val senderName: String,
    val recipientId: String?,
    /** For chats: the other party. For SOS: the sender (IN) or this phone (OUT). */
    val peerId: String,
    val text: String,
    val category: Int,
    val severity: Int,
    val peopleCount: Int,
    val aiConfidence: Float,
    val userEdited: Boolean,
    val latitude: Double?,
    val longitude: Double?,
    val accuracyMeters: Float?,
    val createdAt: Long,
    val receivedAt: Long,
    val hopCount: Int,
    val lastHopId: String?,
    val status: Int = 0,
    val statusAt: Long = 0,
    /** Distinct neighbours that accepted this message (Nearby transfer SUCCESS). */
    val handedToCount: Int = 0,
    val relayedByName: String? = null,
    val relayedAtHop: Int = 0,
    val deliveredByName: String? = null,
    val deliveredHops: Int = 0,
    val deliveredAt: Long? = null,
    val read: Boolean = false,
    /** Concept embedding from the classifier, float32 big-endian, for incident grouping. */
    val concept: ByteArray? = null,
)

/** Seen-message-ID table (FR5). Survives restarts so duplicates are never re-processed. */
@Entity(tableName = "seen_ids", indices = [Index("seenAt")])
data class SeenIdEntity(@PrimaryKey val messageId: String, val seenAt: Long)

/** MeshSOS phones this phone has met. Keys come from signed HELLO packets or signed SOS packets. */
@Entity(tableName = "peers")
data class PeerEntity(
    @PrimaryKey val nodeId: String,
    val displayName: String,
    val signingKey: ByteArray,
    val agreementKey: ByteArray,
    val isRescuer: Boolean,
    val firstSeen: Long,
    val lastSeen: Long,
    /** Current Nearby endpoint id while connected, else null. */
    val endpointId: String?,
    val connected: Boolean,
    val batteryPercent: Int,
    /** 0..1, measured from transfer successes and Nearby bandwidth quality; null = not measured. */
    val linkQuality: Float?,
    val medium: String?,
    val verified: Boolean = false,
    val blocked: Boolean = false,
    /** Fewest hops at which we have heard from this phone (1 = direct neighbour). */
    val minHops: Int = 1,
)

@Entity(tableName = "incidents")
data class IncidentEntity(
    @PrimaryKey val incidentId: String,
    val category: Int,
    val severity: Int,
    val reportCount: Int,
    val latitude: Double?,
    val longitude: Double?,
    val latestAt: Long,
    val peopleCount: Int,
    val meanSimilarity: Double,
    val updatedAt: Long,
)

@Entity(tableName = "incident_reports", primaryKeys = ["incidentId", "messageId"], indices = [Index("messageId")])
data class IncidentReportEntity(val incidentId: String, val messageId: String)

/** Signed RELAYED / DELIVERED receipts received for messages this phone sent. */
@Entity(tableName = "receipts", indices = [Index("refMessageId")])
data class ReceiptEntity(
    @PrimaryKey val receiptId: String,
    val refMessageId: String,
    val kind: Int,
    val fromNodeId: String,
    val fromName: String,
    val fromRescuer: Boolean,
    val hopCount: Int,
    val receivedAt: Long,
)

/** Public-key metadata only. Private keys live in KeyStore-encrypted preferences (KeyVault). */
@Entity(tableName = "key_metadata")
data class KeyMetadataEntity(@PrimaryKey val alias: String, val algorithm: String, val publicKeyHex: String, val createdAt: Long)

/** Persistent copy of the store-and-forward queue (FR8), so queued packets survive restarts. */
@Entity(tableName = "pending_forward", indices = [Index("enqueuedAt")])
data class PendingForwardEntity(
    @PrimaryKey val messageId: String,
    val packet: ByteArray,
    val severity: Int,
    val isOwn: Boolean,
    val enqueuedAt: Long,
    val createdAt: Long,
    /** Comma-separated node IDs that already received it. */
    val sentTo: String,
)

/** Battery level samples for NFR4 measurement. */
@Entity(tableName = "battery_samples")
data class BatterySampleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val at: Long,
    val percent: Float,
    val charging: Boolean,
    val powerSaving: Boolean,
    val discoveryOnMillis: Long,
)
