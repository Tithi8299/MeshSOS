package com.meshsos.app.location

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull

data class Fix(val latitude: Double, val longitude: Double, val accuracyMeters: Float?, val timeMillis: Long)

sealed class FixResult {
    data class Ok(val fix: Fix) : FixResult()
    data object NoPermission : FixResult()
    data object Unavailable : FixResult()
}

/**
 * One-shot GPS fixes (FR6, NFR7). The app never tracks location in the background: a fix is
 * requested only while the user is composing an SOS, and when viewing a received SOS (to show
 * distance and direction locally; that fix is never sent anywhere).
 * GPS works without internet; indoors a fresh fix may take long or fail, so we time out and
 * fall back to the last known fix if it is recent.
 */
class LocationProvider(private val context: Context) {
    private val client = LocationServices.getFusedLocationProviderClient(context)

    fun hasPermission() =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    suspend fun currentFix(timeoutMillis: Long = 12_000, maxLastKnownAgeMillis: Long = 5 * 60_000): FixResult {
        if (!hasPermission()) return FixResult.NoPermission
        return try {
            val cts = CancellationTokenSource()
            val loc = withTimeoutOrNull(timeoutMillis) {
                client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.token).await()
            } ?: run { cts.cancel(); null }
            val use = loc ?: client.lastLocation.await()?.takeIf { System.currentTimeMillis() - it.time < maxLastKnownAgeMillis }
            if (use == null) FixResult.Unavailable
            else FixResult.Ok(Fix(use.latitude, use.longitude, if (use.hasAccuracy()) use.accuracy else null, use.time))
        } catch (e: Exception) {
            FixResult.Unavailable
        }
    }
}
