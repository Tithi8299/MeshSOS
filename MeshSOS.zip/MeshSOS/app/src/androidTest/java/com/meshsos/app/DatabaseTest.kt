package com.meshsos.app

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.meshsos.app.data.database.Direction
import com.meshsos.app.data.database.IncidentEntity
import com.meshsos.app.data.database.IncidentReportEntity
import com.meshsos.app.data.database.MeshDatabase
import com.meshsos.app.data.database.MessageEntity
import com.meshsos.app.data.database.PendingForwardEntity
import com.meshsos.app.data.database.SeenIdEntity
import com.meshsos.core.model.DeliveryStatus
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Integration tests for persistence: seen IDs, status updates, retry queue, incident replacement. */
@RunWith(AndroidJUnit4::class)
class DatabaseTest {
    private lateinit var db: MeshDatabase

    @Before fun open() {
        db = Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(), MeshDatabase::class.java).build()
    }
    @After fun close() = db.close()

    private fun msg(id: String) = MessageEntity(id, 2, Direction.OUT, "me", "Me", null, "me", "help", 1, 1, 3, 0.9f, false,
        24.87, 91.40, 8f, 1000, 1000, 0, null)

    @Test fun seenIdIsRecordedOnce() {
        assertTrue(db.seenIds().insertBlocking(SeenIdEntity("aa", 1)) != -1L)
        assertEquals(-1L, db.seenIds().insertBlocking(SeenIdEntity("aa", 2)))
    }

    @Test fun deliveryStatusOnlyMovesForward() = runTest {
        db.messages().insert(msg("m1"))
        db.messages().raiseStatus("m1", DeliveryStatus.DELIVERED.code, 5)
        db.messages().raiseStatus("m1", DeliveryStatus.SENT.code, 6)        // late SENT event must not downgrade
        assertEquals(DeliveryStatus.DELIVERED.code, db.messages().get("m1")!!.status)
    }

    @Test fun pendingQueueSurvivesAndTracksNeighbours() = runTest {
        db.pending().upsert(PendingForwardEntity("p1", byteArrayOf(1, 2, 3), 1, true, 10, 10, ""))
        db.pending().setSentTo("p1", "nodeA,nodeB")
        val all = db.pending().all()
        assertEquals(1, all.size); assertEquals("nodeA,nodeB", all[0].sentTo)
        db.pending().delete("p1"); assertTrue(db.pending().all().isEmpty())
    }

    @Test fun incidentGroupingIsReplacedAtomically() = runTest {
        db.incidents().replace(listOf(IncidentEntity("i1", 1, 1, 2, null, null, 5, 3, 0.9, 5)),
            listOf(IncidentReportEntity("i1", "m1"), IncidentReportEntity("i1", "m2")))
        db.incidents().replace(listOf(IncidentEntity("i2", 3, 1, 1, null, null, 6, 0, 1.0, 6)), listOf(IncidentReportEntity("i2", "m3")))
        assertEquals(listOf("i2"), db.incidents().observeAll().first().map { it.incidentId })
        assertEquals(null, db.incidents().incidentOf("m1"))
    }
}
