package com.meshsos.app

import androidx.test.ext.junit.runners.AndroidJUnit4
import com.meshsos.app.security.TinkCurveProvider
import com.meshsos.core.crypto.Identity
import com.meshsos.core.crypto.PacketSigner
import com.meshsos.core.crypto.PrivateMessageCipher
import com.meshsos.core.model.PacketType
import com.meshsos.core.packet.Packet
import com.meshsos.core.packet.PacketCodec
import com.meshsos.core.routing.MeshRouter
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

/** Runs the real Tink provider on the phone (checks it works on API 26+). */
@RunWith(AndroidJUnit4::class)
class TinkInteropTest {
    private val a = Identity.generate(TinkCurveProvider, "A")
    private val b = Identity.generate(TinkCurveProvider, "B")

    @Test fun signAndVerify() {
        val signer = PacketSigner(TinkCurveProvider)
        val p = signer.sign(Packet(PacketType.SOS, MeshRouter.newMessageId(), a.nodeId, a.signing.publicKey, a.agreement.publicKey,
            "A", System.currentTimeMillis(), 6, 6, text = "help"), a)
        assertTrue(signer.verify(PacketCodec.decode(PacketCodec.encode(p))))
        assertFalse(signer.verify(p.copy(text = "HELP")))
    }

    @Test fun x25519IsSymmetric() = assertArrayEquals(
        TinkCurveProvider.agree(a.agreement.privateKey, b.agreement.publicKey),
        TinkCurveProvider.agree(b.agreement.privateKey, a.agreement.publicKey))

    @Test fun privateMessageRoundTrip() {
        val mid = MeshRouter.newMessageId()
        val sealed = PrivateMessageCipher(TinkCurveProvider).seal("ছাদে আছি", a.nodeId, b.nodeId, b.agreement.publicKey, mid)
        val p = Packet(PacketType.DIRECT_TEXT, mid, a.nodeId, a.signing.publicKey, a.agreement.publicKey, "A",
            System.currentTimeMillis(), 6, 6, recipientId = b.nodeId, ciphertext = sealed.ciphertext, ephemeralKey = sealed.ephemeralPublicKey)
        assertEquals("ছাদে আছি", PrivateMessageCipher(TinkCurveProvider).open(p, b))
    }
}
