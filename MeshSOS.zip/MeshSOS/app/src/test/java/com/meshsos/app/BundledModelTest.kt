package com.meshsos.app

import com.meshsos.core.ai.ClassifierModel
import com.meshsos.core.ai.EmergencyClassifier
import com.meshsos.core.ai.GroupingConfig
import com.meshsos.core.ai.LearnedPriorityScorer
import com.meshsos.core.model.Category
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** The model files shipped inside the APK load and work (JVM test, no device needed). */
class BundledModelTest {
    private fun asset(name: String) = listOf(File("src/main/assets/models/$name"), File("app/src/main/assets/models/$name")).first { it.exists() }

    @Test fun classifierAssetLoadsAndRunsFast() {
        val cl = EmergencyClassifier(asset("meshsos_classifier.bin").inputStream().use { ClassifierModel.load(it) })
        val r = cl.classify("আগুন লেগেছে, দোকানে")
        assertEquals(Category.FIRE, r.topGuess)
        assertTrue(r.elapsedMillis < 1000)
    }

    @Test fun configAssetsParse() {
        GroupingConfig.fromJson(asset("grouping_config.json").readText())
        LearnedPriorityScorer.fromJson(asset("priority_model.json").readText())
    }
}
