"""
MeshSOS discrete-time mesh simulator (AI-4: priority-aware forwarding).

Models what the Android app does:
  * nodes move (random waypoint) inside an area; a link exists when two nodes are within range
    (NetworkX geometric graph rebuilt every tick)
  * each node keeps a store-and-forward queue and remembers which neighbour it already sent
    each message to (the app does the same), receivers drop duplicates by message id
  * each link moves at most `link_capacity` packets per tick; a packet is lost with probability
    1 - link_quality
  * every message carries a TTL; a relay forwards only while TTL > 0
  * low-battery nodes relay fewer packets per tick
  * a message is DELIVERED when any rescuer node receives it

Policies compared (order in which a node drains its queue toward a neighbour):
  FIFO     - arrival order
  RULE     - transparent score: severity weight + aging (MeshSOS baseline)
  LEARNED  - severity utility x P(useful) from a logistic regression trained on simulator
             outcomes (train_priority.py), plus the same aging term
  HYBRID   - RULE score + learned correction 2*(P(useful)-0.5), plus aging  (used in the app)

Run:  python3 sim/mesh_sim.py --quick      (or without --quick for the full grid)
"""
import argparse
import json
import math
import os
import random
from dataclasses import dataclass, field

import networkx as nx
import numpy as np

SEV = ["critical", "high", "normal"]
SEV_W = {"critical": 3.0, "high": 1.6, "normal": 0.5}
DEADLINE = {"critical": 60, "high": 180, "normal": 600}  # seconds, used only for the training label
AGING_PER_MIN = 0.35   # fairness: +0.35 score per minute waited in this node's queue
AGING_CAP = 4.0


@dataclass
class Msg:
    mid: int
    sev: str
    created: int
    origin: int
    delivered_at: int = -1


@dataclass
class Copy:
    msg: Msg
    ttl: int
    hops: int
    arrived: int
    sent_to: set = field(default_factory=set)


def feature_row(c, now, battery, link_q):
    age_min = (now - c.msg.created) / 60.0
    return [1.0 if c.msg.sev == "critical" else 0.0, 1.0 if c.msg.sev == "high" else 0.0,
            min(age_min, 30.0) / 30.0, min(c.hops, 10) / 10.0, battery, link_q]


FEATURES = ["sev_critical", "sev_high", "age_norm", "hops_norm", "battery", "link_quality"]


class LearnedScorer:
    def __init__(self, path):
        with open(path) as f:
            d = json.load(f)
        self.w = np.array([d["weights"][k] for k in FEATURES])
        self.b = d["bias"]
        self.util = d["severity_utility"]

    def p_useful(self, c, now, battery, link_q):
        z = float(np.dot(self.w, feature_row(c, now, battery, link_q)) + self.b)
        return 1.0 / (1.0 + math.exp(-z))

    def __call__(self, c, now, battery, link_q):
        return self.util[c.msg.sev] * self.p_useful(c, now, battery, link_q)

    def hybrid(self, c, now, battery, link_q):
        # rule score plus a learned correction in [-1, +1]
        return SEV_W[c.msg.sev] + 2.0 * (self.p_useful(c, now, battery, link_q) - 0.5)


def aging(c, now):
    return min(AGING_CAP, AGING_PER_MIN * (now - c.arrived) / 60.0)


def run(n_nodes=40, area=600.0, radio_range=110.0, speed=0.0, ticks=900, msg_rate=0.25, ttl=6,
        link_capacity=1, n_rescuers=2, low_battery_share=0.3, policy="FIFO", scorer=None, seed=0,
        log_training=False):
    rnd = random.Random(seed)
    pos = {i: (rnd.uniform(0, area), rnd.uniform(0, area)) for i in range(n_nodes)}
    target = {i: (rnd.uniform(0, area), rnd.uniform(0, area)) for i in range(n_nodes)}
    battery = {i: (rnd.uniform(0.05, 0.2) if rnd.random() < low_battery_share else rnd.uniform(0.4, 1.0))
               for i in range(n_nodes)}
    rescuers = set(rnd.sample(range(n_nodes), n_rescuers))
    queues = {i: {} for i in range(n_nodes)}
    seen = {i: set() for i in range(n_nodes)}
    msgs, tx_log, mid = [], [], 0
    link_q = {}

    def lq(a, b):
        k = (min(a, b), max(a, b))
        if k not in link_q:
            link_q[k] = rnd.uniform(0.55, 0.98)
        return link_q[k]

    for t in range(ticks):
        # mobility (random waypoint)
        if speed > 0:
            for i in range(n_nodes):
                (x, y), (tx, ty) = pos[i], target[i]
                d = math.hypot(tx - x, ty - y)
                if d < speed:
                    target[i] = (rnd.uniform(0, area), rnd.uniform(0, area))
                else:
                    pos[i] = (x + speed * (tx - x) / d, y + speed * (ty - y) / d)
        # new messages (Poisson)
        k = np.random.default_rng(seed * 100003 + t).poisson(msg_rate)
        for _ in range(k):
            o = rnd.choice([i for i in range(n_nodes) if i not in rescuers])
            sev = rnd.choices(SEV, weights=[0.12, 0.28, 0.60])[0]
            m = Msg(mid, sev, t, o)
            msgs.append(m)
            queues[o][mid] = Copy(m, ttl, 0, t)
            seen[o].add(mid)
            mid += 1
        g = nx.random_geometric_graph(n_nodes, radio_range, pos=pos)
        deliveries = []
        for a in range(n_nodes):
            if not queues[a]:
                continue
            cap_a = link_capacity if battery[a] >= 0.2 else max(1, link_capacity // 2)
            if battery[a] < 0.2 and t % 2:   # low battery: relay every other tick
                continue
            for b in g.neighbors(a):
                q = lq(a, b)
                cands = [c for c in queues[a].values() if b not in c.sent_to and (c.ttl > 0 or c.hops == 0)]
                if not cands:
                    continue
                if policy == "FIFO":
                    cands.sort(key=lambda c: c.arrived)
                elif policy == "RULE":
                    cands.sort(key=lambda c: -(SEV_W[c.msg.sev] + aging(c, t)))
                elif policy == "RANDOM":
                    rnd.shuffle(cands)
                elif policy == "HYBRID":
                    cands.sort(key=lambda c: -(scorer.hybrid(c, t, battery[a], q) + aging(c, t)))
                else:
                    cands.sort(key=lambda c: -(scorer(c, t, battery[a], q) + aging(c, t)))
                for c in cands[:cap_a]:
                    c.sent_to.add(b)
                    ok = rnd.random() < q
                    if log_training:
                        tx_log.append((feature_row(c, t, battery[a], q), c.msg, t, ok))
                    if ok:
                        deliveries.append((b, c))
        for b, c in deliveries:
            m = c.msg
            if m.mid in seen[b]:
                continue                                   # duplicate suppression
            seen[b].add(m.mid)
            if b in rescuers:
                if m.delivered_at < 0:
                    m.delivered_at = t
                continue                                   # rescuer is an endpoint
            if c.ttl - 1 >= 0:
                queues[b][m.mid] = Copy(m, c.ttl - 1, c.hops + 1, t)
        # delivered messages leave queues (acknowledgement flooding is modelled as instant)
        for i in range(n_nodes):
            for k2 in [k3 for k3, c in queues[i].items() if c.msg.delivered_at >= 0]:
                del queues[i][k2]
    res = {"policy": policy}
    for s in SEV:
        ms = [m for m in msgs if m.sev == s and m.created < ticks - 120]
        lat = [m.delivered_at - m.created for m in ms if m.delivered_at >= 0]
        res[s] = {"n": len(ms), "delivery_ratio": (len(lat) / len(ms)) if ms else None,
                  "median_latency_s": float(np.median(lat)) if lat else None,
                  "p90_latency_s": float(np.percentile(lat, 90)) if lat else None}
    if log_training:
        res["_tx"] = tx_log
    return res


SCENARIOS = {
    "base_static_40": dict(n_nodes=40, speed=0.0),
    "walking_40": dict(n_nodes=40, speed=1.2),
    "dense_80": dict(n_nodes=80, speed=0.6),
    "sparse_25": dict(n_nodes=25, speed=1.2, radio_range=130.0),
    "heavy_load_40": dict(n_nodes=40, speed=0.6, msg_rate=0.6),
    "ttl3_40": dict(n_nodes=40, speed=0.6, ttl=3),
    "ttl10_40": dict(n_nodes=40, speed=0.6, ttl=10),
    "low_battery_40": dict(n_nodes=40, speed=0.6, low_battery_share=0.7),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--seeds", default="101,102,103,104")
    ap.add_argument("--out", default="simulation_results.json")
    ap.add_argument("--model", default=os.path.join(os.path.dirname(__file__), "results", "priority_model.json"))
    a = ap.parse_args()
    seeds = [101, 102] if a.quick else [int(x) for x in a.seeds.split(",")]
    scorer = LearnedScorer(a.model) if os.path.exists(a.model) else None
    policies = ["FIFO", "RULE"] + (["LEARNED", "HYBRID"] if scorer else [])
    out = {}
    for name, kw in SCENARIOS.items():
        out[name] = {}
        for p in policies:
            agg = {s: {"delivery_ratio": [], "median_latency_s": [], "p90_latency_s": []} for s in SEV}
            for sd in seeds:
                r = run(policy=p, scorer=scorer, seed=sd, **kw)
                for s in SEV:
                    for k in agg[s]:
                        if r[s][k] is not None:
                            agg[s][k].append(r[s][k])
            out[name][p] = {s: {**{k: (float(np.mean(v)) if v else None) for k, v in agg[s].items()},
                                **{k + "_sem": (float(np.std(v, ddof=1) / math.sqrt(len(v))) if len(v) > 1 else None)
                                   for k, v in agg[s].items()}} for s in SEV}
            c = out[name][p]["critical"]
            n = out[name][p]["normal"]
            print(f"{name:16s} {p:8s} crit DR={c['delivery_ratio']:.2f} med={c['median_latency_s']:.0f}s "
                  f"p90={c['p90_latency_s']:.0f}s | normal DR={n['delivery_ratio']:.2f} med={n['median_latency_s']:.0f}s")
    os.makedirs(os.path.join(os.path.dirname(__file__), "results"), exist_ok=True)
    with open(os.path.join(os.path.dirname(__file__), "results", a.out), "w") as f:
        json.dump(out, f, indent=1)


if __name__ == "__main__":
    main()
