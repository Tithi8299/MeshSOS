"""
Train the learned forwarding-priority model from simulator outcomes.

Training data: every transmission attempt in simulations run with a RANDOM queue order
(so the label is not biased by an existing policy). Features (see mesh_sim.FEATURES):
severity one-hot, message age, hop count, sender battery, link quality.
Label: 1 if that message reached a rescuer within its severity deadline after this
transmission AND the transmission succeeded, else 0 - i.e. "is sending this one now likely
to be useful?". At run time priority = severity_utility * P(useful) + aging term.

Writes sim/results/priority_model.json, copied into the app as assets/models/priority_model.json.
"""
import json
import os
import sys

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import train_test_split

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mesh_sim as S  # noqa: E402

X, y = [], []
for name, kw in S.SCENARIOS.items():
    for sd in (11, 12):
        r = S.run(policy="RANDOM", seed=sd, log_training=True, **kw)
        for feats, msg, t, ok in r["_tx"]:
            useful = ok and msg.delivered_at >= 0 and (msg.delivered_at - t) <= S.DEADLINE[msg.sev] \
                     and msg.delivered_at >= t
            X.append(feats)
            y.append(1 if useful else 0)
X, y = np.array(X), np.array(y)
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.25, random_state=0, stratify=y)
m = LogisticRegression(max_iter=2000).fit(Xtr, ytr)
auc = roc_auc_score(yte, m.predict_proba(Xte)[:, 1])
model = {"format": "meshsos-priority-v1", "features": S.FEATURES,
         "weights": dict(zip(S.FEATURES, map(float, m.coef_[0]))), "bias": float(m.intercept_[0]),
         "severity_utility": {"critical": 3.0, "high": 1.6, "normal": 0.5},
         "aging_per_min": S.AGING_PER_MIN, "aging_cap": S.AGING_CAP,
         "training": {"rows": int(len(y)), "positive_rate": float(y.mean()), "holdout_auc": float(auc)}}
out = os.path.join(os.path.dirname(__file__), "results", "priority_model.json")
os.makedirs(os.path.dirname(out), exist_ok=True)
with open(out, "w") as f:
    json.dump(model, f, indent=1)
print(json.dumps(model, indent=1))
