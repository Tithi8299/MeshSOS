# Requirements traceability matrix

Source: *MeshSOS Project Proposal*, section 2. Paths are relative to the repository root; `core/...` means `core/src/main/kotlin/com/meshsos/core/...` and `app/...` means `app/src/main/java/com/meshsos/app/...`.

**Verification status:**
- **Verified**: the test was actually run and passed in the build environment.
- **Written**: a test exists but has not been run yet (needs a Kotlin compiler or a phone).
- **Device**: can only be verified on physical phones (docs/DEVICE_TESTING_GUIDE.md).

## Functional requirements

| ID | Requirement | Implementation | Verification | Status |
|---|---|---|---|---|
| FR1 | Discover nearby devices without internet | `app/network/nearby/NearbyTransport.kt`: advertising + discovery, `P2P_CLUSTER`, service ID `com.meshsos.app.mesh.v1` | Device test A | Device |
| FR2 | Connect and exchange messages directly | `NearbyTransport` (request/accept, BYTES payloads); `MeshEngine.onConnected`, `sendHello`, `flushTo` | Device test A | Device |
| FR3 | Multi-hop forwarding | `core/routing/MeshRouter.kt` (`forwardedBy`), `PriorityForwardQueue`, `MeshEngine.onAccepted` | `RoutingTest.twoHopSosIsRelayedDeliveredAndAcknowledged`; device test B | Written / Device |
| FR4 | TTL on every message, drop at zero | `Packet.originalTtl/ttl` (original is signed), `PacketValidator`, `MeshRouter` | `RoutingTest.ttlZeroIsDeliveredButNotForwarded`, `ttlCannotBeRaisedByARelay`, `meshCannotLoopForever`; device test D | Written / Device |
| FR5 | Ignore already-seen message IDs | `SeenStore` → Room `seen_ids` (`SeenIdDao.insertBlocking`), pruned after 72 h (> 48 h packet lifetime) | `RoutingTest.duplicatesAreSuppressed`; `DatabaseTest.seenIdIsRecordedOnce`; device test C | Written / Device |
| FR6 | One-tap SOS with GPS | Home SOS → Send SOS (2 taps); `location/LocationProvider.kt`; `MeshEngine.sendSos` | Device test G | Device |
| FR7 | Text to one device or to everyone nearby | `MeshEngine.sendDirect`, `sendBroadcast`; Chat screen (peer or "Everyone nearby") | `PacketAndCryptoTest.onlyTheRecipientCanReadAPrivateMessage`; device test H | Written / Device |
| FR8 | Store undelivered messages, retry on a new neighbour | `PriorityForwardQueue` + Room `pending_forward`, restored at start (`restoreQueue`), flushed on every HELLO | `RoutingTest.queueSendsEachPacketToEachNeighbourOnceAndSkipsTheSender`; `DatabaseTest.pendingQueueSurvivesAndTracksNeighbours`; device tests E, F | Written / Device |
| FR9 | Show queued / sent / relayed / delivered | `DeliveryStatus`; SENT from Nearby `PayloadTransferUpdate.SUCCESS`; RELAYED/DELIVERED from signed receipts; `DeliveryScreen` | `RoutingTest` (receipts); `DatabaseTest.deliveryStatusOnlyMovesForward`; device test B | Written / Device |
| FR10 | Sign every message, reject invalid signatures | `core/crypto/Identity.kt` (`PacketSigner`), Ed25519 via `app/security/Security.kt` (Tink) | `PacketAndCryptoTest.relayFieldsAreNotSignedButEverythingElseIs`, `senderCannotClaimSomeoneElsesId`; `RoutingTest.tamperedPacketIsRejected`; `TinkInteropTest`; device test I | Written / Device |
| FR11 | Encrypt one-to-one messages | `PrivateMessageCipher`: ephemeral X25519 → HKDF-SHA256 → AES-256-GCM, header as AAD | `PacketAndCryptoTest` (recipient-only, tamper, fresh ciphertext, HKDF RFC 5869 vector); `TinkInteropTest.privateMessageRoundTrip`; device test H | Written / Device |
| FR12 | Power-saving mode that reduces scanning | `NearbyTransport.restartScanLoop` (continuous vs 5 s per 30 s), measured duty cycle in Settings → Diagnostics | Device test L | Device |
| FR13 | Distance and direction to a received SOS | `core/geo/Geo.kt` (haversine, bearing, 8-point compass); `DetailScreen` compass | `AiAndGeoTest.distanceAndDirection` | Written |

## AI feature requirements

| ID | Requirement | Implementation | Verification | Status |
|---|---|---|---|---|
| AI-1 | Classify Bangla / English / mixed text with a confidence score | `ml/train_classifier.py` → `meshsos_classifier.bin`; `core/ai/ClassifierModel.kt`, `EmergencyClassifier.kt`, `TextFeaturizer.kt`; New SOS screen | Held-out test (`ml/reports/classifier_report.md`); `ml/meshsos_model.py` parity check; `AiAndGeoTest.kotlinInferenceMatchesPythonGoldenVectors` | **Verified** (Python) / Written (Kotlin) |
| AI-2 | Severity level, editable before sending | Severity head of the same model; Severity segmented control + type chips mark the result as edited | Severity macro F1 0.575 (test), 0.763 (challenge set) | **Verified** (Python) |
| AI-3 | Unclassified below a threshold, still delivered | `EmergencyClassifier.threshold = 0.60`; text is always sent unchanged; classifier errors return UNCLASSIFIED and never throw | `AiAndGeoTest.classifierHandlesPrototypeMessageAndGarbage`; coverage 64 % on the test set | Written |
| AI-4 | Forwarding queue ordered by an AI priority score | `core/ai/PriorityScorer.kt` (Rule + Learned), aging against starvation, battery-aware relaying; `sim/` | Simulation, 20 seeds (docs/TEST_REPORT.md); `RoutingTest.criticalGoesFirstButOldRoutineMessagesAreNotStarved`, `lowBatteryStopsRelayingRoutineTrafficOnly` | **Verified** (sim) / Written |
| AI-5 | Group reports of the same incident, show counts | `core/ai/IncidentGrouper.kt` (concept embedding + TF-IDF + distance + time); `data/repository/IncidentRepository.kt`; Incidents screen | `ml/grouping_eval.py` (pairwise F1 0.838 on test scenarios); `AiAndGeoTest.groupingUsesMeaningPlaceAndTime` | **Verified** (Python) / Written |
| AI-6 | All AI on the device, no internet | Models are assets in the APK; inference is plain Kotlin; the app has no INTERNET permission | Manifest review (no `android.permission.INTERNET`); device test J | Device |

## Non-functional requirements

| ID | Requirement | How it is addressed | Verification | Status |
|---|---|---|---|---|
| NFR1 | Two-hop SOS within 10 s | Priority queue sends immediately on connect; Delivered latency is shown on the Delivery screen | Device test B (read the "x s" figure) | Device |
| NFR2 | ≥ 80 % macro F1 on held-out data | TF-IDF + logistic regression | **0.756 on held-out templates: target not met.** 0.858 on a 70-message hand-written challenge set (too small to claim the target) | **Not met** |
| NFR3 | Classification < 1 s on a mid-range phone | Sparse linear model, about 11.5 k features, 2.1 MB | Settings → Diagnostics → *Time the classifier* on a phone | Device |
| NFR4 | Small battery use per hour in power saving, measured | Battery sampled every 10 min (unplugged), reported per mode in Diagnostics | Device test L (2 h per mode) | Device |
| NFR5 | SOS in ≤ 3 taps | Home **SOS** → **Send SOS** = 2 taps (text optional; default text is used) | UI walkthrough | Written |
| NFR6 | Android 8.0 / API 26+ | `minSdk = 26`; Tink provides Ed25519/X25519 below API 33 | Install on an Android 8 phone or emulator | Device |
| NFR7 | Location only when sending an SOS | One-shot fix in the New SOS screen only; no background location permission; Detail screen uses your fix locally and never sends it | Code review; device test G | Written |

## Ethical and safety items (proposal section 5.3)

| Item | Implementation |
|---|---|
| Privacy notice before first use | Onboarding screen (screen 1) |
| Delete stored messages | Settings → Delete all (with confirmation) |
| Rate limit | 6 SOS per 10 minutes, enforced when sending and when relaying |
| Hide / report abusive senders | Flag button on the SOS detail screen; hidden senders are neither shown nor relayed |
| AI never blocks or hides a message | `EmergencyClassifier` never throws; the original text is always sent and shown |
| Not a replacement for 999 | Stated on onboarding and in Settings |
