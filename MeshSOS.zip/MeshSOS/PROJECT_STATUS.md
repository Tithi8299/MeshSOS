# Project status

Last updated: 25 November 2026.

## The short version

All the code is written: the Android app, the pure-Kotlin core, the Python training scripts and the simulator. The AI models are trained and evaluated, and the Python side was run and verified. **The Android build and the Kotlin tests have not been run yet**, because the environment this was built in blocks Google's Maven repository, Maven Central and the Android SDK. The first real build, and every phone test, happens on your computer.

| Area | State |
|---|---|
| Python: dataset, training, evaluation, export, grouping, simulator | **Run and verified** in the build environment |
| Exported model file vs scikit-learn | **Verified**: max difference 5.2 × 10⁻⁷ over 60 golden vectors |
| Kotlin expected values (normalisation, people count, classifier outputs, grouping, geo) | Cross-checked against the Python reference implementation |
| `core` module (Kotlin) | Written with JUnit tests; **not yet compiled or run** |
| `app` module (Kotlin, Compose, Room, Nearby, Tink) | Written; **not yet compiled** |
| Physical-device tests A to L | **Not run**: needs 2 to 6 phones (see docs/DEVICE_TESTING_GUIDE.md) |

## Milestones

| # | Milestone | Status |
|---|---|---|
| 1 | Requirements analysis and architecture | Done: REQUIREMENTS_TRACEABILITY.md, docs/ARCHITECTURE.md |
| 2 | Android project and initial build | Project created; **build not yet run** |
| 3 | Ten native UI screens | Written in Compose; not yet seen on a device |
| 4 | Real two-device communication | Implemented on Nearby Connections; needs device test A |
| 5 | Three-device multi-hop | Implemented at the application layer; unit-tested logic; needs device test B |
| 6 | Room database and store-and-forward | Implemented; DAO tests written (on-device) |
| 7 | SOS and GPS | Implemented; needs device test G |
| 8 | AI classifier and on-device inference | Trained and exported; Kotlin inference written; **macro F1 0.756, below the 0.80 target** |
| 9 | Priority forwarding and incident grouping | Simulated and trained; grouping F1 0.838 on synthetic scenarios |
| 10 | Security integration | Ed25519 + X25519 + HKDF + AES-GCM implemented; JDK-provider tests written |
| 11 | Testing, debugging, optimisation | Python done; Kotlin and device testing pending |
| 12 | Final APK and documentation | Documentation done; **APK must be built in Android Studio** |

## Current build status

- `./gradlew :core:test`: **not run**. The Kotlin compiler download was blocked by this environment's safety policy, and Maven Central is unreachable here.
- `./gradlew :app:assembleDebug`: **not run**. The Android SDK and Google Maven are unreachable here.
- Expect a few compile errors on the first build. Everything was written against stable, documented APIs, but nothing beats a compiler. Fix them in this order: `:core:test` first, then `:app:assembleDebug`.

## Known bugs and risks

- Unknown compile errors (see above).
- The Tink `subtle` API calls (`Ed25519Sign`, `Ed25519Verify`, `X25519`) are written from the Tink 1.x API. If Tink changed a signature, `TinkInteropTest` will show it.
- The Nearby Connections callbacks were written from the documented API of play-services-nearby 19.x and have not been exercised.
- The classifier's held-out macro F1 is 0.756, below the NFR2 target of 0.80. The weakest class is *food and water* (F1 0.51), often confused with *other*.
- The learned priority model did not beat the rule-based one in a 20-seed simulation, so rule-based is the default.

## Pending device tests

All of tests A to L in docs/DEVICE_TESTING_GUIDE.md, plus the on-device latency check (NFR3), the two-hop delay check (NFR1) and battery measurements in both modes (NFR4).

## Important architectural decisions

1. **Pure-Kotlin `core` module.** Routing, packet format, crypto glue, AI inference and grouping have no Android dependency, so they are unit-testable on any JDK and the same code runs on the phone.
2. **Nearby Connections with `P2P_CLUSTER`.** It supports M-to-N connections, which a mesh needs. Nearby only moves bytes between direct neighbours; all multi-hop forwarding, TTL and duplicate suppression are done by `MeshRouter`.
3. **Self-certifying node IDs.** A node ID is the first 16 bytes of SHA-256 of its Ed25519 key, so nobody can claim another phone's ID without its private key.
4. **Ephemeral-static X25519 per private message.** Every message gets a fresh key, so AES-GCM nonce reuse is impossible.
5. **A linear classifier running in plain Kotlin instead of TensorFlow Lite.** A TF-IDF + logistic-regression model is a sparse dot product, so it needs no ML runtime, adds no native library, and can be checked number-for-number against scikit-learn. No pretrained multilingual transformer could be downloaded in the build environment. See docs/KNOWN_LIMITATIONS.md.
6. **A supervised concept embedding for grouping.** The classifier's fine-grained "concept" head gives a language-independent vector, so "baba shash nicche na" and "my father stopped breathing" end up close together. It beat word overlap (F1 0.838 vs 0.562).
7. **Rule-based priority by default.** It was best in a 20-seed simulation. The learned model is available in Settings.
8. **Statuses come only from real events.** Sent = Nearby transfer success. Relayed and Delivered = signed receipts coming back. There are no timers.

## Exact next action

1. Open the project in Android Studio and run `./gradlew :core:test`. Fix any compile errors in `core`.
2. Run `./gradlew :app:assembleDebug`. Fix any compile errors in `app`.
3. Install on two phones and run device test A (docs/DEVICE_TESTING_GUIDE.md).
4. Run `./gradlew :app:connectedDebugAndroidTest` with a phone attached.
5. Continue with device tests B to L, and record the results in docs/TEST_REPORT.md.
6. To raise classifier accuracy: have team members write 300 to 500 real-style messages, especially for food and water and for English, label them, add them to the training data, and retrain.
